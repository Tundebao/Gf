import React, { createContext, useState, useEffect, useContext, useRef } from 'react';
import { useLocation } from 'wouter';

interface User {
  id: number;
  username: string;
  isAdmin: boolean;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  token: null,
  isAuthenticated: false,
  isLoading: true,
  error: null,
  login: async () => {},
  logout: async () => {},
  clearError: () => {},
});

export const useAuth = () => useContext(AuthContext);

interface AuthProviderProps {
  children: React.ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [, navigate] = useLocation();

  // Check authentication status on mount and token change
  useEffect(() => {
    const checkAuthStatus = async () => {
      console.log('Checking authentication status, token present:', !!token);
      
      // Immediately set loading to false if no token
      if (!token) {
        console.log('No token found, setting isLoading to false');
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        
        console.log('Fetching authentication status...');
        const response = await fetch('/api/auth/status', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
          credentials: 'include',
        });

        const data = await response.json();
        console.log('Auth status response:', data);

        if (data.authenticated && data.user) {
          console.log('User authenticated:', data.user);
          setUser(data.user);
          
          // Immediately set authenticated and not loading
          setIsLoading(false);
        } else {
          console.log('Token invalid or expired, clearing user data');
          // Token is invalid, clear it
          localStorage.removeItem('token');
          setToken(null);
          setUser(null);
          setIsLoading(false);
        }
      } catch (err) {
        console.error('Error checking auth status:', err);
        setError('Error checking authentication status. Please try again.');
        
        // Clear token on error to prevent repeated failed auth attempts
        localStorage.removeItem('token');
        setToken(null);
        setUser(null);
        setIsLoading(false);
      }
    };

    // Very short timeout - just 500ms
    const timeoutId = setTimeout(() => {
      // Ensure we don't get stuck forever in loading state
      if (isLoading) {
        console.log('Auth check timed out (short timeout), forcing loading to false');
        setIsLoading(false);
      }
    }, 500); // Much shorter timeout (0.5 seconds)

    checkAuthStatus();
    
    return () => clearTimeout(timeoutId);
  }, [token]);

  // Login function
  const login = async (username: string, password: string) => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
        credentials: 'include', // Send cookies
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Login failed');
      }

      // Save token to localStorage and state
      localStorage.setItem('token', data.token);
      setToken(data.token);
      setUser(data.user);
      
      console.log('Login successful, token stored:', data.token);
      
      // WebSocket will reconnect automatically with the new token
      // via the useEffect in the WebSocketContext
      navigate('/dashboard');
    } catch (err: any) {
      console.error('Login error:', err);
      setError(err.message || 'Failed to login. Please check your credentials.');
      setUser(null);
      setToken(null);
    } finally {
      setIsLoading(false);
    }
  };

  // Logout function
  const logout = async () => {
    try {
      setIsLoading(true);

      // Call logout API endpoint
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: {
          'Authorization': token ? `Bearer ${token}` : '',
        },
        credentials: 'include',
      });

      // Clear token from localStorage and state
      localStorage.removeItem('token');
      setToken(null);
      setUser(null);
      navigate('/login');
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const clearError = () => setError(null);

  const isAuthenticated = !!user;

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated,
        isLoading,
        error,
        login,
        logout,
        clearError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};