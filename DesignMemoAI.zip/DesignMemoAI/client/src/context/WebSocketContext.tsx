import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import { useAuth } from './AuthContext';

// Extend WebSocket interface to include our custom properties
declare global {
  interface WebSocket {
    retryCount?: number;
  }
}

interface WebSocketContextType {
  connected: boolean;
  lastMessage: any;
  sendMessage: (message: any) => void;
  subscribe: (channel: string, callback: (data: any) => void) => void;
  unsubscribe: (channel: string, callback: (data: any) => void) => void;
}

const WebSocketContext = createContext<WebSocketContextType>({
  connected: false,
  lastMessage: null,
  sendMessage: () => {},
  subscribe: () => {},
  unsubscribe: () => {}
});

export const useWebSocket = () => useContext(WebSocketContext);

interface WebSocketProviderProps {
  children: React.ReactNode;
}

export const WebSocketProvider: React.FC<WebSocketProviderProps> = ({ children }) => {
  const { token } = useAuth();
  const [connected, setConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<any>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const connectWebSocket = () => {
    try {
      // Get the correct protocol based on current connection
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      
      // Create the WebSocket URL with fallback options
      let wsUrl;
      const hostname = window.location.host;
      
      // Primary connection strategy - use the current hostname
      wsUrl = `${protocol}//${hostname}/ws`;
      
      console.log('Connecting to WebSocket at:', wsUrl);
      
      // If we have a token, add it as a query parameter
      const socketUrl = token ? `${wsUrl}?token=${token}` : wsUrl;
      
      // Create the WebSocket connection with error handling
      const socket = new WebSocket(socketUrl);
      
      // Store the socket reference
      socketRef.current = socket;

      socket.onopen = () => {
        console.log('WebSocket connection established');
        setConnected(true);
        
        // Reset retry count when connection is successful
        if (socketRef.current) {
          socketRef.current.retryCount = 0;
        }
        
        // Clear any reconnect timeout
        if (reconnectTimeoutRef.current) {
          clearTimeout(reconnectTimeoutRef.current);
          reconnectTimeoutRef.current = null;
        }
        
        // Send ping message to verify connection
        socket.send(JSON.stringify({ 
          type: 'ping',
          token: token // Include token in messages
        }));
        
        // Auto-subscribe to common channels
        setTimeout(() => {
          if (socket.readyState === WebSocket.OPEN) {
            // Subscribe to common channels directly as subscribe function might not be ready
            socket.send(JSON.stringify({
              type: 'subscribe',
              channel: 'notifications',
              token
            }));
            
            socket.send(JSON.stringify({
              type: 'subscribe',
              channel: 'system_logs',
              token
            }));
            
            console.log('Auto-subscribed to common channels');
          }
        }, 1000); // Small delay to ensure connection is stable
      };

      socket.onclose = (event) => {
        console.log('WebSocket connection closed:', event);
        setConnected(false);
        
        // Exponential backoff for reconnection attempts
        // Start with 2 seconds, and increase by 50% each time, up to 30 seconds
        const backoffTime = Math.min(
          30000, 
          2000 * Math.pow(1.5, socketRef.current?.retryCount || 0)
        );
        
        // Store retry count on the socket for exponential backoff
        if (!socketRef.current) {
          socketRef.current = socket;
        }
        socketRef.current.retryCount = (socketRef.current.retryCount || 0) + 1;
        
        console.log(`Reconnecting in ${Math.round(backoffTime / 1000)} seconds (attempt ${socketRef.current.retryCount})...`);
        
        // Try to reconnect after the calculated delay
        reconnectTimeoutRef.current = setTimeout(() => {
          console.log('Attempting to reconnect...');
          connectWebSocket();
        }, backoffTime);
      };

      socket.onerror = (error) => {
        console.error('WebSocket error:', error);
        // No need to explicitly close here as onclose will be triggered automatically
      };

      socket.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          console.log('WebSocket message received:', message);
          
          // Notify callbacks subscribed to this message type
          const messageType = message.type;
          const callbacks = callbacksRef.current.get(messageType);
          if (callbacks) {
            // Execute all callbacks registered for this message type
            callbacks.forEach(callback => {
              try {
                callback(message);
              } catch (error) {
                console.error(`Error in callback for ${messageType}:`, error);
              }
            });
          }
          
          // Handle different message types
          switch (message.type) {
            case 'pong':
              // Server responded to our ping
              console.log('Ping-pong: connection confirmed');
              break;
              
            case 'error':
              console.error('WebSocket error from server:', message.message);
              break;
              
            case 'subscription_success':
              console.log(`Successfully subscribed to ${message.channel}`);
              break;
              
            case 'subscription_error':
              console.error(`Error subscribing to ${message.channel}:`, message.message);
              break;

            case 'subscribed': // Subscription confirmation
              console.log(`Successfully subscribed to ${message.data?.channel}`);
              break;
              
            case 'order_update':
              console.log('Order update received:', message.data);
              break;
              
            case 'position_update':
              console.log('Position update received:', message.data);
              break;
              
            case 'copy_trading_log':
              console.log('Copy trading log received:', message.data);
              break;
              
            case 'risk_event':
              console.warn('Risk event received:', message.data);
              break;
              
            case 'notification':
              console.log('Notification received:', message.data);
              break;
              
            case 'system_log':
              console.log('System log received:', message.data);
              break;
              
            case 'status': // Connection status update
              console.log('Connection status:', message.data);
              break;
              
            case 'broker_status_change': // Broker connection status change
              console.log('Broker status changed:', message.data);
              // Invalidate broker status query cache to refresh UI
              try {
                // Check if window.queryClient has been assigned
                if (window.queryClient) {
                  window.queryClient.invalidateQueries({ queryKey: ['/api/brokers/status'] });
                  console.log('Invalidated broker status cache after connection change');
                }
              } catch (error) {
                console.error('Error invalidating broker status query:', error);
              }
              break;
              
            case 'broker_status': // Dedicated broker status event
              console.log('Broker status event received:', message.data);
              // This is handled by subscribers via the callback mechanism
              break;
              
            case 'heartbeat': // Server heartbeat
              // Silent handling, no need to log every heartbeat
              break;
              
            default:
              console.log('Unknown message type:', message.type);
          }
          
          // Update last message for any consumers
          setLastMessage(message);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };
    } catch (error) {
      console.error('Error connecting to WebSocket:', error);
    }
  };

  const sendMessage = (message: any) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      // Add token to all outgoing messages for authentication
      const messageWithToken = { ...message, token };
      socketRef.current.send(JSON.stringify(messageWithToken));
    } else {
      console.error('WebSocket is not connected, cannot send message');
    }
  };
  
  // Callback registry
  const callbacksRef = useRef<Map<string, Set<(data: any) => void>>>(new Map());
  
  // Subscribe to a specific channel with callback
  const subscribe = (channel: string, callback: (data: any) => void) => {
    // Register the callback
    if (!callbacksRef.current.has(channel)) {
      callbacksRef.current.set(channel, new Set());
    }
    callbacksRef.current.get(channel)?.add(callback);
    
    // Send subscription message to server if connected
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: 'subscribe',
        channel,
        token
      }));
      console.log(`Subscribed to ${channel}`);
    } else {
      console.error('WebSocket is not connected, subscription will be pending until connected');
    }
  };
  
  // Unsubscribe from a specific channel
  const unsubscribe = (channel: string, callback: (data: any) => void) => {
    // Remove the callback
    const callbacks = callbacksRef.current.get(channel);
    if (callbacks) {
      callbacks.delete(callback);
      if (callbacks.size === 0) {
        callbacksRef.current.delete(channel);
        
        // Send unsubscription message to server if connected
        if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
          socketRef.current.send(JSON.stringify({
            type: 'unsubscribe',
            channel,
            token
          }));
          console.log(`Unsubscribed from ${channel}`);
        }
      }
    }
  };

  useEffect(() => {
    // Connect when component mounts or when token changes
    if (socketRef.current) {
      socketRef.current.close();
    }
    connectWebSocket();

    // Cleanup on unmount
    return () => {
      if (socketRef.current) {
        socketRef.current.close();
      }
      
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [token]);

  return (
    <WebSocketContext.Provider value={{ connected, lastMessage, sendMessage, subscribe, unsubscribe }}>
      {children}
    </WebSocketContext.Provider>
  );
};