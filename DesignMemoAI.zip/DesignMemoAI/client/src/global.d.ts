import { QueryClient } from "@tanstack/react-query";

// Global type declarations for window object
declare global {
  interface Window {
    queryClient: QueryClient;
  }
}

export {};