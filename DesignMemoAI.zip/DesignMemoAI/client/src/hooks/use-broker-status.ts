import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useWebSocket } from '@/context/WebSocketContext';

export function useBrokerStatus() {
  const { connected: isWebSocketConnected } = useWebSocket();
  
  // Using React Query to fetch broker status
  const {
    data = { connected: false },
    isLoading,
    isError,
    refetch
  } = useQuery<{ 
    connected: boolean, 
    totalBrokers?: number, 
    connectedBrokers?: number,
    brokers?: any[]
  }>({
    queryKey: ['/api/brokers/status'],
    // Short staletime to ensure fresh data
    staleTime: 5000,
    // Don't refetch on window focus to avoid excessive refreshes
    refetchOnWindowFocus: false,
    // Enable polling every 15 seconds for continuous updates
    refetchInterval: 15000,
    // If we're not connected to WebSocket, don't fetch
    enabled: isWebSocketConnected,
  });

  // Listen for broker connection events from the WebSocket
  const { subscribe, unsubscribe } = useWebSocket();
  useEffect(() => {
    if (!isWebSocketConnected) return;

    // Handler for broker status events
    const handleBrokerEvent = (eventData: any) => {
      console.log('Received broker status update via WebSocket, refreshing data');
      refetch();
    };

    // Handler for broker status change events
    const handleBrokerStatusChange = (eventData: any) => {
      console.log('Received broker status change via WebSocket, refreshing data');
      refetch();
    };

    // Subscribe to broker status events and status change events
    subscribe('broker_status', handleBrokerEvent);
    subscribe('broker_status_change', handleBrokerStatusChange);
    
    // Refetch on initial mount/reconnect
    refetch();

    return () => {
      // Clean up subscriptions
      unsubscribe('broker_status', handleBrokerEvent);
      unsubscribe('broker_status_change', handleBrokerStatusChange);
    };
  }, [isWebSocketConnected, subscribe, unsubscribe, refetch]);

  // Ensure window.queryClient is set for global access
  useEffect(() => {
    if (typeof window !== 'undefined' && !window.queryClient) {
      console.warn('window.queryClient is not set. Some refresh actions may not work.');
    }
  }, []);

  return {
    isBrokerConnected: data.connected,
    brokerCount: data.totalBrokers || 0,
    connectedBrokerCount: data.connectedBrokers || 0,
    brokers: data.brokers || [],
    isLoading,
    isError,
    refetch
  };
}