import { useState, useEffect } from "react";

// Hook for detecting mobile devices based on screen width
export function useMobile(): boolean {
  const [isMobile, setIsMobile] = useState<boolean>(false);

  useEffect(() => {
    // Handler to call on window resize
    const handleResize = () => {
      // Set state based on window width (768px is typical tablet breakpoint)
      setIsMobile(window.innerWidth < 768);
    };
    
    // Add event listener
    window.addEventListener("resize", handleResize);
    
    // Call handler right away so state gets updated with initial window size
    handleResize();
    
    // Remove event listener on cleanup
    return () => window.removeEventListener("resize", handleResize);
  }, []); // Empty array ensures effect is only run on mount and unmount

  return isMobile;
}