import { apiRequest } from "./queryClient";

// Helper to get headers with auth token
function getAuthHeaders(): HeadersInit {
  const headers: HeadersInit = {};
  const token = localStorage.getItem('token');
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

// Broker API
export async function getBrokers() {
  const response = await fetch("/api/brokers", {
    headers: getAuthHeaders(),
    credentials: "include",
  });
  if (!response.ok) {
    throw new Error(`Error fetching brokers: ${response.statusText}`);
  }
  return await response.json();
}

export async function getBrokerStatus() {
  const response = await fetch("/api/brokers/status", {
    headers: getAuthHeaders(),
    credentials: "include",
  });
  if (!response.ok) {
    throw new Error(`Error fetching broker status: ${response.statusText}`);
  }
  return await response.json();
}

export async function addBroker(brokerData: any) {
  return apiRequest("POST", "/api/brokers", brokerData);
}

export async function refreshBroker(id: number) {
  return apiRequest("POST", `/api/brokers/${id}/refresh`, {});
}

export async function removeBroker(id: number) {
  return apiRequest("DELETE", `/api/brokers/${id}`, {});
}

// Trading API
export async function placeOrder(order: any) {
  return apiRequest("POST", "/api/trading/orders", order);
}

export async function cancelOrder(id: number) {
  return apiRequest("DELETE", `/api/trading/orders/${id}`, {});
}

export async function getOrders() {
  const response = await fetch("/api/trading/orders", {
    headers: getAuthHeaders(),
    credentials: "include",
  });
  if (!response.ok) {
    throw new Error(`Error fetching orders: ${response.statusText}`);
  }
  return await response.json();
}

export async function getPositions() {
  const response = await fetch("/api/trading/positions", {
    headers: getAuthHeaders(),
    credentials: "include",
  });
  if (!response.ok) {
    throw new Error(`Error fetching positions: ${response.statusText}`);
  }
  return await response.json();
}

// Symbol API
export async function searchSymbol(query: string) {
  const response = await fetch(`/api/symbols/search?q=${encodeURIComponent(query)}`, {
    headers: getAuthHeaders(),
    credentials: "include",
  });
  if (!response.ok) {
    throw new Error(`Error searching symbol: ${response.statusText}`);
  }
  return await response.json();
}

export async function getSymbolInfo(symbol: string) {
  const response = await fetch(`/api/symbols/${encodeURIComponent(symbol)}`, {
    headers: getAuthHeaders(),
    credentials: "include",
  });
  if (!response.ok) {
    throw new Error(`Error fetching symbol info: ${response.statusText}`);
  }
  return await response.json();
}

// Copy Trading API
export async function startCopyTrading() {
  return apiRequest("POST", "/api/copy-trading/start", {});
}

export async function stopCopyTrading() {
  return apiRequest("POST", "/api/copy-trading/stop", {});
}

export async function getCopyTradingStatus() {
  const response = await fetch("/api/copy-trading/status", {
    headers: getAuthHeaders(),
    credentials: "include",
  });
  if (!response.ok) {
    throw new Error(`Error fetching copy trading status: ${response.statusText}`);
  }
  return await response.json();
}

export async function getCopyTradingSettings() {
  const response = await fetch("/api/copy-trading/settings", {
    headers: getAuthHeaders(),
    credentials: "include",
  });
  if (!response.ok) {
    throw new Error(`Error fetching copy trading settings: ${response.statusText}`);
  }
  return await response.json();
}

export async function updateCopyTradingSettings(settings: any) {
  return apiRequest("PUT", "/api/copy-trading/settings", settings);
}

export async function getCopyTradingLogs() {
  const response = await fetch("/api/copy-trading/logs", {
    headers: getAuthHeaders(),
    credentials: "include",
  });
  if (!response.ok) {
    throw new Error(`Error fetching copy trading logs: ${response.statusText}`);
  }
  return await response.json();
}

export async function getCopyTradingStats() {
  const response = await fetch("/api/copy-trading/stats", {
    headers: getAuthHeaders(),
    credentials: "include",
  });
  if (!response.ok) {
    throw new Error(`Error fetching copy trading stats: ${response.statusText}`);
  }
  return await response.json();
}

export async function testCopyTrade(data: any) {
  return apiRequest("POST", "/api/copy-trading/test", data);
}

// Risk API
export async function getRiskSettings() {
  const response = await fetch("/api/risk/settings", {
    headers: getAuthHeaders(),
    credentials: "include",
  });
  if (!response.ok) {
    throw new Error(`Error fetching risk settings: ${response.statusText}`);
  }
  return await response.json();
}

export async function updateRiskSettings(settings: any) {
  return apiRequest("PUT", "/api/risk/settings", settings);
}

// Logs API
export async function getLogs(page = 1, limit = 20) {
  const response = await fetch(`/api/logs?page=${page}&limit=${limit}`, {
    headers: getAuthHeaders(),
    credentials: "include",
  });
  if (!response.ok) {
    throw new Error(`Error fetching logs: ${response.statusText}`);
  }
  return await response.json();
}

// Dashboard API
export async function getDashboardStats() {
  const response = await fetch("/api/dashboard/stats", {
    headers: getAuthHeaders(),
    credentials: "include",
  });
  if (!response.ok) {
    throw new Error(`Error fetching dashboard stats: ${response.statusText}`);
  }
  return await response.json();
}

// Notifications API
export async function getNotifications(page = 1, limit = 20) {
  const response = await fetch(`/api/notifications?page=${page}&limit=${limit}`, {
    headers: getAuthHeaders(),
    credentials: "include",
  });
  if (!response.ok) {
    throw new Error(`Error fetching notifications: ${response.statusText}`);
  }
  return await response.json();
}

export async function markNotificationAsRead(id: number) {
  return apiRequest("PUT", `/api/notifications/${id}/read`, {});
}

export async function getUnreadNotificationsCount() {
  const response = await fetch("/api/notifications/unread", {
    headers: getAuthHeaders(),
    credentials: "include",
  });
  if (!response.ok) {
    throw new Error(`Error fetching unread notifications count: ${response.statusText}`);
  }
  return await response.json();
}
