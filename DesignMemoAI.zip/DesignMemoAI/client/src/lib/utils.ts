import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(value: number, options: Intl.NumberFormatOptions = {}): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
    ...options
  }).format(value);
}

export function formatNumber(value: number, options: Intl.NumberFormatOptions = {}): string {
  return new Intl.NumberFormat('en-US', options).format(value);
}

export function formatDate(date: Date | string, options: Intl.DateTimeFormatOptions = {}): string {
  if (typeof date === 'string') {
    date = new Date(date);
  }
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    ...options
  }).format(date);
}

export function formatTime(date: Date | string, options: Intl.DateTimeFormatOptions = {}): string {
  if (typeof date === 'string') {
    date = new Date(date);
  }
  return new Intl.DateTimeFormat('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    ...options
  }).format(date);
}

export function formatDateTime(date: Date | string, options: Intl.DateTimeFormatOptions = {}): string {
  if (typeof date === 'string') {
    date = new Date(date);
  }
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    ...options
  }).format(date);
}

export function truncateString(str: string, maxLength: number): string {
  if (str.length <= maxLength) return str;
  return str.slice(0, maxLength) + '...';
}

export function maskAccountId(id: string): string {
  if (!id) return '****';
  if (id.length <= 4) return '****' + id;
  return '****' + id.slice(-4);
}

export function getOrderTypeLabel(type: string): string {
  const orderTypes: Record<string, string> = {
    market: 'Market',
    limit: 'Limit',
    stop: 'Stop',
    stopLimit: 'Stop Limit',
    trailingStop: 'Trailing Stop',
  };
  
  return orderTypes[type] || type;
}

export function getActionLabel(action: string): string {
  const actions: Record<string, string> = {
    buy: 'Buy',
    sell: 'Sell',
    buyToOpen: 'Buy to Open',
    sellToOpen: 'Sell to Open',
    buyToClose: 'Buy to Close',
    sellToClose: 'Sell to Close',
  };
  
  return actions[action] || action;
}

export function getTimeInForceLabel(tif: string): string {
  const tifs: Record<string, string> = {
    day: 'Day',
    gtc: 'GTC',
    gtcExt: 'GTC EXT',
  };
  
  return tifs[tif] || tif;
}

export function isValidSymbol(symbol: string): boolean {
  // Basic validation - alphanumeric with possible dash or dot
  return /^[A-Z0-9\.-]+$/.test(symbol.toUpperCase());
}

export function getCurrentTimestamp(): string {
  return new Date().toISOString();
}
