import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { ThemeProvider } from "next-themes";
import { AuthProvider } from "./context/AuthContext";
import { WebSocketProvider } from "./context/WebSocketContext";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";

// Make queryClient globally available for imperative access
// This helps with WebSocket and other non-React based code
if (typeof window !== 'undefined') {
  window.queryClient = queryClient;
}

// Configure root error handling
const handleError = (error: any) => {
  console.error("Root error handler caught:", error);
};

// Apply the error handler
window.addEventListener('error', handleError);
window.addEventListener('unhandledrejection', (event) => handleError(event.reason));

createRoot(document.getElementById("root")!).render(
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <AuthProvider>
        <WebSocketProvider>
          <App />
        </WebSocketProvider>
      </AuthProvider>
    </ThemeProvider>
  </QueryClientProvider>
);
