import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useTheme } from "next-themes";
import { useMobile } from "@/hooks/use-mobile";
import { useAuth } from "@/context/AuthContext";
import { X, User, Moon, Sun } from "lucide-react";
import { 
  LayoutDashboard, 
  Users, 
  BarChart2, 
  Copy, 
  History, 
  Tag, 
  ShieldAlert, 
  Bell, 
  FileText, 
  Settings 
} from "lucide-react";

interface SidebarProps {
  open: boolean;
  setOpen: (open: boolean) => void;
}

interface SidebarItemProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  active: boolean;
}

function SidebarItem({ href, icon, label, active }: SidebarItemProps) {
  return (
    <Link href={href}>
      <Button
        variant="ghost"
        className={cn(
          "w-full justify-start",
          active && "bg-slate-100 text-primary-dark dark:bg-slate-700 dark:text-blue-400"
        )}
      >
        {icon}
        <span className="ml-3">{label}</span>
      </Button>
    </Link>
  );
}

function SidebarSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-6">
      <span className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider px-3">
        {title}
      </span>
      <div className="mt-2 space-y-1">
        {children}
      </div>
    </div>
  );
}

export function Sidebar({ open, setOpen }: SidebarProps) {
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();
  const isMobile = useMobile();
  const { user } = useAuth();
  
  return (
    <>
      {/* Overlay for mobile */}
      {isMobile && open && (
        <div 
          className="fixed inset-0 z-40 bg-black/50"
          onClick={() => setOpen(false)}
        />
      )}
      
      <aside 
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 transition-transform duration-300 ease-in-out transform bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 lg:static lg:translate-x-0 flex flex-col",
          open ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex items-center justify-between h-16 px-4 border-b border-slate-200 dark:border-slate-700">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded flex items-center justify-center bg-primary text-white">
              TC
            </div>
            <h1 className="ml-2 text-lg font-semibold">TradeCopy Pro</h1>
          </div>
          
          {isMobile && (
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setOpen(false)}
              className="lg:hidden"
            >
              <X className="h-5 w-5" />
              <span className="sr-only">Close sidebar</span>
            </Button>
          )}
        </div>
        
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto scrollbar-hide">
          <SidebarSection title="Main">
            <SidebarItem
              href="/dashboard"
              icon={<LayoutDashboard className="h-5 w-5" />}
              label="Dashboard"
              active={location === "/dashboard" || location === "/"}
            />
            <SidebarItem
              href="/accounts"
              icon={<Users className="h-5 w-5" />}
              label="Accounts"
              active={location === "/accounts"}
            />
          </SidebarSection>
          
          <SidebarSection title="Trading">
            <SidebarItem
              href="/manual-trading"
              icon={<BarChart2 className="h-5 w-5" />}
              label="Manual Trading"
              active={location === "/manual-trading"}
            />
            <SidebarItem
              href="/copy-trading"
              icon={<Copy className="h-5 w-5" />}
              label="Copy Trading"
              active={location === "/copy-trading"}
            />
            <SidebarItem
              href="/trades"
              icon={<History className="h-5 w-5" />}
              label="Trades"
              active={location === "/trades"}
            />
          </SidebarSection>
          
          <SidebarSection title="Configuration">
            <SidebarItem
              href="/symbols"
              icon={<Tag className="h-5 w-5" />}
              label="Symbols"
              active={location === "/symbols"}
            />
            <SidebarItem
              href="/risk-settings"
              icon={<ShieldAlert className="h-5 w-5" />}
              label="Risk Settings"
              active={location === "/risk-settings"}
            />
            <SidebarItem
              href="/notifications"
              icon={<Bell className="h-5 w-5" />}
              label="Notifications"
              active={location === "/notifications"}
            />
            <SidebarItem
              href="/logs"
              icon={<FileText className="h-5 w-5" />}
              label="Logs"
              active={location === "/logs"}
            />
            <SidebarItem
              href="/settings"
              icon={<Settings className="h-5 w-5" />}
              label="Settings"
              active={location === "/settings"}
            />
          </SidebarSection>
        </nav>
        
        <div className="p-4 border-t border-slate-200 dark:border-slate-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <User className="h-5 w-5 text-slate-400" />
              <span className="text-sm font-medium">Admin</span>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="rounded-full"
            >
              {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
          </div>
        </div>
      </aside>
    </>
  );
}
