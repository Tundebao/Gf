import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Bell, Menu, User } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import ConnectionStatus from "@/components/ConnectionStatus";
import { useQuery } from "@tanstack/react-query";
import { useBrokerStatus } from "@/hooks/use-broker-status";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface HeaderProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

export function Header({ sidebarOpen, setSidebarOpen }: HeaderProps) {
  const [location] = useLocation();
  const { logout, user } = useAuth();
  const { data: notifications = [], isLoading: isLoadingNotifications } = useQuery<any[]>({
    queryKey: ['/api/notifications/unread'],
  });
  
  // Use the broker status hook
  const { isBrokerConnected, isLoading: isLoadingBrokers } = useBrokerStatus();

  // Get page title based on current location
  const getPageTitle = () => {
    switch (true) {
      case location === "/" || location === "/dashboard":
        return "Dashboard";
      case location === "/accounts":
        return "Accounts";
      case location === "/manual-trading":
        return "Manual Trading";
      case location === "/copy-trading":
        return "Copy Trading";
      case location === "/trades":
        return "Trades History";
      case location === "/symbols":
        return "Symbols Management";
      case location === "/risk-settings":
        return "Risk Settings";
      case location === "/notifications":
        return "Notifications";
      case location === "/logs":
        return "System Logs";
      case location === "/settings":
        return "Platform Settings";
      default:
        return "";
    }
  };

  return (
    <header className="bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
      <div className="flex items-center justify-between h-16 px-4">
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="lg:hidden"
          >
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle sidebar</span>
          </Button>
          <h2 className="ml-2 lg:ml-0 text-lg font-semibold">
            {getPageTitle()}
          </h2>
        </div>
        
        <div className="flex items-center space-x-3">
          {/* WebSocket Connection Status Indicator */}
          <div className="hidden md:block">
            <ConnectionStatus />
          </div>
          
          {/* We've replaced this with the ConnectionStatus component which now shows broker status */}
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                {notifications.length > 0 && (
                  <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full" />
                )}
                <span className="sr-only">Notifications</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80">
              <DropdownMenuLabel>Notifications</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {isLoadingNotifications ? (
                <div className="py-2 px-4 text-center text-sm text-slate-500 dark:text-slate-400">
                  Loading notifications...
                </div>
              ) : notifications.length === 0 ? (
                <div className="py-2 px-4 text-center text-sm text-slate-500 dark:text-slate-400">
                  No new notifications
                </div>
              ) : (
                notifications.map((notification) => (
                  <DropdownMenuItem key={notification.id}>
                    <div className="flex flex-col w-full">
                      <div className="font-medium">{notification.title}</div>
                      <div className="text-sm text-slate-500 dark:text-slate-400">
                        {notification.message}
                      </div>
                      <div className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                        {new Date(notification.createdAt).toLocaleString()}
                      </div>
                    </div>
                  </DropdownMenuItem>
                ))
              )}
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Separator orientation="vertical" className="h-6" />
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-300">
                  A
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => logout()}>
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
