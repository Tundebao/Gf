import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { RefreshCw, MoreVertical, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

interface BrokerCardProps {
  broker: {
    id: number;
    type: "schwab" | "tastytrade";
    accountId: string;
    accountType: string;
    role: "leader" | "follower";
    connected: boolean;
    balance: number | null;
    buyingPower: number | null;
    pdtStatus: string | null;
    connectedAt: string | null;
  };
}

export function BrokerCard({ broker }: BrokerCardProps) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const { toast } = useToast();

  const formatCurrency = (amount: number | null) => {
    if (amount === null) return "N/A";
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };

  const getBrokerLogo = (type: string) => {
    if (type === "schwab") {
      return (
        <div className="w-8 h-8 rounded flex items-center justify-center bg-gray-600 text-white">
          CS
        </div>
      );
    } else if (type === "tastytrade") {
      return (
        <div className="w-8 h-8 rounded flex items-center justify-center bg-amber-600 text-white">
          TT
        </div>
      );
    }
    return null;
  };

  const refreshBroker = async () => {
    try {
      setIsRefreshing(true);
      await apiRequest("POST", `/api/brokers/${broker.id}/refresh`, {});
      
      // Invalidate queries to refresh data
      await queryClient.invalidateQueries({ queryKey: ["/api/brokers"] });
      
      toast({
        title: "Account refreshed",
        description: "Latest account data has been fetched.",
      });
    } catch (error) {
      console.error("Failed to refresh broker:", error);
      toast({
        title: "Refresh failed",
        description: error instanceof Error ? error.message : "Could not refresh account data",
        variant: "destructive",
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  const disconnectBroker = async () => {
    try {
      setIsDeleting(true);
      await apiRequest("DELETE", `/api/brokers/${broker.id}`, {});
      
      // Invalidate queries to refresh data
      await queryClient.invalidateQueries({ queryKey: ["/api/brokers"] });
      
      toast({
        title: "Broker disconnected",
        description: "Your broker account has been disconnected.",
      });
    } catch (error) {
      console.error("Failed to disconnect broker:", error);
      toast({
        title: "Disconnection failed",
        description: error instanceof Error ? error.message : "Could not disconnect broker",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
      setShowDeleteDialog(false);
    }
  };

  return (
    <>
      <Card className="overflow-hidden border border-slate-200 dark:border-slate-700">
        <CardHeader className="bg-slate-50 dark:bg-slate-700 px-4 py-4 border-b border-slate-200 dark:border-slate-600 flex flex-row justify-between items-center space-y-0">
          <div className="flex items-center">
            {getBrokerLogo(broker.type)}
            <div className="ml-3">
              <h4 className="font-medium">
                {broker.type === "schwab" ? "Charles Schwab" : "Tastytrade"}
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {broker.type === "schwab" ? "OAuth2 Connection" : "API Connection"}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant={broker.connected ? "success" : "destructive"}>
              {broker.connected ? "Connected" : "Disconnected"}
            </Badge>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                  <MoreVertical className="h-4 w-4" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={refreshBroker}>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Refresh
                </DropdownMenuItem>
                <DropdownMenuItem 
                  className="text-destructive focus:text-destructive"
                  onClick={() => setShowDeleteDialog(true)}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Disconnect
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardHeader>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Account Type</p>
              <p className="text-sm">{broker.accountType || "Unknown"}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Account ID</p>
              <p className="font-mono text-sm">{broker.accountId}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Connected</p>
              <p className="text-sm">{broker.connectedAt || "N/A"}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Balance</p>
              <p className="text-sm font-medium">{formatCurrency(broker.balance)}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Buying Power</p>
              <p className="text-sm font-medium">{formatCurrency(broker.buyingPower)}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">PDT Status</p>
              <p className="text-sm">{broker.pdtStatus || "N/A"}</p>
            </div>
          </div>
          
          <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
              <div className="flex items-center">
                <span className="mr-2 text-sm">Role:</span>
                <Badge variant={broker.role === "leader" ? "default" : "secondary"} className="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300 hover:bg-purple-100 dark:hover:bg-purple-900">
                  {broker.role === "leader" ? "Leader" : "Follower"}
                </Badge>
              </div>
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  disabled={isRefreshing}
                  onClick={refreshBroker}
                >
                  {isRefreshing ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      Refreshing...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Refresh
                    </>
                  )}
                </Button>
                <Button 
                  variant="destructive" 
                  size="sm"
                  disabled={isDeleting}
                  onClick={() => setShowDeleteDialog(true)}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Disconnect
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Disconnect Broker</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to disconnect this broker? This will remove all access to the account and stop any trading activities.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={disconnectBroker}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={isDeleting}
            >
              {isDeleting ? "Disconnecting..." : "Disconnect"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
