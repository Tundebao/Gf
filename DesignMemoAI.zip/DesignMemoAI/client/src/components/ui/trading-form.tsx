import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { DollarSign } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";

// Define form validation schema
const tradingFormSchema = z.object({
  accountId: z.string().min(1, "Account is required"),
  symbol: z.string().min(1, "Symbol is required"),
  instrumentType: z.enum(["stock", "option", "multiLegOption"]),
  action: z.string().min(1, "Action is required"),
  orderType: z.string().min(1, "Order type is required"),
  quantity: z.coerce.number().min(1, "Quantity must be at least 1"),
  price: z.coerce.number().min(0, "Price must be positive").optional(),
  timeInForce: z.string().min(1, "Time in force is required"),
  copyToFollowers: z.boolean().default(false),
});

type TradingFormValues = z.infer<typeof tradingFormSchema>;

export function TradingForm() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [formData, setFormData] = useState<TradingFormValues | null>(null);
  const { toast } = useToast();
  
  const form = useForm<TradingFormValues>({
    resolver: zodResolver(tradingFormSchema),
    defaultValues: {
      instrumentType: "stock",
      action: "buy",
      orderType: "market",
      quantity: 1,
      timeInForce: "day",
      copyToFollowers: false,
    },
  });

  // Get broker accounts
  const { data: accounts = [], isLoading: isLoadingAccounts } = useQuery<any[]>({
    queryKey: ['/api/brokers'],
  });
  
  const instrumentType = form.watch("instrumentType");
  const orderType = form.watch("orderType");
  
  function onPreviewOrder(values: TradingFormValues) {
    setFormData(values);
    setShowConfirmDialog(true);
  }
  
  async function placeOrder() {
    if (!formData) return;
    
    try {
      setIsSubmitting(true);
      
      // Call the API to place the order
      await apiRequest("POST", "/api/trading/orders", formData);
      
      toast({
        title: "Order placed successfully",
        description: "Your order has been sent to the broker.",
      });
      
      // Reset form after successful order
      form.reset({
        accountId: formData.accountId,
        instrumentType: "stock",
        action: "buy",
        orderType: "market",
        quantity: 1,
        timeInForce: "day",
        copyToFollowers: false,
        symbol: "",
        price: undefined,
      });
      
      setShowConfirmDialog(false);
    } catch (error) {
      console.error("Failed to place order:", error);
      toast({
        title: "Failed to place order",
        description: error instanceof Error ? error.message : "There was an error placing your order. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  function getEstimatedValue(): string {
    if (!formData) return "N/A";
    
    if (formData.price && formData.quantity) {
      return new Intl.NumberFormat('en-US', { 
        style: 'currency', 
        currency: 'USD'
      }).format(formData.price * formData.quantity);
    }
    
    return "Market Price";
  }
  
  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>New Order</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onPreviewOrder)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="accountId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Account</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                        disabled={isLoadingAccounts || accounts.length === 0}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select account" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {accounts.map((account) => (
                            <SelectItem 
                              key={account.id} 
                              value={account.id.toString()}
                            >
                              {account.type === "schwab" ? "Charles Schwab" : "Tastytrade"} {account.accountId}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {accounts.length === 0 && !isLoadingAccounts && (
                        <FormDescription className="text-destructive">
                          No broker accounts available. Please add a broker first.
                        </FormDescription>
                      )}
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="symbol"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Symbol</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter symbol (e.g. AAPL)" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="instrumentType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Order Type</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-wrap gap-4"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="stock" />
                          </FormControl>
                          <FormLabel className="font-normal">
                            Stock
                          </FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="option" />
                          </FormControl>
                          <FormLabel className="font-normal">
                            Option
                          </FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="multiLegOption" />
                          </FormControl>
                          <FormLabel className="font-normal">
                            Multi-leg Option
                          </FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <FormField
                  control={form.control}
                  name="action"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Action</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select action" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {instrumentType === "stock" ? (
                            <>
                              <SelectItem value="buy">Buy</SelectItem>
                              <SelectItem value="sell">Sell</SelectItem>
                            </>
                          ) : (
                            <>
                              <SelectItem value="buyToOpen">Buy to Open</SelectItem>
                              <SelectItem value="sellToOpen">Sell to Open</SelectItem>
                              <SelectItem value="buyToClose">Buy to Close</SelectItem>
                              <SelectItem value="sellToClose">Sell to Close</SelectItem>
                            </>
                          )}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="orderType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select order type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="market">Market</SelectItem>
                          <SelectItem value="limit">Limit</SelectItem>
                          <SelectItem value="stop">Stop</SelectItem>
                          <SelectItem value="stopLimit">Stop Limit</SelectItem>
                          <SelectItem value="trailingStop">Trailing Stop</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="quantity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Quantity</FormLabel>
                      <FormControl>
                        <Input type="number" min="1" placeholder="0" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {orderType !== "market" && (
                  <FormField
                    control={form.control}
                    name="price"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Price</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <DollarSign className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input 
                              type="number" 
                              step="0.01" 
                              min="0" 
                              placeholder="0.00" 
                              className="pl-7" 
                              {...field} 
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
                
                <FormField
                  control={form.control}
                  name="timeInForce"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Time in Force</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select time in force" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="day">Day</SelectItem>
                          <SelectItem value="gtc">GTC</SelectItem>
                          <SelectItem value="gtcExt">GTC EXT</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <Separator />
              
              <div className="flex justify-end space-x-3">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => form.reset()}
                >
                  Reset
                </Button>
                <Button type="submit">
                  Preview Order
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
      
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Order</DialogTitle>
            <DialogDescription>
              You are about to place the following order:
            </DialogDescription>
          </DialogHeader>
          
          <div className="bg-slate-50 dark:bg-slate-700 p-4 rounded-md space-y-2">
            <div className="flex justify-between">
              <span className="text-sm text-slate-500 dark:text-slate-400">Action</span>
              <span className="text-sm font-medium">
                {formData?.action === "buy" ? "Buy" :
                 formData?.action === "sell" ? "Sell" :
                 formData?.action === "buyToOpen" ? "Buy to Open" :
                 formData?.action === "sellToOpen" ? "Sell to Open" :
                 formData?.action === "buyToClose" ? "Buy to Close" :
                 formData?.action === "sellToClose" ? "Sell to Close" : ""}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-slate-500 dark:text-slate-400">Symbol</span>
              <span className="text-sm font-medium">{formData?.symbol?.toUpperCase()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-slate-500 dark:text-slate-400">Order Type</span>
              <span className="text-sm font-medium">
                {formData?.orderType === "market" ? "Market" :
                 formData?.orderType === "limit" ? "Limit" :
                 formData?.orderType === "stop" ? "Stop" :
                 formData?.orderType === "stopLimit" ? "Stop Limit" :
                 formData?.orderType === "trailingStop" ? "Trailing Stop" : ""}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-slate-500 dark:text-slate-400">Quantity</span>
              <span className="text-sm font-medium">{formData?.quantity}</span>
            </div>
            {formData?.price && (
              <div className="flex justify-between">
                <span className="text-sm text-slate-500 dark:text-slate-400">Price</span>
                <span className="text-sm font-medium">
                  ${Number(formData.price).toFixed(2)}
                </span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-sm text-slate-500 dark:text-slate-400">Estimated Value</span>
              <span className="text-sm font-medium">{getEstimatedValue()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-slate-500 dark:text-slate-400">Account</span>
              <span className="text-sm font-medium">
                {accounts.find(a => a.id.toString() === formData?.accountId)?.type === "schwab" 
                  ? "Charles Schwab " 
                  : "Tastytrade "}
                {accounts.find(a => a.id.toString() === formData?.accountId)?.accountId}
              </span>
            </div>
          </div>
          
          <FormField
            control={form.control}
            name="copyToFollowers"
            render={({ field }) => (
              <FormItem className="flex flex-row items-start space-x-3 space-y-0 mt-2">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
                <div className="space-y-1 leading-none">
                  <FormLabel>Copy to followers</FormLabel>
                  <FormDescription>
                    This order will be copied to all active follower accounts.
                  </FormDescription>
                </div>
              </FormItem>
            )}
          />
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowConfirmDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={placeOrder}
              disabled={isSubmitting}
            >
              {isSubmitting ? "Processing..." : "Place Order"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
