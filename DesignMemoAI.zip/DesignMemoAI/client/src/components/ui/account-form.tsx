import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";

// Type definitions for API responses
interface TastytradeResponse {
  message: string;
  broker: {
    id: number;
    name: string;
    type: string;
    accountId: string;
    connected: boolean;
  };
}

interface SchwabInitiateResponse {
  authUrl: string;
  message: string;
}

// Define Tastytrade form validation schema
const tastytradeFormSchema = z.object({
  brokerType: z.literal("tastytrade"),
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
  role: z.enum(["leader", "follower"]),
});

// Define Schwab form validation schema
const schwabFormSchema = z.object({
  brokerType: z.literal("schwab"),
  clientId: z.string().min(1, "Client ID is required"),
  clientSecret: z.string().min(1, "Client Secret is required"),
  redirectUri: z.string().url("Must be a valid URL"),
  role: z.enum(["leader", "follower"]),
});

// Combined form schema with discriminated union
const accountFormSchema = z.discriminatedUnion("brokerType", [
  tastytradeFormSchema,
  schwabFormSchema
]);

type AccountFormValues = z.infer<typeof accountFormSchema>;

interface AccountFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export function AccountForm({ open, onOpenChange, onSuccess }: AccountFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isRedirecting, setIsRedirecting] = useState(false);
  const { toast } = useToast();
  
  // Set separate default values for each broker type
  const defaultTastytradeValues = {
    brokerType: "tastytrade" as const,
    username: "sohtheng", // Pre-filled with provided credentials
    password: "sohtheng1986", // Pre-filled with provided credentials
    role: "leader" as const
  };
  
  // Form implementation
  const form = useForm<AccountFormValues>({
    resolver: zodResolver(accountFormSchema),
    defaultValues: defaultTastytradeValues,
  });

  const brokerType = form.watch("brokerType");

  // Handle form submissions for different broker types
  async function onSubmit(values: AccountFormValues) {
    try {
      setIsSubmitting(true);
      
      if (values.brokerType === "tastytrade") {
        // Connect to Tastytrade directly using their API
        const response = await apiRequest<TastytradeResponse>("POST", "/api/brokers/tastytrade/connect", {
          username: values.username,
          password: values.password,
          role: values.role
        });
        
        // Check if we got a valid response with a broker
        if (response && response.broker) {
          toast({
            title: "Tastytrade connected successfully",
            description: `Connected to Tastytrade account with real account ID: ${response.broker.accountId}`,
          });
        } else {
          throw new Error("Invalid response from server");
        }
        
      } else if (values.brokerType === "schwab") {
        // Initiate OAuth flow for Schwab
        const response = await apiRequest<SchwabInitiateResponse>("POST", "/api/brokers/schwab/initiate", {
          clientId: values.clientId,
          clientSecret: values.clientSecret,
          redirectUri: values.redirectUri,
          role: values.role
        });
        
        // Redirect to Schwab OAuth URL
        if (response && response.authUrl) {
          setIsRedirecting(true);
          toast({
            title: "Redirecting to Schwab",
            description: "You will be redirected to Charles Schwab to authorize this application.",
          });
          
          // Short delay before redirecting
          setTimeout(() => {
            window.location.href = response.authUrl;
          }, 1500);
          return;
        } else {
          throw new Error("Invalid OAuth response from server");
        }
      }
      
      // If we get here and not redirecting to OAuth, call onSuccess
      if (onSuccess) {
        onSuccess();
      }
      
      onOpenChange(false);
    } catch (error) {
      console.error("Failed to connect broker:", error);
      toast({
        title: "Connection failed",
        description: error instanceof Error ? error.message : "There was an error connecting to the broker. Please check your credentials and try again.",
        variant: "destructive",
      });
    } finally {
      if (!isRedirecting) {
        setIsSubmitting(false);
      }
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Connect Broker Account</DialogTitle>
          <DialogDescription>
            Add your broker credentials to connect your trading account.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="brokerType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Broker Type</FormLabel>
                  <Select 
                    onValueChange={(value) => {
                      // When broker type changes, we need to reset form fields
                      if (value === "tastytrade") {
                        // Set for Tastytrade
                        form.reset({
                          brokerType: "tastytrade",
                          username: "sohtheng",
                          password: "sohtheng1986",
                          role: "leader"
                        });
                      } else if (value === "schwab") {
                        // Set for Schwab
                        form.reset({
                          brokerType: "schwab",
                          clientId: "JtK96Q9sOAbNvbNSh9rWeaGuIK8Si335",
                          clientSecret: "8lrmF9APAnOTsGMn",
                          redirectUri: "https://tradeswim.org/auth/schwab/callback",
                          role: "leader"
                        });
                      }
                    }} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select broker" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="schwab">Charles Schwab</SelectItem>
                      <SelectItem value="tastytrade">Tastytrade</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {brokerType === "schwab" && (
              <>
                <FormDescription>
                  Charles Schwab requires OAuth2 authentication. You will be redirected to Schwab to authorize this application.
                </FormDescription>
                
                <FormField
                  control={form.control}
                  name="clientId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Client ID</FormLabel>
                      <FormControl>
                        <Input placeholder="Your Schwab Client ID" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="clientSecret"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Client Secret</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Your Schwab Client Secret" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="redirectUri"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Redirect URI</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormDescription>
                        This must match the redirect URI registered with Schwab
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </>
            )}
            
            {brokerType === "tastytrade" && (
              <>
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input placeholder="Your Tastytrade Username" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Your Tastytrade Password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </>
            )}
            
            <FormField
              control={form.control}
              name="role"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormLabel>Account Role</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex gap-6"
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="leader" />
                        </FormControl>
                        <FormLabel className="font-normal">
                          Leader
                        </FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="follower" />
                        </FormControl>
                        <FormLabel className="font-normal">
                          Follower
                        </FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormDescription>
                    Leader accounts send trades, follower accounts receive trades.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button
                type="button" 
                variant="outline" 
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Connecting..." : "Connect"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
