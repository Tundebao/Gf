import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useWebSocket } from "@/context/WebSocketContext";

interface LogEntry {
  id: number;
  timestamp: string;
  type: 'INFO' | 'WARNING' | 'ERROR';
  message: string;
}

export function SystemActivity() {
  const [_, navigate] = useLocation();
  const { connected } = useWebSocket();
  const [logs, setLogs] = useState<LogEntry[]>([]);
  
  const { data: initialLogs = [], isLoading } = useQuery<LogEntry[]>({
    queryKey: ['/api/logs/recent'],
  });
  
  useEffect(() => {
    if (initialLogs.length > 0) {
      setLogs(initialLogs);
    }
  }, [initialLogs]);
  
  // Use websocket to update logs in real-time
  const { lastMessage } = useWebSocket();
  
  useEffect(() => {
    if (lastMessage && lastMessage.type === 'log') {
      setLogs((prevLogs) => {
        // Add new log to the beginning and limit to 10 entries
        const newLogs = [lastMessage.data, ...prevLogs].slice(0, 10);
        return newLogs;
      });
    }
  }, [lastMessage]);

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    
    // If it's today, show the time
    if (date.toDateString() === now.toDateString()) {
      return date.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
    }
    
    // Otherwise, show the date and time
    return date.toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTypeVariant = (type: string) => {
    switch (type) {
      case 'ERROR':
        return "destructive";
      case 'WARNING':
        return "outline";
      case 'INFO':
      default:
        return "secondary";
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Recent System Activity</CardTitle>
        <Button 
          variant="link" 
          onClick={() => navigate('/logs')}
        >
          View All
        </Button>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
            <thead className="bg-slate-50 dark:bg-slate-700">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">
                  Time
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">
                  Type
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">
                  Message
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
              {isLoading ? (
                <tr>
                  <td colSpan={3} className="px-6 py-4 text-center text-sm text-slate-500 dark:text-slate-400">
                    Loading...
                  </td>
                </tr>
              ) : logs.length === 0 ? (
                <tr>
                  <td colSpan={3} className="px-6 py-10 text-center text-sm text-slate-500 dark:text-slate-400">
                    No recent activity
                  </td>
                </tr>
              ) : (
                logs.map((log) => (
                  <tr key={log.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">
                      {formatTime(log.timestamp)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <Badge variant={getTypeVariant(log.type)}>
                        {log.type}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">
                      {log.message}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </CardContent>
      <CardFooter className="border-t border-slate-200 dark:border-slate-700 py-2 px-6">
        <div className="w-full flex justify-end">
          <Badge variant={connected ? "outline" : "destructive"} className="ml-auto text-xs">
            {connected ? "Realtime Updates Active" : "Realtime Updates Disconnected"}
          </Badge>
        </div>
      </CardFooter>
    </Card>
  );
}
