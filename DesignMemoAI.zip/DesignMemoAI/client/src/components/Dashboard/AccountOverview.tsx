import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AccountForm } from "@/components/ui/account-form";
import { useQuery } from "@tanstack/react-query";
import { RefreshCw, LinkIcon } from "lucide-react";

export function AccountOverview() {
  const [showAccountModal, setShowAccountModal] = useState(false);
  
  const { 
    data: brokers = [], 
    isLoading,
    refetch,
    isRefetching
  } = useQuery<any[]>({
    queryKey: ['/api/brokers'],
  });
  
  const hasBrokers = brokers.length > 0;
  
  // Format broker ID for display
  const formatAccountId = (id: string) => {
    if (!id) return "****";
    if (id.length <= 4) return "****" + id;
    return "****" + id.slice(-4);
  };

  // Format currency values
  const formatCurrency = (amount: number | null) => {
    if (amount === null) return "$0.00";
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Connection Status</CardTitle>
        {hasBrokers && (
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => refetch()} 
            disabled={isRefetching}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isRefetching ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
          </div>
        ) : !hasBrokers ? (
          <div className="text-center py-8">
            <div className="flex justify-center mb-4">
              <div className="bg-slate-100 dark:bg-slate-700 p-4 rounded-full">
                <LinkIcon className="h-10 w-10 text-slate-400 dark:text-slate-500" />
              </div>
            </div>
            <h3 className="text-lg font-medium text-slate-900 dark:text-slate-100 mb-2">No Brokers Connected</h3>
            <p className="text-slate-500 dark:text-slate-400 mb-4 max-w-md mx-auto">
              You need to connect at least one broker to start trading. Set up your broker credentials to enable trading functionality.
            </p>
            <Button onClick={() => setShowAccountModal(true)}>
              <LinkIcon className="h-4 w-4 mr-2" />
              Connect Broker
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {brokers.map((broker) => (
              <div key={broker.id} className="border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden">
                <div className="px-4 py-3 bg-slate-50 dark:bg-slate-700 border-b border-slate-200 dark:border-slate-600 flex justify-between items-center">
                  <div className="flex items-center">
                    <div className={`w-6 h-6 rounded flex items-center justify-center ${broker.type === 'schwab' ? 'bg-gray-600' : 'bg-amber-600'} text-white text-xs`}>
                      {broker.type === 'schwab' ? 'CS' : 'TT'}
                    </div>
                    <h4 className="font-medium ml-2">
                      {broker.type === 'schwab' ? 'Charles Schwab' : 'Tastytrade'}
                    </h4>
                  </div>
                  <Badge variant={broker.connected ? "success" : "destructive"}>
                    {broker.connected ? "Connected" : "Disconnected"}
                  </Badge>
                </div>
                <div className="p-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Account ID</p>
                      <p className="font-mono text-sm">{formatAccountId(broker.accountId)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Role</p>
                      <p className="text-sm capitalize">{broker.role}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Buying Power</p>
                      <p className="text-sm font-medium">{formatCurrency(broker.buyingPower)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Last Updated</p>
                      <p className="text-sm">{broker.updatedAt ? new Date(broker.updatedAt).toLocaleTimeString() : 'Never'}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
      
      <AccountForm 
        open={showAccountModal} 
        onOpenChange={setShowAccountModal} 
        onSuccess={() => refetch()}
      />
    </Card>
  );
}
