import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { 
  Users, 
  BarChart4, 
  LineChart, 
  Files 
} from "lucide-react";

export function QuickStats() {
  const { 
    data: stats = { 
      activeAccounts: 0, 
      openPositions: 0, 
      dailyPnl: 0, 
      copyTradesCount: 0 
    }, 
    isLoading 
  } = useQuery<{
    activeAccounts: number;
    openPositions: number;
    dailyPnl: number;
    copyTradesCount: number;
  }>({
    queryKey: ['/api/dashboard/stats'],
    // Return a default value of zeros when the broker isn't connected
    enabled: false,
  });

  // Format currency values
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };

  const statItems = [
    {
      title: "Active Accounts",
      value: stats.activeAccounts.toString(),
      icon: <Users className="text-blue-600 dark:text-blue-400" />,
      bgColor: "bg-blue-100 dark:bg-blue-900",
    },
    {
      title: "Open Positions",
      value: stats.openPositions.toString(),
      icon: <BarChart4 className="text-amber-600 dark:text-amber-400" />,
      bgColor: "bg-amber-100 dark:bg-amber-900",
    },
    {
      title: "Daily P&L",
      value: formatCurrency(stats.dailyPnl),
      icon: <LineChart className="text-green-600 dark:text-green-400" />,
      bgColor: "bg-green-100 dark:bg-green-900",
    },
    {
      title: "Copy Trades Today",
      value: stats.copyTradesCount.toString(),
      icon: <Files className="text-purple-600 dark:text-purple-400" />,
      bgColor: "bg-purple-100 dark:bg-purple-900",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {statItems.map((stat, index) => (
        <Card key={index}>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{stat.title}</p>
                <p className="text-2xl font-semibold mt-1">{isLoading ? '-' : stat.value}</p>
              </div>
              <div className={`p-2 rounded-md ${stat.bgColor}`}>
                {stat.icon}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
