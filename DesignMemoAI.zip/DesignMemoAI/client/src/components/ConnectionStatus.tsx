import { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Wifi, WifiOff, RefreshCw, Database } from 'lucide-react';
import { useWebSocket } from '@/context/WebSocketContext';
import { useBrokerStatus } from '@/hooks/use-broker-status';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';

export default function ConnectionStatus() {
  const { connected } = useWebSocket();
  const { 
    isBrokerConnected, 
    brokerCount, 
    connectedBrokerCount,
    brokers = [],
    refetch: refreshBrokerStatus 
  } = useBrokerStatus();
  const [reconnectingStatus, setReconnectingStatus] = useState(false);
  const [lastConnectedTime, setLastConnectedTime] = useState<Date | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Update the last connected time when the connection status changes
  useEffect(() => {
    if (connected) {
      setLastConnectedTime(new Date());
      setReconnectingStatus(false);
      
      // When WebSocket connection is established, refresh broker status
      refreshBrokerStatus();
    } else if (lastConnectedTime !== null) {
      // If we were connected before but now disconnected, we're trying to reconnect
      setReconnectingStatus(true);
    }
  }, [connected, lastConnectedTime, refreshBrokerStatus]);
  
  // Function to manually refresh broker status
  const handleRefreshStatus = () => {
    setIsRefreshing(true);
    console.log("Manually refreshing broker status");
    
    // Make sure queryClient is available
    if (typeof window !== 'undefined' && window.queryClient) {
      window.queryClient.invalidateQueries({ queryKey: ['/api/brokers/status'] });
    }
    
    // Also use our hook's refetch method
    refreshBrokerStatus().finally(() => {
      setTimeout(() => setIsRefreshing(false), 500);
    });
  };

  // Function to get time elapsed since last connection
  const getElapsedTimeText = () => {
    if (!lastConnectedTime) return 'Never connected';
    
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - lastConnectedTime.getTime()) / 1000);
    
    if (diffInSeconds < 60) return `${diffInSeconds} seconds ago`;
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
    return `${Math.floor(diffInSeconds / 3600)} hours ago`;
  };

  return (
    <div className="flex items-center gap-2">
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="cursor-help">
              <Badge 
                variant={connected ? 'success' : reconnectingStatus ? 'warning' : 'error'} 
                className="flex items-center gap-1 h-6 px-2 py-1"
              >
                {connected ? (
                  <>
                    <Wifi className="h-3 w-3" />
                    <span className="text-xs font-medium">Connected</span>
                  </>
                ) : reconnectingStatus ? (
                  <>
                    <Wifi className="h-3 w-3 animate-pulse" />
                    <span className="text-xs font-medium">Reconnecting...</span>
                  </>
                ) : (
                  <>
                    <WifiOff className="h-3 w-3" />
                    <span className="text-xs font-medium">Disconnected</span>
                  </>
                )}
              </Badge>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <div className="text-sm">
              <div>WebSocket: {connected ? 'Connected' : reconnectingStatus ? 'Reconnecting' : 'Disconnected'}</div>
              <div>Broker: {isBrokerConnected ? 'Connected' : 'Disconnected'}</div>
              {lastConnectedTime && (
                <div>Last connected: {getElapsedTimeText()}</div>
              )}
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
      
      {/* Broker status badge */}
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="cursor-help">
              <Badge 
                variant={isBrokerConnected ? 'success' : 'error'} 
                className="flex items-center gap-1 h-6 px-2 py-1"
              >
                <span className="text-xs font-medium">
                  {isBrokerConnected ? 'Broker Connected' : 'No Broker'}
                </span>
              </Badge>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <div className="text-sm">
              <div className="font-semibold mb-1">Broker Status</div>
              <div>Connection: {isBrokerConnected ? 'Active' : 'Inactive'}</div>
              {isBrokerConnected && (
                <>
                  <div>Total brokers: {brokerCount}</div>
                  <div>Connected: {connectedBrokerCount} of {brokerCount}</div>
                  
                  {brokers.length > 0 && (
                    <div className="mt-2 mb-1">
                      <div className="font-semibold text-xs">Connected Brokers:</div>
                      <div className="max-h-28 overflow-y-auto">
                        {brokers.map((broker: any) => (
                          <div key={broker.id} className={`text-xs mt-1 flex items-center ${broker.connected ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                            <Database className="h-3 w-3 mr-1" />
                            {broker.name || broker.type} - {broker.connected ? 'Connected' : 'Disconnected'}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
              
              <div className="text-xs text-gray-500 mt-2">
                {isBrokerConnected 
                  ? 'Your broker account is connected and ready for trading' 
                  : 'Connect a broker to start trading'}
              </div>
              
              <Button 
                size="sm" 
                variant="outline" 
                className="w-full mt-2 h-7 text-xs"
                onClick={(e) => {
                  e.preventDefault();
                  handleRefreshStatus();
                }}
                disabled={isRefreshing}
              >
                {isRefreshing ? (
                  <>
                    <RefreshCw className="h-3 w-3 mr-1 animate-spin" />
                    Refreshing...
                  </>
                ) : (
                  <>
                    <RefreshCw className="h-3 w-3 mr-1" />
                    Refresh Status
                  </>
                )}
              </Button>
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  );
}