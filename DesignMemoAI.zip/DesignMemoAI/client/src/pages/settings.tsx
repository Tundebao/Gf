import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardFooter 
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AccountForm } from "@/components/ui/account-form";
import { 
  Settings as SettingsIcon, 
  LinkIcon, 
  Clock, 
  Globe, 
  Key, 
  Save, 
  Database,
  AlertTriangle
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// General settings schema
const generalSettingsSchema = z.object({
  timezone: z.string().min(1, "Timezone is required"),
  dateFormat: z.string().min(1, "Date format is required"),
  timeFormat: z.string().min(1, "Time format is required"),
  copyTradeDelay: z.coerce.number().min(0, "Delay must be a positive number"),
  defaultTradingHours: z.object({
    start: z.string(),
    end: z.string(),
  }),
  autoRefresh: z.boolean().default(true),
  refreshInterval: z.coerce.number().min(5, "Refresh interval must be at least 5 seconds"),
});

type GeneralSettingsValues = z.infer<typeof generalSettingsSchema>;

// API settings schema
const apiSettingsSchema = z.object({
  webhookEnabled: z.boolean().default(false),
  webhookUrl: z.string().url("Invalid webhook URL").optional().or(z.literal("")),
  webhookSecret: z.string().optional().or(z.literal("")),
});

type ApiSettingsValues = z.infer<typeof apiSettingsSchema>;

export default function SettingsPage() {
  const [showAccountModal, setShowAccountModal] = useState(false);
  const [showResetDialog, setShowResetDialog] = useState(false);
  const { toast } = useToast();
  
  const { 
    data: { brokersConnected = false } = {}, 
    isLoading: isLoadingBrokerStatus 
  } = useQuery<{brokersConnected: boolean}>({
    queryKey: ['/api/brokers/status'],
  });
  
  const { 
    data: generalSettings, 
    isLoading: isLoadingGeneralSettings 
  } = useQuery<GeneralSettingsValues>({
    queryKey: ['/api/settings/general'],
    enabled: brokersConnected,
  });
  
  const { 
    data: apiSettings, 
    isLoading: isLoadingApiSettings 
  } = useQuery<ApiSettingsValues>({
    queryKey: ['/api/settings/api'],
    enabled: brokersConnected,
  });
  
  // General settings form
  const generalForm = useForm<GeneralSettingsValues>({
    resolver: zodResolver(generalSettingsSchema),
    defaultValues: {
      timezone: "America/New_York",
      dateFormat: "MM/DD/YYYY",
      timeFormat: "12h",
      copyTradeDelay: 0,
      defaultTradingHours: {
        start: "09:30",
        end: "16:00",
      },
      autoRefresh: true,
      refreshInterval: 30,
    },
  });
  
  // API settings form
  const apiForm = useForm<ApiSettingsValues>({
    resolver: zodResolver(apiSettingsSchema),
    defaultValues: {
      webhookEnabled: false,
      webhookUrl: "",
      webhookSecret: "",
    },
  });
  
  // Set form values when settings are loaded
  useState(() => {
    if (generalSettings) {
      generalForm.reset(generalSettings);
    }
    
    if (apiSettings) {
      apiForm.reset(apiSettings);
    }
  });
  
  // Update general settings mutation
  const updateGeneralSettingsMutation = useMutation({
    mutationFn: (data: GeneralSettingsValues) => {
      return apiRequest("PUT", "/api/settings/general", data);
    },
    onSuccess: () => {
      toast({
        title: "Settings updated",
        description: "General settings have been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/settings/general'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update settings",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Update API settings mutation
  const updateApiSettingsMutation = useMutation({
    mutationFn: (data: ApiSettingsValues) => {
      return apiRequest("PUT", "/api/settings/api", data);
    },
    onSuccess: () => {
      toast({
        title: "API settings updated",
        description: "API settings have been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/settings/api'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update API settings",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Test webhook mutation
  const testWebhookMutation = useMutation({
    mutationFn: () => {
      return apiRequest("POST", "/api/settings/test-webhook", {});
    },
    onSuccess: () => {
      toast({
        title: "Webhook test sent",
        description: "A test webhook payload has been sent successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Webhook test failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Reset platform mutation
  const resetPlatformMutation = useMutation({
    mutationFn: () => {
      return apiRequest("POST", "/api/settings/reset", {});
    },
    onSuccess: () => {
      toast({
        title: "Platform reset",
        description: "All settings and data have been reset to defaults",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 2000);
    },
    onError: (error) => {
      toast({
        title: "Reset failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Handle general settings form submission
  const onSubmitGeneralSettings = (data: GeneralSettingsValues) => {
    updateGeneralSettingsMutation.mutate(data);
  };
  
  // Handle API settings form submission
  const onSubmitApiSettings = (data: ApiSettingsValues) => {
    updateApiSettingsMutation.mutate(data);
  };
  
  // Handle platform reset
  const handleResetPlatform = () => {
    resetPlatformMutation.mutate();
  };

  if (isLoadingBrokerStatus) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  if (!brokersConnected) {
    return (
      <Card className="p-8 text-center">
        <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-slate-100 dark:bg-slate-700 mb-4">
          <SettingsIcon className="h-10 w-10 text-slate-500 dark:text-slate-400" />
        </div>
        <h3 className="text-lg font-medium text-slate-900 dark:text-slate-100 mb-2">Broker Connection Required</h3>
        <p className="text-slate-500 dark:text-slate-400 mb-4 max-w-md mx-auto">
          Platform settings require an active broker connection. Please connect your brokerage account first.
        </p>
        <Button onClick={() => setShowAccountModal(true)}>
          <LinkIcon className="h-4 w-4 mr-2" />
          Connect Broker
        </Button>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid grid-cols-2 w-[400px]">
          <TabsTrigger value="general">General Settings</TabsTrigger>
          <TabsTrigger value="api">API & Webhooks</TabsTrigger>
        </TabsList>
        
        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>
                Configure global platform settings
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingGeneralSettings ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : (
                <Form {...generalForm}>
                  <form onSubmit={generalForm.handleSubmit(onSubmitGeneralSettings)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-6">
                        <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-md">
                          <h3 className="flex items-center text-base font-medium mb-4">
                            <Globe className="h-5 w-5 mr-2 text-blue-600 dark:text-blue-500" />
                            Region & Format
                          </h3>
                          
                          <div className="space-y-4">
                            <FormField
                              control={generalForm.control}
                              name="timezone"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Timezone</FormLabel>
                                  <Select 
                                    onValueChange={field.onChange} 
                                    defaultValue={field.value}
                                  >
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select timezone" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="America/New_York">America/New_York (EST/EDT)</SelectItem>
                                      <SelectItem value="America/Chicago">America/Chicago (CST/CDT)</SelectItem>
                                      <SelectItem value="America/Denver">America/Denver (MST/MDT)</SelectItem>
                                      <SelectItem value="America/Los_Angeles">America/Los_Angeles (PST/PDT)</SelectItem>
                                      <SelectItem value="Europe/London">Europe/London (GMT/BST)</SelectItem>
                                      <SelectItem value="Europe/Paris">Europe/Paris (CET/CEST)</SelectItem>
                                      <SelectItem value="Asia/Tokyo">Asia/Tokyo (JST)</SelectItem>
                                      <SelectItem value="Australia/Sydney">Australia/Sydney (AEST/AEDT)</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormDescription>
                                    All times will be displayed in this timezone
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={generalForm.control}
                              name="dateFormat"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Date Format</FormLabel>
                                  <Select 
                                    onValueChange={field.onChange} 
                                    defaultValue={field.value}
                                  >
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select date format" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                                      <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                                      <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={generalForm.control}
                              name="timeFormat"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Time Format</FormLabel>
                                  <Select 
                                    onValueChange={field.onChange} 
                                    defaultValue={field.value}
                                  >
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select time format" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="12h">12-hour (e.g. 2:30 PM)</SelectItem>
                                      <SelectItem value="24h">24-hour (e.g. 14:30)</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-6">
                        <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-md">
                          <h3 className="flex items-center text-base font-medium mb-4">
                            <Clock className="h-5 w-5 mr-2 text-green-600 dark:text-green-500" />
                            Trading Settings
                          </h3>
                          
                          <div className="space-y-4">
                            <FormField
                              control={generalForm.control}
                              name="copyTradeDelay"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Copy Trade Delay (ms)</FormLabel>
                                  <FormControl>
                                    <Input type="number" min="0" {...field} />
                                  </FormControl>
                                  <FormDescription>
                                    Optional delay between lead and follow trades (in milliseconds)
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <div className="grid grid-cols-2 gap-4">
                              <FormField
                                control={generalForm.control}
                                name="defaultTradingHours.start"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Trading Start Time</FormLabel>
                                    <FormControl>
                                      <Input type="time" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={generalForm.control}
                                name="defaultTradingHours.end"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Trading End Time</FormLabel>
                                    <FormControl>
                                      <Input type="time" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                          </div>
                        </div>
                        
                        <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-md">
                          <h3 className="flex items-center text-base font-medium mb-4">
                            <Database className="h-5 w-5 mr-2 text-purple-600 dark:text-purple-500" />
                            Data Refresh
                          </h3>
                          
                          <div className="space-y-4">
                            <FormField
                              control={generalForm.control}
                              name="autoRefresh"
                              render={({ field }) => (
                                <FormItem className="flex flex-row items-center justify-between space-y-0">
                                  <div className="space-y-0.5">
                                    <FormLabel>Auto Refresh</FormLabel>
                                    <FormDescription>
                                      Automatically refresh data
                                    </FormDescription>
                                  </div>
                                  <FormControl>
                                    <Switch
                                      checked={field.value}
                                      onCheckedChange={field.onChange}
                                    />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            
                            {generalForm.watch("autoRefresh") && (
                              <FormField
                                control={generalForm.control}
                                name="refreshInterval"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Refresh Interval (seconds)</FormLabel>
                                    <FormControl>
                                      <Input type="number" min="5" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <CardFooter className="flex justify-end border-t pt-6 px-0">
                      <Button 
                        type="submit"
                        disabled={updateGeneralSettingsMutation.isPending || !generalForm.formState.isDirty}
                      >
                        {updateGeneralSettingsMutation.isPending ? (
                          <>
                            <Save className="h-4 w-4 mr-2 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="h-4 w-4 mr-2" />
                            Save Settings
                          </>
                        )}
                      </Button>
                    </CardFooter>
                  </form>
                </Form>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="api">
          <Card>
            <CardHeader>
              <CardTitle>API & Webhook Settings</CardTitle>
              <CardDescription>
                Configure external integrations and API settings
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingApiSettings ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : (
                <Form {...apiForm}>
                  <form onSubmit={apiForm.handleSubmit(onSubmitApiSettings)} className="space-y-6">
                    <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-md">
                      <h3 className="flex items-center text-base font-medium mb-4">
                        <Key className="h-5 w-5 mr-2 text-blue-600 dark:text-blue-500" />
                        Webhook Integration
                      </h3>
                      
                      <div className="space-y-4">
                        <FormField
                          control={apiForm.control}
                          name="webhookEnabled"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between space-y-0">
                              <div className="space-y-0.5">
                                <FormLabel>Enable Webhooks</FormLabel>
                                <FormDescription>
                                  Send trade events to external services
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        {apiForm.watch("webhookEnabled") && (
                          <>
                            <FormField
                              control={apiForm.control}
                              name="webhookUrl"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Webhook URL</FormLabel>
                                  <FormControl>
                                    <Input placeholder="https://your-service.com/webhook" {...field} />
                                  </FormControl>
                                  <FormDescription>
                                    The URL where webhook events will be sent
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={apiForm.control}
                              name="webhookSecret"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Webhook Secret</FormLabel>
                                  <FormControl>
                                    <Input type="password" placeholder="Your webhook secret" {...field} />
                                  </FormControl>
                                  <FormDescription>
                                    Used to sign webhook payloads for verification
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <Button 
                              type="button" 
                              variant="outline" 
                              size="sm"
                              onClick={() => testWebhookMutation.mutate()}
                              disabled={testWebhookMutation.isPending || !apiForm.watch("webhookUrl")}
                            >
                              Send Test Webhook
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                    
                    <CardFooter className="flex justify-between border-t pt-6 px-0">
                      <Button 
                        type="button" 
                        variant="destructive"
                        onClick={() => setShowResetDialog(true)}
                      >
                        <AlertTriangle className="h-4 w-4 mr-2" />
                        Reset Platform
                      </Button>
                      
                      <Button 
                        type="submit"
                        disabled={updateApiSettingsMutation.isPending || !apiForm.formState.isDirty}
                      >
                        {updateApiSettingsMutation.isPending ? (
                          <>
                            <Save className="h-4 w-4 mr-2 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="h-4 w-4 mr-2" />
                            Save API Settings
                          </>
                        )}
                      </Button>
                    </CardFooter>
                  </form>
                </Form>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <AccountForm 
        open={showAccountModal} 
        onOpenChange={setShowAccountModal} 
      />
      
      <AlertDialog open={showResetDialog} onOpenChange={setShowResetDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action will reset the entire platform to its default state. All settings, connections, and data will be permanently deleted. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleResetPlatform}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={resetPlatformMutation.isPending}
            >
              {resetPlatformMutation.isPending ? "Resetting..." : "Reset Platform"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
