import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardFooter 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Separator } from "@/components/ui/separator";
import { AccountForm } from "@/components/ui/account-form";
import { 
  ShieldAlert, 
  LinkIcon, 
  RefreshCw, 
  AlertTriangle,
  Lock,
  DollarSign,
  Timer,
  Activity
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";

// Global risk settings schema
const globalRiskFormSchema = z.object({
  maxDailyLoss: z.coerce.number().min(0, "Must be a positive number"),
  maxPositionSize: z.coerce.number().min(0, "Must be a positive number"),
  maxPositionValue: z.coerce.number().min(0, "Must be a positive number"),
  maxLeverage: z.coerce.number().min(1, "Must be at least 1"),
  emergencyStopEnabled: z.boolean().default(false),
  enabledHours: z.object({
    start: z.string(),
    end: z.string(),
  }),
  enabledDays: z.array(z.string()).min(1, "At least one trading day must be selected"),
});

type GlobalRiskFormValues = z.infer<typeof globalRiskFormSchema>;

// Account specific risk settings schema
const accountRiskFormSchema = z.object({
  accountId: z.string().min(1, "Account is required"),
  maxDailyLoss: z.coerce.number().min(0, "Must be a positive number"),
  maxPositionSize: z.coerce.number().min(0, "Must be a positive number"),
  maxPositionValue: z.coerce.number().min(0, "Must be a positive number"),
  maxLeverage: z.coerce.number().min(1, "Must be at least 1"),
  enforceStopLoss: z.boolean().default(false),
  stopLossPercentage: z.coerce.number().min(0, "Must be a positive number").max(100, "Must be at most 100"),
});

type AccountRiskFormValues = z.infer<typeof accountRiskFormSchema>;

export default function RiskSettings() {
  const [showAccountModal, setShowAccountModal] = useState(false);
  const { toast } = useToast();
  
  const { 
    data: { brokersConnected = false } = {}, 
    isLoading: isLoadingBrokerStatus 
  } = useQuery<{brokersConnected: boolean}>({
    queryKey: ['/api/brokers/status'],
  });
  
  const { 
    data: brokers = [], 
    isLoading: isLoadingBrokers 
  } = useQuery<any[]>({
    queryKey: ['/api/brokers'],
    enabled: brokersConnected,
  });
  
  const { 
    data: globalRiskSettings,
    isLoading: isLoadingGlobalRisk 
  } = useQuery<GlobalRiskFormValues>({
    queryKey: ['/api/risk/settings/global'],
    enabled: brokersConnected,
  });
  
  const { 
    data: accountRiskSettings = [],
    isLoading: isLoadingAccountRisk 
  } = useQuery<any[]>({
    queryKey: ['/api/risk/settings/accounts'],
    enabled: brokersConnected,
  });
  
  const { 
    data: recentRiskEvents = [],
    isLoading: isLoadingRiskEvents 
  } = useQuery<any[]>({
    queryKey: ['/api/risk/events'],
    enabled: brokersConnected,
  });
  
  // Global risk settings form
  const globalRiskForm = useForm<GlobalRiskFormValues>({
    resolver: zodResolver(globalRiskFormSchema),
    defaultValues: {
      maxDailyLoss: 1000,
      maxPositionSize: 100,
      maxPositionValue: 10000,
      maxLeverage: 1,
      emergencyStopEnabled: false,
      enabledHours: {
        start: "09:30",
        end: "16:00",
      },
      enabledDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    },
  });
  
  // Account risk settings form
  const accountRiskForm = useForm<AccountRiskFormValues>({
    resolver: zodResolver(accountRiskFormSchema),
    defaultValues: {
      accountId: "",
      maxDailyLoss: 1000,
      maxPositionSize: 100,
      maxPositionValue: 10000,
      maxLeverage: 1,
      enforceStopLoss: false,
      stopLossPercentage: 10,
    },
  });
  
  // Set global risk form values when data is loaded
  useState(() => {
    if (globalRiskSettings) {
      globalRiskForm.reset(globalRiskSettings);
    }
  });
  
  // Update global risk settings mutation
  const updateGlobalRiskMutation = useMutation({
    mutationFn: (data: GlobalRiskFormValues) => {
      return apiRequest("PUT", "/api/risk/settings/global", data);
    },
    onSuccess: () => {
      toast({
        title: "Risk settings updated",
        description: "Global risk controls have been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/risk/settings/global'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update risk settings",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Update account risk settings mutation
  const updateAccountRiskMutation = useMutation({
    mutationFn: (data: AccountRiskFormValues) => {
      return apiRequest("PUT", `/api/risk/settings/accounts/${data.accountId}`, data);
    },
    onSuccess: () => {
      toast({
        title: "Risk settings updated",
        description: "Account risk controls have been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/risk/settings/accounts'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update risk settings",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Reset risk event mutation
  const resetRiskEventMutation = useMutation({
    mutationFn: (eventId: number) => {
      return apiRequest("POST", `/api/risk/events/${eventId}/reset`, {});
    },
    onSuccess: () => {
      toast({
        title: "Risk event reset",
        description: "The risk event has been reset successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/risk/events'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to reset risk event",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Emergency stop mutation
  const emergencyStopMutation = useMutation({
    mutationFn: (enabled: boolean) => {
      return apiRequest("POST", "/api/risk/emergency-stop", { enabled });
    },
    onSuccess: (_, variables) => {
      toast({
        title: variables ? "Emergency stop activated" : "Emergency stop deactivated",
        description: variables
          ? "All trading has been stopped"
          : "Trading can now resume",
        variant: variables ? "destructive" : "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/risk/settings/global'] });
    },
    onError: (error) => {
      toast({
        title: "Emergency stop failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Handle global risk form submission
  const onSubmitGlobalRiskForm = (data: GlobalRiskFormValues) => {
    updateGlobalRiskMutation.mutate(data);
  };
  
  // Handle account risk form submission
  const onSubmitAccountRiskForm = (data: AccountRiskFormValues) => {
    updateAccountRiskMutation.mutate(data);
  };
  
  // Format risk event type for display
  const formatRiskEventType = (type: string) => {
    switch (type) {
      case "maxDailyLoss":
        return "Max Daily Loss";
      case "maxPositionSize":
        return "Max Position Size";
      case "maxPositionValue":
        return "Max Position Value";
      case "maxLeverage":
        return "Max Leverage";
      case "stopLoss":
        return "Stop Loss";
      case "emergencyStop":
        return "Emergency Stop";
      case "outOfHours":
        return "Out of Trading Hours";
      default:
        return type;
    }
  };

  if (isLoadingBrokerStatus) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  if (!brokersConnected) {
    return (
      <Card className="p-8 text-center">
        <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-slate-100 dark:bg-slate-700 mb-4">
          <ShieldAlert className="h-10 w-10 text-slate-500 dark:text-slate-400" />
        </div>
        <h3 className="text-lg font-medium text-slate-900 dark:text-slate-100 mb-2">Broker Connection Required</h3>
        <p className="text-slate-500 dark:text-slate-400 mb-4 max-w-md mx-auto">
          Risk settings require an active broker connection. Please connect your brokerage account first.
        </p>
        <Button onClick={() => setShowAccountModal(true)}>
          <LinkIcon className="h-4 w-4 mr-2" />
          Connect Broker
        </Button>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Risk Management</h1>
          <p className="text-slate-500 dark:text-slate-400">
            Configure risk controls to protect your trading accounts
          </p>
        </div>
        
        <Card className={`p-2 ${globalRiskSettings?.emergencyStopEnabled ? 'bg-red-100 dark:bg-red-900 border-red-300 dark:border-red-700' : ''}`}>
          <Button 
            variant={globalRiskSettings?.emergencyStopEnabled ? "destructive" : "outline"}
            size="lg"
            className="gap-2"
            onClick={() => {
              if (globalRiskSettings) {
                emergencyStopMutation.mutate(!globalRiskSettings.emergencyStopEnabled);
              }
            }}
            disabled={emergencyStopMutation.isPending}
          >
            {globalRiskSettings?.emergencyStopEnabled ? (
              <>
                <Lock className="h-5 w-5" />
                <span>Emergency Stop Active</span>
              </>
            ) : (
              <>
                <AlertTriangle className="h-5 w-5" />
                <span>Activate Emergency Stop</span>
              </>
            )}
          </Button>
        </Card>
      </div>
      
      <Tabs defaultValue="global" className="space-y-6">
        <TabsList className="grid grid-cols-3 w-[400px]">
          <TabsTrigger value="global">Global Settings</TabsTrigger>
          <TabsTrigger value="accounts">Account Settings</TabsTrigger>
          <TabsTrigger value="events">Risk Events</TabsTrigger>
        </TabsList>
        
        <TabsContent value="global" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Global Risk Controls</CardTitle>
              <CardDescription>
                These settings apply to all accounts unless overridden by account-specific settings
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingGlobalRisk ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : (
                <Form {...globalRiskForm}>
                  <form onSubmit={globalRiskForm.handleSubmit(onSubmitGlobalRiskForm)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-6">
                        <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-md">
                          <h3 className="flex items-center text-base font-medium mb-4">
                            <DollarSign className="h-5 w-5 mr-2 text-green-600 dark:text-green-500" />
                            Financial Limits
                          </h3>
                          
                          <div className="space-y-4">
                            <FormField
                              control={globalRiskForm.control}
                              name="maxDailyLoss"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Maximum Daily Loss ($)</FormLabel>
                                  <FormControl>
                                    <Input type="number" {...field} />
                                  </FormControl>
                                  <FormDescription>
                                    Stop trading if daily loss exceeds this amount
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={globalRiskForm.control}
                              name="maxPositionValue"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Maximum Position Value ($)</FormLabel>
                                  <FormControl>
                                    <Input type="number" {...field} />
                                  </FormControl>
                                  <FormDescription>
                                    Maximum value for any single position
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={globalRiskForm.control}
                              name="maxLeverage"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Maximum Leverage</FormLabel>
                                  <FormControl>
                                    <Input type="number" min="1" step="0.1" {...field} />
                                  </FormControl>
                                  <FormDescription>
                                    Maximum allowed leverage ratio (1 = no leverage)
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                        
                        <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-md">
                          <h3 className="flex items-center text-base font-medium mb-4">
                            <Activity className="h-5 w-5 mr-2 text-purple-600 dark:text-purple-500" />
                            Position Controls
                          </h3>
                          
                          <FormField
                            control={globalRiskForm.control}
                            name="maxPositionSize"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Maximum Position Size</FormLabel>
                                <FormControl>
                                  <Input type="number" {...field} />
                                </FormControl>
                                <FormDescription>
                                  Maximum number of shares/contracts per position
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-6">
                        <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-md">
                          <h3 className="flex items-center text-base font-medium mb-4">
                            <Timer className="h-5 w-5 mr-2 text-blue-600 dark:text-blue-500" />
                            Trading Hours
                          </h3>
                          
                          <div className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              <FormField
                                control={globalRiskForm.control}
                                name="enabledHours.start"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Start Time</FormLabel>
                                    <FormControl>
                                      <Input type="time" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={globalRiskForm.control}
                                name="enabledHours.end"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>End Time</FormLabel>
                                    <FormControl>
                                      <Input type="time" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                            
                            <FormField
                              control={globalRiskForm.control}
                              name="enabledDays"
                              render={() => (
                                <FormItem>
                                  <div className="mb-2">
                                    <FormLabel>Trading Days</FormLabel>
                                  </div>
                                  <div className="flex flex-wrap gap-2">
                                    {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map((day) => (
                                      <FormField
                                        key={day}
                                        control={globalRiskForm.control}
                                        name="enabledDays"
                                        render={({ field }) => {
                                          return (
                                            <FormItem
                                              key={day}
                                              className="flex flex-row items-center space-x-1 space-y-0"
                                            >
                                              <FormControl>
                                                <input
                                                  type="checkbox"
                                                  className="peer h-4 w-4 rounded border border-slate-300 text-primary focus:ring-primary"
                                                  checked={field.value?.includes(day)}
                                                  onChange={(event) => {
                                                    const checked = event.target.checked;
                                                    const updatedValue = checked
                                                      ? [...field.value, day]
                                                      : field.value?.filter(
                                                          (value) => value !== day
                                                        );
                                                    field.onChange(updatedValue);
                                                  }}
                                                />
                                              </FormControl>
                                              <FormLabel className="text-sm font-normal">
                                                {day}
                                              </FormLabel>
                                            </FormItem>
                                          );
                                        }}
                                      />
                                    ))}
                                  </div>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                        
                        <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-md">
                          <h3 className="flex items-center text-base font-medium mb-4">
                            <ShieldAlert className="h-5 w-5 mr-2 text-red-600 dark:text-red-500" />
                            Emergency Controls
                          </h3>
                          
                          <FormField
                            control={globalRiskForm.control}
                            name="emergencyStopEnabled"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                                <div className="space-y-0.5">
                                  <FormLabel className="text-base">
                                    Emergency Stop
                                  </FormLabel>
                                  <FormDescription>
                                    Automatically halt all trading activity
                                  </FormDescription>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={(value) => {
                                      field.onChange(value);
                                      // Update immediately
                                      emergencyStopMutation.mutate(value);
                                    }}
                                    disabled={emergencyStopMutation.isPending}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                    </div>
                    
                    <CardFooter className="flex justify-end border-t pt-6 px-0">
                      <Button 
                        type="submit"
                        disabled={updateGlobalRiskMutation.isPending || !globalRiskForm.formState.isDirty}
                      >
                        {updateGlobalRiskMutation.isPending ? "Saving..." : "Save Global Settings"}
                      </Button>
                    </CardFooter>
                  </form>
                </Form>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="accounts" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Account-Specific Risk Controls</CardTitle>
              <CardDescription>
                Configure risk settings for individual trading accounts
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingBrokers || isLoadingAccountRisk ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : brokers.length === 0 ? (
                <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                  No broker accounts available. Please add a broker first.
                </div>
              ) : (
                <div className="space-y-6">
                  <Form {...accountRiskForm}>
                    <form onSubmit={accountRiskForm.handleSubmit(onSubmitAccountRiskForm)} className="space-y-6">
                      <FormField
                        control={accountRiskForm.control}
                        name="accountId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Select Account</FormLabel>
                            <Select 
                              onValueChange={(value) => {
                                field.onChange(value);
                                // Fill form with existing settings for the selected account
                                const accountSettings = accountRiskSettings.find(
                                  settings => settings.accountId.toString() === value
                                );
                                if (accountSettings) {
                                  accountRiskForm.reset({
                                    accountId: value,
                                    maxDailyLoss: accountSettings.maxDailyLoss,
                                    maxPositionSize: accountSettings.maxPositionSize,
                                    maxPositionValue: accountSettings.maxPositionValue,
                                    maxLeverage: accountSettings.maxLeverage,
                                    enforceStopLoss: accountSettings.enforceStopLoss,
                                    stopLossPercentage: accountSettings.stopLossPercentage,
                                  });
                                } else {
                                  // Reset to defaults if no settings exist
                                  accountRiskForm.reset({
                                    accountId: value,
                                    maxDailyLoss: 1000,
                                    maxPositionSize: 100,
                                    maxPositionValue: 10000,
                                    maxLeverage: 1,
                                    enforceStopLoss: false,
                                    stopLossPercentage: 10,
                                  });
                                }
                              }} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select an account" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {brokers.map((broker) => (
                                  <SelectItem key={broker.id} value={broker.id.toString()}>
                                    {broker.type === 'schwab' ? 'Charles Schwab' : 'Tastytrade'} {broker.accountId}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Choose an account to configure risk settings
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      {accountRiskForm.watch("accountId") && (
                        <>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-4">
                              <FormField
                                control={accountRiskForm.control}
                                name="maxDailyLoss"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Maximum Daily Loss ($)</FormLabel>
                                    <FormControl>
                                      <Input type="number" {...field} />
                                    </FormControl>
                                    <FormDescription>
                                      Stop trading if daily loss exceeds this amount
                                    </FormDescription>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={accountRiskForm.control}
                                name="maxPositionSize"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Maximum Position Size</FormLabel>
                                    <FormControl>
                                      <Input type="number" {...field} />
                                    </FormControl>
                                    <FormDescription>
                                      Maximum number of shares/contracts per position
                                    </FormDescription>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                            
                            <div className="space-y-4">
                              <FormField
                                control={accountRiskForm.control}
                                name="maxPositionValue"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Maximum Position Value ($)</FormLabel>
                                    <FormControl>
                                      <Input type="number" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={accountRiskForm.control}
                                name="maxLeverage"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Maximum Leverage</FormLabel>
                                    <FormControl>
                                      <Input type="number" min="1" step="0.1" {...field} />
                                    </FormControl>
                                    <FormDescription>
                                      Maximum allowed leverage ratio
                                    </FormDescription>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </div>
                          </div>
                          
                          <FormField
                            control={accountRiskForm.control}
                            name="enforceStopLoss"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                                <div className="space-y-0.5">
                                  <FormLabel className="text-base">
                                    Enforce Stop Loss
                                  </FormLabel>
                                  <FormDescription>
                                    Automatically apply stop loss to all positions
                                  </FormDescription>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          
                          {accountRiskForm.watch("enforceStopLoss") && (
                            <FormField
                              control={accountRiskForm.control}
                              name="stopLossPercentage"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Stop Loss Percentage (%)</FormLabel>
                                  <FormControl>
                                    <Input type="number" min="0" max="100" {...field} />
                                  </FormControl>
                                  <FormDescription>
                                    Close position when loss exceeds this percentage
                                  </FormDescription>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          )}
                          
                          <CardFooter className="flex justify-end border-t pt-6 px-0">
                            <Button 
                              type="submit"
                              disabled={updateAccountRiskMutation.isPending || !accountRiskForm.formState.isDirty}
                            >
                              {updateAccountRiskMutation.isPending ? "Saving..." : "Save Account Settings"}
                            </Button>
                          </CardFooter>
                        </>
                      )}
                    </form>
                  </Form>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="events" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Risk Events Log</CardTitle>
              <CardDescription>
                View and manage risk events that have occurred
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingRiskEvents ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : recentRiskEvents.length === 0 ? (
                <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                  No risk events have been logged
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date & Time</TableHead>
                        <TableHead>Event Type</TableHead>
                        <TableHead>Account</TableHead>
                        <TableHead>Symbol</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {recentRiskEvents.map((event) => (
                        <TableRow key={event.id}>
                          <TableCell>
                            {new Date(event.timestamp).toLocaleString()}
                          </TableCell>
                          <TableCell>
                            {formatRiskEventType(event.type)}
                          </TableCell>
                          <TableCell>
                            {event.accountId ? (
                              brokers.find(b => b.id === event.accountId)?.type === 'schwab' ? 'CS' : 'TT'
                            ) : (
                              'Global'
                            )} {event.accountId && brokers.find(b => b.id === event.accountId)?.accountId.slice(-4)}
                          </TableCell>
                          <TableCell className="font-mono">
                            {event.symbol || '—'}
                          </TableCell>
                          <TableCell>
                            {event.description}
                          </TableCell>
                          <TableCell>
                            <Badge variant={event.active ? "destructive" : "success"}>
                              {event.active ? "Active" : "Resolved"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {event.active && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => resetRiskEventMutation.mutate(event.id)}
                                disabled={resetRiskEventMutation.isPending}
                              >
                                Reset
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <AccountForm 
        open={showAccountModal} 
        onOpenChange={setShowAccountModal} 
      />
    </div>
  );
}
