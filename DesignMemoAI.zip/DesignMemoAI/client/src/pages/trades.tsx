import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { AccountForm } from "@/components/ui/account-form";
import { Search, Calendar as CalendarIcon, History, RefreshCw, Download, LinkIcon } from "lucide-react";
import { format } from "date-fns";
import { formatCurrency, getActionLabel, getOrderTypeLabel } from "@/lib/utils";

export default function Trades() {
  const [showAccountModal, setShowAccountModal] = useState(false);
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [accountFilter, setAccountFilter] = useState<string>("all");
  const [openPositionsTab, setOpenPositionsTab] = useState<string>("all");
  
  const { 
    data: { brokersConnected = false } = {}, 
    isLoading: isLoadingBrokerStatus 
  } = useQuery<{brokersConnected: boolean}>({
    queryKey: ['/api/brokers/status'],
  });
  
  const { 
    data: brokers = [], 
    isLoading: isLoadingBrokers 
  } = useQuery<any[]>({
    queryKey: ['/api/brokers'],
    enabled: brokersConnected,
  });
  
  const { 
    data: orders = [], 
    isLoading: isLoadingOrders,
    refetch: refetchOrders 
  } = useQuery<any[]>({
    queryKey: ['/api/trading/orders'],
    enabled: brokersConnected,
  });
  
  const { 
    data: positions = [], 
    isLoading: isLoadingPositions,
    refetch: refetchPositions
  } = useQuery<any[]>({
    queryKey: ['/api/trading/positions'],
    enabled: brokersConnected,
  });
  
  const filteredOrders = orders.filter(order => {
    let matches = true;
    
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      matches = matches && (
        order.symbol.toLowerCase().includes(query) ||
        order.orderId.toLowerCase().includes(query)
      );
    }
    
    // Apply status filter
    if (statusFilter !== "all") {
      matches = matches && order.status === statusFilter;
    }
    
    // Apply account filter
    if (accountFilter !== "all") {
      matches = matches && order.accountId.toString() === accountFilter;
    }
    
    return matches;
  });
  
  const filteredPositions = positions.filter(position => {
    // Apply account filter
    if (accountFilter !== "all") {
      return position.accountId.toString() === accountFilter;
    }
    
    // Apply position type filter (stocks vs options)
    if (openPositionsTab !== "all") {
      return position.type === openPositionsTab;
    }
    
    return true;
  });
  
  // Format date for display
  const formattedDate = date ? format(date, "PPP") : "Select date";
  
  const getBadgeVariant = (status: string) => {
    switch (status.toLowerCase()) {
      case "filled":
        return "success";
      case "partially_filled":
        return "warning";
      case "open":
      case "pending":
        return "secondary";
      case "canceled":
      case "rejected":
        return "destructive";
      default:
        return "outline";
    }
  };
  
  const positionPnlColor = (pnl: number) => {
    if (pnl > 0) return "text-green-600 dark:text-green-400";
    if (pnl < 0) return "text-red-600 dark:text-red-400";
    return "";
  };

  if (isLoadingBrokerStatus) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  if (!brokersConnected) {
    return (
      <Card className="p-8 text-center">
        <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-slate-100 dark:bg-slate-700 mb-4">
          <History className="h-10 w-10 text-slate-500 dark:text-slate-400" />
        </div>
        <h3 className="text-lg font-medium text-slate-900 dark:text-slate-100 mb-2">Broker Connection Required</h3>
        <p className="text-slate-500 dark:text-slate-400 mb-4 max-w-md mx-auto">
          Trade history requires an active broker connection. Please connect your brokerage account first.
        </p>
        <Button onClick={() => setShowAccountModal(true)}>
          <LinkIcon className="h-4 w-4 mr-2" />
          Connect Broker
        </Button>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <CardTitle>Trade History</CardTitle>
              <CardDescription>
                View and filter your trade history
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => {
                refetchOrders();
                refetchPositions();
              }}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="orders" className="space-y-4">
            <TabsList>
              <TabsTrigger value="orders">Orders</TabsTrigger>
              <TabsTrigger value="positions">Open Positions</TabsTrigger>
            </TabsList>
            
            <div className="flex flex-col md:flex-row gap-4 items-end">
              <div className="grid gap-2 flex-1">
                <label htmlFor="search" className="text-sm font-medium">Search</label>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-500 dark:text-slate-400" />
                  <Input
                    id="search"
                    type="search"
                    placeholder="Search by symbol or order ID"
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="grid gap-2 w-full md:w-[200px]">
                <label htmlFor="account" className="text-sm font-medium">Account</label>
                <Select
                  value={accountFilter}
                  onValueChange={setAccountFilter}
                >
                  <SelectTrigger id="account">
                    <SelectValue placeholder="All accounts" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All accounts</SelectItem>
                    {brokers.map((broker) => (
                      <SelectItem key={broker.id} value={broker.id.toString()}>
                        {broker.type === 'schwab' ? 'Charles Schwab' : 'Tastytrade'} {broker.accountId}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2 w-full md:w-[180px]">
                <label htmlFor="status" className="text-sm font-medium">Status</label>
                <Select
                  value={statusFilter}
                  onValueChange={setStatusFilter}
                >
                  <SelectTrigger id="status">
                    <SelectValue placeholder="All statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All statuses</SelectItem>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="filled">Filled</SelectItem>
                    <SelectItem value="partially_filled">Partially Filled</SelectItem>
                    <SelectItem value="canceled">Canceled</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2 w-full md:w-[240px]">
                <label htmlFor="date" className="text-sm font-medium">Date</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      id="date"
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formattedDate}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            
            <TabsContent value="orders" className="space-y-4">
              {isLoadingOrders ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : filteredOrders.length === 0 ? (
                <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                  No orders found matching your criteria
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date & Time</TableHead>
                        <TableHead>Symbol</TableHead>
                        <TableHead>Action</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Account</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredOrders.map((order) => (
                        <TableRow key={order.id}>
                          <TableCell>
                            {new Date(order.createdAt).toLocaleString()}
                          </TableCell>
                          <TableCell className="font-mono font-medium">
                            {order.symbol}
                          </TableCell>
                          <TableCell>
                            <span className={order.action.toLowerCase().includes('buy') ? 'text-green-600 dark:text-green-500' : 'text-red-600 dark:text-red-500'}>
                              {getActionLabel(order.action)}
                            </span>
                          </TableCell>
                          <TableCell>
                            {getOrderTypeLabel(order.orderType)}
                          </TableCell>
                          <TableCell>
                            {order.quantity}
                          </TableCell>
                          <TableCell>
                            {order.price ? formatCurrency(order.price) : 'Market'}
                          </TableCell>
                          <TableCell>
                            <Badge variant={getBadgeVariant(order.status)}>
                              {order.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {brokers.find(b => b.id === order.accountId)?.type === 'schwab' ? 'CS' : 'TT'} {brokers.find(b => b.id === order.accountId)?.accountId.slice(-4)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="positions" className="space-y-4">
              <div className="flex justify-start mb-4">
                <TabsList>
                  <TabsTrigger 
                    value="all" 
                    onClick={() => setOpenPositionsTab('all')}
                    className={openPositionsTab === 'all' ? 'bg-primary text-white' : ''}
                  >
                    All
                  </TabsTrigger>
                  <TabsTrigger 
                    value="stock" 
                    onClick={() => setOpenPositionsTab('stock')}
                    className={openPositionsTab === 'stock' ? 'bg-primary text-white' : ''}
                  >
                    Stocks
                  </TabsTrigger>
                  <TabsTrigger 
                    value="option" 
                    onClick={() => setOpenPositionsTab('option')}
                    className={openPositionsTab === 'option' ? 'bg-primary text-white' : ''}
                  >
                    Options
                  </TabsTrigger>
                </TabsList>
              </div>
              
              {isLoadingPositions ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : filteredPositions.length === 0 ? (
                <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                  No open positions found
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Symbol</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead>Avg. Cost</TableHead>
                        <TableHead>Current Price</TableHead>
                        <TableHead>Market Value</TableHead>
                        <TableHead>Unrealized P&L</TableHead>
                        <TableHead>Account</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPositions.map((position) => (
                        <TableRow key={position.id}>
                          <TableCell className="font-mono font-medium">
                            {position.symbol}
                          </TableCell>
                          <TableCell>
                            {position.type === 'stock' ? 'Stock' : 'Option'}
                          </TableCell>
                          <TableCell>
                            {position.quantity}
                          </TableCell>
                          <TableCell>
                            {formatCurrency(position.averageCost)}
                          </TableCell>
                          <TableCell>
                            {formatCurrency(position.currentPrice)}
                          </TableCell>
                          <TableCell>
                            {formatCurrency(position.marketValue)}
                          </TableCell>
                          <TableCell className={positionPnlColor(position.unrealizedPnl)}>
                            {formatCurrency(position.unrealizedPnl)} ({position.unrealizedPnlPercent}%)
                          </TableCell>
                          <TableCell>
                            {brokers.find(b => b.id === position.accountId)?.type === 'schwab' ? 'CS' : 'TT'} {brokers.find(b => b.id === position.accountId)?.accountId.slice(-4)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      <AccountForm 
        open={showAccountModal} 
        onOpenChange={setShowAccountModal} 
      />
    </div>
  );
}
