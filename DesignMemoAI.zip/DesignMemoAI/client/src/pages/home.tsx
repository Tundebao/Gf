import { useEffect } from "react";
import { useLocation } from "wouter";

export default function Home() {
  const [_, navigate] = useLocation();
  
  // Redirect to dashboard
  useEffect(() => {
    navigate("/dashboard");
  }, [navigate]);
  
  return null;
}
