import { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TradingForm } from "@/components/ui/trading-form";
import { AccountForm } from "@/components/ui/account-form";
import { useQuery } from "@tanstack/react-query";
import { BarChart2, LinkIcon, RefreshCw } from "lucide-react";
import { useBrokerStatus } from "@/hooks/use-broker-status";

export default function ManualTrading() {
  const [showAccountModal, setShowAccountModal] = useState(false);
  
  // Use the centralized broker status hook
  const { isBrokerConnected, isLoading: isLoadingBrokerStatus } = useBrokerStatus();
  
  const { 
    data: symbolInfo = null, 
    isLoading: isLoadingSymbol 
  } = useQuery<any>({
    queryKey: ['/api/symbols/AAPL'],
    enabled: false, // Only load when user enters a symbol
  });
  
  const { 
    data: accountSummary = null, 
    isLoading: isLoadingAccount 
  } = useQuery<any>({
    queryKey: ['/api/brokers/summary'],
    enabled: false, // Load when account is selected
  });

  return (
    <div className="space-y-6">
      {isLoadingBrokerStatus ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      ) : !isBrokerConnected ? (
        <Card className="p-8 text-center">
          <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-slate-100 dark:bg-slate-700 mb-4">
            <BarChart2 className="h-10 w-10 text-slate-500 dark:text-slate-400" />
          </div>
          <h3 className="text-lg font-medium text-slate-900 dark:text-slate-100 mb-2">Broker Connection Required</h3>
          <p className="text-slate-500 dark:text-slate-400 mb-4 max-w-md mx-auto">
            Manual trading requires an active broker connection. Please connect your brokerage account first.
          </p>
          <Button onClick={() => setShowAccountModal(true)}>
            <LinkIcon className="h-4 w-4 mr-2" />
            Connect Broker
          </Button>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <TradingForm />
          </div>
          
          <div className="space-y-6">
            {/* Symbol Info */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Symbol Info</CardTitle>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="h-8"
                >
                  <RefreshCw className="h-3 w-3 mr-2" />
                  Refresh
                </Button>
              </CardHeader>
              <CardContent>
                <div className="p-2 text-center">
                  <p className="text-slate-500 dark:text-slate-400">Enter a symbol above to see market data</p>
                </div>
              </CardContent>
            </Card>
            
            {/* Account Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Account Summary</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y divide-slate-200 dark:divide-slate-700">
                  <div className="px-4 py-3 flex justify-between">
                    <span className="text-sm text-slate-500 dark:text-slate-400">Cash Balance</span>
                    <span className="text-sm font-medium">$0.00</span>
                  </div>
                  <div className="px-4 py-3 flex justify-between">
                    <span className="text-sm text-slate-500 dark:text-slate-400">Buying Power</span>
                    <span className="text-sm font-medium">$0.00</span>
                  </div>
                  <div className="px-4 py-3 flex justify-between">
                    <span className="text-sm text-slate-500 dark:text-slate-400">Day Trades</span>
                    <span className="text-sm font-medium">0/3</span>
                  </div>
                  <div className="px-4 py-3 flex justify-between">
                    <span className="text-sm text-slate-500 dark:text-slate-400">Today's P&L</span>
                    <span className="text-sm font-medium text-green-600 dark:text-green-400">+$0.00</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
      
      <AccountForm 
        open={showAccountModal} 
        onOpenChange={setShowAccountModal} 
      />
    </div>
  );
}
