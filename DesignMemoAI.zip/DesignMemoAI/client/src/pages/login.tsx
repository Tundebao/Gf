import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/context/AuthContext";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Lock, AlertCircle } from "lucide-react";

// Define form validation schema
const loginFormSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

type LoginFormValues = z.infer<typeof loginFormSchema>;

export default function Login() {
  const { login, error, clearError } = useAuth();
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginFormSchema),
    defaultValues: {
      username: "admin",
      password: "admin",
    },
  });

  // Reset form errors when auth context error changes
  useEffect(() => {
    if (error) {
      console.log("Auth error detected:", error);
    }
  }, [error]);

  async function onSubmit(data: LoginFormValues) {
    try {
      // Clear any previous errors
      clearError?.();
      setIsLoading(true);
      
      console.log("Logging in with credentials:", data.username);
      
      // Make direct fetch request to login
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: data.username,
          password: data.password
        }),
        credentials: 'include'
      });
      
      const responseData = await response.json();
      console.log("Login response:", responseData);
      
      if (!response.ok) {
        throw new Error(responseData.message || 'Login failed');
      }
      
      // Save token to localStorage
      localStorage.setItem('token', responseData.token);
      console.log('Login successful, saved token:', responseData.token);
      
      // IMPORTANT: Route through our special redirect page
      // which has multiple fallback mechanisms to ensure we reach the dashboard
      console.log('🚀 HARD REDIRECT: Routing through special redirect page...');
      
      // Use our special redirect page that has multiple fallback mechanisms
      window.location.href = '/redirect-to-dashboard';
    } catch (error: any) {
      // Display error
      console.error("Login form error:", error);
      setIsLoading(false);
      form.setError("root", { 
        message: error.message || "Login failed. Please check your credentials."
      });
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="w-12 h-12 rounded-full flex items-center justify-center bg-primary text-white">
              <Lock className="h-6 w-6" />
            </div>
          </div>
          <CardTitle className="text-2xl">TradeCopy Pro</CardTitle>
          <CardDescription>
            Sign in to access your copy trading platform
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4 mr-2" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              {form.formState.errors.root && (
                <Alert variant="destructive" className="mb-4">
                  <AlertCircle className="h-4 w-4 mr-2" />
                  <AlertDescription>{form.formState.errors.root.message}</AlertDescription>
                </Alert>
              )}
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input placeholder="admin" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="••••••••" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Signing in...
                  </>
                ) : (
                  "Sign In"
                )}
              </Button>
              
              <div className="text-center text-sm text-muted-foreground">
                <p>Default login: admin / admin</p>
              </div>
            </form>
          </Form>
        </CardContent>
        <Separator />
        <CardFooter className="text-xs text-center text-slate-500 dark:text-slate-400 pt-4 flex flex-col">
          <div>Admin-only platform for stock and options copy trading</div>
          <div className="mt-1">© {new Date().getFullYear()} TradeCopy Pro</div>
        </CardFooter>
      </Card>
    </div>
  );
}
