import { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BrokerCard } from "@/components/ui/broker-card";
import { AccountForm } from "@/components/ui/account-form";
import { useQuery } from "@tanstack/react-query";
import { Banknote, Plus, RefreshCw } from "lucide-react";

export default function Accounts() {
  const [showAccountModal, setShowAccountModal] = useState(false);
  
  const { 
    data: brokers = [], 
    isLoading, 
    refetch,
    isRefetching
  } = useQuery<any[]>({
    queryKey: ['/api/brokers'],
  });
  
  const hasBrokers = brokers.length > 0;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Broker Connections</CardTitle>
            <CardDescription>
              Manage your connected brokerage accounts
            </CardDescription>
          </div>
          <Button onClick={() => setShowAccountModal(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Broker
          </Button>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
            </div>
          ) : !hasBrokers ? (
            <div className="text-center py-8">
              <div className="flex justify-center mb-4">
                <div className="bg-slate-100 dark:bg-slate-700 p-4 rounded-full">
                  <Banknote className="h-10 w-10 text-slate-400 dark:text-slate-500" />
                </div>
              </div>
              <h3 className="text-lg font-medium text-slate-900 dark:text-slate-100 mb-2">No Brokers Connected</h3>
              <p className="text-slate-500 dark:text-slate-400 mb-4 max-w-md mx-auto">
                To start trading, you need to connect your brokerage accounts. We support Charles Schwab and Tastytrade.
              </p>
              <Button onClick={() => setShowAccountModal(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Connect Broker
              </Button>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="flex justify-end">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => refetch()}
                  disabled={isRefetching}
                >
                  <RefreshCw className={`h-4 w-4 mr-2 ${isRefetching ? 'animate-spin' : ''}`} />
                  Refresh All
                </Button>
              </div>
              <div className="grid grid-cols-1 gap-6">
                {brokers.map((broker) => (
                  <BrokerCard key={broker.id} broker={broker} />
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      <AccountForm 
        open={showAccountModal} 
        onOpenChange={setShowAccountModal} 
        onSuccess={() => refetch()}
      />
    </div>
  );
}
