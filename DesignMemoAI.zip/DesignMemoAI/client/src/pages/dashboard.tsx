import { AccountOverview } from "@/components/Dashboard/AccountOverview";
import { QuickStats } from "@/components/Dashboard/QuickStats";
import { SystemActivity } from "@/components/Dashboard/SystemActivity";
import { useAuth } from "@/context/AuthContext";
import { useEffect } from "react";

export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();
  
  // Direct authentication verification - if not authenticated, redirect to login
  useEffect(() => {
    // Add a small delay to ensure everything is mounted
    const timeoutId = setTimeout(() => {
      if (!isAuthenticated) {
        console.log('Dashboard detected user not authenticated, redirecting to login');
        window.location.href = '/login';
      } else {
        console.log('Dashboard authenticated user:', user);
      }
    }, 300);
    
    return () => clearTimeout(timeoutId);
  }, [isAuthenticated, user]);

  return (
    <div className="space-y-6">
      <AccountOverview />
      <QuickStats />
      <SystemActivity />
    </div>
  );
}
