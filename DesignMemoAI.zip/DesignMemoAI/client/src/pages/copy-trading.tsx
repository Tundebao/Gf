import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getCopyTradingSettings, getCopyTradingStats, getCopyTradingLogs, updateCopyTradingSettings, testCopyTrade } from '@/lib/api';
import { useWebSocket } from '@/context/WebSocketContext';
import { useBrokerStatus } from '@/hooks/use-broker-status';

// Components
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';

// Icons
import { CheckCircle, AlertCircle, ArrowRight, Settings, LineChart, List, Clock, Copy, Users, RefreshCw, XCircle } from 'lucide-react';

// Copy trading settings form schema
const formSchema = z.object({
  enabled: z.boolean().default(false),
  copyMode: z.enum(['all', 'whitelist', 'blacklist']).default('all'),
  symbolWhitelist: z.string().optional(),
  symbolBlacklist: z.string().optional(),
  positionSizeType: z.enum(['fixed', 'percentage', 'proportional']).default('percentage'),
  positionSizeValue: z.coerce.number().nonnegative().default(100),
  maxPositionSize: z.coerce.number().nonnegative().default(0),
  delaySeconds: z.coerce.number().nonnegative().default(0),
  riskCheckEnabled: z.boolean().default(true),
  notificationsEnabled: z.boolean().default(true),
  forbidFollowerManualOrders: z.boolean().default(false)
});

// Copy trading status card for dashboard
const CopyTradingStatusCard = ({ stats }: { stats: any }) => {
  const isEnabled = stats?.settings?.enabled;
  
  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
        <CardTitle className="text-sm font-medium">
          Copy Trading System
        </CardTitle>
        {isEnabled ? (
          <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold bg-green-100 text-green-800 border-green-500">
            <CheckCircle className="w-3 h-3 mr-1" />
            Active
          </div>
        ) : (
          <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold bg-red-100 text-red-800 border-red-500">
            <XCircle className="w-3 h-3 mr-1" />
            Inactive
          </div>
        )}
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Leaders</p>
            <p className="text-lg font-bold">{stats?.brokers?.leaders?.connected || 0} / {stats?.brokers?.leaders?.total || 0}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Followers</p>
            <p className="text-lg font-bold">{stats?.brokers?.followers?.connected || 0} / {stats?.brokers?.followers?.total || 0}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Success Rate</p>
            <p className="text-lg font-bold">{stats?.copies?.successRate?.toFixed(1) || 0}%</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Total Copies</p>
            <p className="text-lg font-bold">{stats?.copies?.total || 0}</p>
          </div>
        </div>
        <Separator className="my-4" />
        <div className="space-y-2">
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Mode:</span>
            <span className="font-medium capitalize">{stats?.settings?.copyMode || 'All'}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// Recent copy trade log item component
const CopyTradeLogItem = ({ log }: { log: any }) => {
  // Status colors
  const statusColors: Record<string, { bg: string, text: string, icon: JSX.Element }> = {
    completed: {
      bg: 'bg-green-100',
      text: 'text-green-800',
      icon: <CheckCircle className="w-4 h-4 text-green-600" />
    },
    processing: {
      bg: 'bg-blue-100',
      text: 'text-blue-800',
      icon: <RefreshCw className="w-4 h-4 text-blue-600 animate-spin" />
    },
    error: {
      bg: 'bg-red-100',
      text: 'text-red-800',
      icon: <AlertCircle className="w-4 h-4 text-red-600" />
    },
    rejected: {
      bg: 'bg-orange-100',
      text: 'text-orange-800',
      icon: <XCircle className="w-4 h-4 text-orange-600" />
    },
    filtered: {
      bg: 'bg-gray-100',
      text: 'text-gray-800',
      icon: <AlertCircle className="w-4 h-4 text-gray-600" />
    },
    received: {
      bg: 'bg-purple-100',
      text: 'text-purple-800',
      icon: <Clock className="w-4 h-4 text-purple-600" />
    },
    skipped: {
      bg: 'bg-yellow-100',
      text: 'text-yellow-800',
      icon: <XCircle className="w-4 h-4 text-yellow-600" />
    }
  };
  
  const statusStyle = statusColors[log.status] || statusColors.processing;
  
  return (
    <div className="flex items-start space-x-4 p-4 border-b border-gray-100 hover:bg-gray-50">
      <div className="mt-0.5">{statusStyle.icon}</div>
      <div className="flex-1 space-y-1">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium">{log.symbol}</p>
          <div className={`px-2 py-1 rounded-full text-xs font-medium ${statusStyle.bg} ${statusStyle.text}`}>
            {log.status}
          </div>
        </div>
        <p className="text-sm text-gray-600">{log.message}</p>
        <div className="flex justify-between">
          <p className="text-xs text-gray-500">
            {new Date(log.timestamp).toLocaleString()}
          </p>
          {log.quantity && log.side && (
            <p className="text-xs font-medium">
              {log.side.toUpperCase()} {log.quantity}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

// Main copy trading page component
export default function CopyTradingPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('dashboard');
  const { connected, lastMessage } = useWebSocket();
  
  // Use the centralized broker status hook
  const { isBrokerConnected, isLoading: isLoadingBrokerStatus } = useBrokerStatus();
  
  // Fetch copy trading settings
  const { data: settings, isLoading: isLoadingSettings } = useQuery({
    queryKey: ['/api/copy-trading/settings'],
    retry: 1,
    enabled: isBrokerConnected // Only fetch if a broker is connected
  });

  // Fetch copy trading stats
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ['/api/copy-trading/stats'],
    refetchInterval: 10000, // Refresh every 10 seconds
    enabled: isBrokerConnected // Only fetch if a broker is connected
  });
  
  // Fetch copy trading logs
  const { data: logs, isLoading: isLoadingLogs } = useQuery({
    queryKey: ['/api/copy-trading/logs'],
    refetchInterval: 5000, // Refresh every 5 seconds
    enabled: isBrokerConnected // Only fetch if a broker is connected
  });
  
  // Handle WebSocket messages for real-time updates
  useEffect(() => {
    if (lastMessage) {
      const { type, data } = lastMessage;
      
      // Handle different message types
      switch (type) {
        case 'copy_trading_log':
          // Add new log to the top of the logs list and invalidate the query
          queryClient.setQueryData(['/api/copy-trading/logs'], (oldData: any) => {
            return [data, ...(oldData || [])];
          });
          break;
          
        case 'risk_event':
          // Show a toast notification for risk events
          toast({
            title: 'Risk Alert',
            description: data.description,
            variant: 'destructive'
          });
          break;
          
        case 'copy_trading_settings_updated':
          // Update the settings data
          queryClient.setQueryData(['/api/copy-trading/settings'], data);
          queryClient.invalidateQueries({ queryKey: ['/api/copy-trading/stats'] });
          break;
      }
    }
  }, [lastMessage, queryClient, toast]);
  
  // Form setup
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      enabled: false,
      copyMode: 'all',
      symbolWhitelist: '',
      symbolBlacklist: '',
      positionSizeType: 'percentage',
      positionSizeValue: 100,
      maxPositionSize: 0,
      delaySeconds: 0,
      riskCheckEnabled: true,
      notificationsEnabled: true,
      forbidFollowerManualOrders: false
    }
  });
  
  // Update form values when settings are loaded
  useEffect(() => {
    if (settings) {
      // Handle arrays for whitelist/blacklist
      const symbolWhitelist = Array.isArray(settings.symbolWhitelist) 
        ? settings.symbolWhitelist.join(', ') 
        : '';
      
      const symbolBlacklist = Array.isArray(settings.symbolBlacklist) 
        ? settings.symbolBlacklist.join(', ') 
        : '';
      
      form.reset({
        ...settings,
        symbolWhitelist,
        symbolBlacklist
      });
    }
  }, [settings, form]);
  
  // Update settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: (data: any) => {
      // Convert comma-separated strings to arrays
      const formattedData = {
        ...data,
        symbolWhitelist: data.symbolWhitelist ? data.symbolWhitelist.split(',').map((s: string) => s.trim()) : [],
        symbolBlacklist: data.symbolBlacklist ? data.symbolBlacklist.split(',').map((s: string) => s.trim()) : []
      };
      
      return updateCopyTradingSettings(formattedData);
    },
    onSuccess: () => {
      toast({
        title: 'Settings updated',
        description: 'Copy trading settings have been saved successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/copy-trading/settings'] });
      queryClient.invalidateQueries({ queryKey: ['/api/copy-trading/stats'] });
    },
    onError: (error) => {
      toast({
        title: 'Error updating settings',
        description: error.message || 'There was an error saving your settings.',
        variant: 'destructive'
      });
    }
  });
  
  // Test copy trade mutation
  const testCopyTradeMutation = useMutation({
    mutationFn: (data: any) => {
      return testCopyTrade(data);
    },
    onSuccess: () => {
      toast({
        title: 'Test copy trade initiated',
        description: 'A test copy trade has been initiated successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/copy-trading/logs'] });
    },
    onError: (error) => {
      toast({
        title: 'Error running test',
        description: error.message || 'There was an error initiating the test copy trade.',
        variant: 'destructive'
      });
    }
  });
  
  // Handle form submission
  function onSubmit(data: z.infer<typeof formSchema>) {
    updateSettingsMutation.mutate(data);
  }
  
  // Handle test copy trade
  function handleTestCopyTrade() {
    const leaderBroker = stats?.brokers?.leaders?.connected > 0 ? 1 : null;
    
    if (!leaderBroker) {
      toast({
        title: 'No leader accounts',
        description: 'You need at least one connected leader account to run a test.',
        variant: 'destructive'
      });
      return;
    }
    
    testCopyTradeMutation.mutate({
      leaderId: leaderBroker,
      symbol: 'AAPL',
      quantity: 1,
      side: 'buy',
      type: 'market'
    });
  }

  return (
    <div className="container mx-auto py-8">
      <div className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Copy Trading</h1>
          <p className="text-muted-foreground mt-2">
            Automatically copy trades from leader accounts to follower accounts
          </p>
        </div>
        <div className="flex items-center">
          {connected ? (
            <div className="flex items-center text-green-600">
              <div className="w-2 h-2 bg-green-600 rounded-full mr-2 animate-pulse"></div>
              <span className="text-sm">Real-time updates active</span>
            </div>
          ) : (
            <div className="flex items-center text-red-600">
              <div className="w-2 h-2 bg-red-600 rounded-full mr-2"></div>
              <span className="text-sm">Real-time updates disconnected</span>
            </div>
          )}
        </div>
      </div>
      
      {/* Show broker connection required message when no broker is connected */}
      {!isLoadingBrokerStatus && !isBrokerConnected && (
        <Alert className="mb-6" variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Broker Connection Required</AlertTitle>
          <AlertDescription>
            Copy Trading requires an active broker connection. Please connect your brokerage account first.
          </AlertDescription>
          <Button variant="outline" className="mt-2" size="sm" asChild>
            <a href="/accounts">Go to Accounts</a>
          </Button>
        </Alert>
      )}
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-8">
          <TabsTrigger value="dashboard" className="flex items-center">
            <LineChart className="w-4 h-4 mr-2" />
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center" disabled={!isBrokerConnected}>
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </TabsTrigger>
          <TabsTrigger value="logs" className="flex items-center" disabled={!isBrokerConnected}>
            <List className="w-4 h-4 mr-2" />
            Activity Logs
          </TabsTrigger>
        </TabsList>
        
        {/* Dashboard Tab */}
        <TabsContent value="dashboard" className="space-y-4">
          {isLoadingBrokerStatus ? (
            <div className="flex items-center justify-center p-8">
              <RefreshCw className="w-6 h-6 text-primary animate-spin" />
            </div>
          ) : !isBrokerConnected ? (
            <Card>
              <CardHeader>
                <CardTitle>Copy Trading Unavailable</CardTitle>
                <CardDescription>
                  Connect a broker to use the copy trading system
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <AlertCircle className="h-16 w-16 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Active Broker Connection</h3>
                  <p className="text-muted-foreground mb-4">
                    Copy trading requires at least one active broker connection to function properly.
                    Please connect to a broker to start using the copy trading system.
                  </p>
                  <Button asChild>
                    <a href="/accounts">Set Up Broker Connections</a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <CopyTradingStatusCard stats={stats} />
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle>Connected Accounts</CardTitle>
                  <CardDescription>Leaders and followers in your copy trading network</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-sm mb-2 flex items-center">
                        <Users className="w-4 h-4 mr-2" />
                        Leader Accounts
                      </h4>
                      <Progress value={(stats?.brokers?.leaders?.connected / Math.max(1, stats?.brokers?.leaders?.total)) * 100} className="h-2" />
                      <p className="text-sm text-muted-foreground mt-1">
                        {stats?.brokers?.leaders?.connected || 0} connected out of {stats?.brokers?.leaders?.total || 0} total
                      </p>
                    </div>
                    <div>
                      <h4 className="font-medium text-sm mb-2 flex items-center">
                        <Copy className="w-4 h-4 mr-2" />
                        Follower Accounts
                      </h4>
                      <Progress value={(stats?.brokers?.followers?.connected / Math.max(1, stats?.brokers?.followers?.total)) * 100} className="h-2" />
                      <p className="text-sm text-muted-foreground mt-1">
                        {stats?.brokers?.followers?.connected || 0} connected out of {stats?.brokers?.followers?.total || 0} total
                      </p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button 
                    variant="outline" 
                    className="w-full" 
                    onClick={handleTestCopyTrade} 
                    disabled={testCopyTradeMutation.isPending || (stats?.brokers?.leaders?.connected || 0) === 0}
                  >
                    {testCopyTradeMutation.isPending ? (
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <ArrowRight className="mr-2 h-4 w-4" />
                    )}
                    Run Test Copy Trade
                  </Button>
                </CardFooter>
              </Card>
              
              {/* Recent Activity Card */}
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Latest copy trading activity</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingLogs ? (
                    <div className="flex items-center justify-center p-8">
                      <RefreshCw className="w-6 h-6 text-primary animate-spin" />
                    </div>
                  ) : logs && logs.length > 0 ? (
                    <ScrollArea className="h-[300px]">
                      {logs.slice(0, 10).map((log: any) => (
                        <CopyTradeLogItem key={log.id} log={log} />
                      ))}
                    </ScrollArea>
                  ) : (
                    <div className="text-center p-8 text-muted-foreground">
                      No copy trading activity yet
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>
        
        {/* Settings Tab */}
        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Copy Trading Settings</CardTitle>
              <CardDescription>
                Configure how trades are copied from leaders to followers
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="space-y-4">
                    {/* Global Settings Section */}
                    <div>
                      <h3 className="text-lg font-medium">Global Settings</h3>
                      <div className="grid md:grid-cols-2 gap-6 mt-3">
                        <FormField
                          control={form.control}
                          name="enabled"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">
                                  Enable Copy Trading
                                </FormLabel>
                                <FormDescription>
                                  Turn on automated trade copying from leaders to followers
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="copyMode"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Copy Mode</FormLabel>
                              <Select 
                                onValueChange={field.onChange} 
                                defaultValue={field.value}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select a copy mode" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="all">All Symbols</SelectItem>
                                  <SelectItem value="whitelist">Whitelist Only</SelectItem>
                                  <SelectItem value="blacklist">All Except Blacklist</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                Controls which symbols will be copied
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        {form.watch('copyMode') === 'whitelist' && (
                          <FormField
                            control={form.control}
                            name="symbolWhitelist"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Symbol Whitelist</FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="AAPL, MSFT, GOOGL"
                                    {...field}
                                  />
                                </FormControl>
                                <FormDescription>
                                  Only these symbols will be copied (comma separated)
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        )}
                        
                        {form.watch('copyMode') === 'blacklist' && (
                          <FormField
                            control={form.control}
                            name="symbolBlacklist"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Symbol Blacklist</FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="GME, AMC, TSLA"
                                    {...field}
                                  />
                                </FormControl>
                                <FormDescription>
                                  These symbols will never be copied (comma separated)
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        )}
                      </div>
                    </div>
                    
                    {/* Position Sizing Section */}
                    <Separator />
                    <div>
                      <h3 className="text-lg font-medium">Position Sizing</h3>
                      <div className="grid md:grid-cols-2 gap-6 mt-3">
                        <FormField
                          control={form.control}
                          name="positionSizeType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Position Size Type</FormLabel>
                              <Select 
                                onValueChange={field.onChange} 
                                defaultValue={field.value}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select a position sizing method" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="fixed">Fixed Quantity</SelectItem>
                                  <SelectItem value="percentage">Percentage of Leader</SelectItem>
                                  <SelectItem value="proportional">Proportional to Account Size</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                How position sizes are calculated for followers
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="positionSizeValue"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                {form.watch('positionSizeType') === 'fixed' && 'Fixed Quantity'}
                                {form.watch('positionSizeType') === 'percentage' && 'Percentage of Leader Position (%)'}
                                {form.watch('positionSizeType') === 'proportional' && 'Proportional Factor (%)'}
                              </FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                {form.watch('positionSizeType') === 'fixed' && 'Exact number of shares/contracts to trade'}
                                {form.watch('positionSizeType') === 'percentage' && '100% means exactly copy the leader position size'}
                                {form.watch('positionSizeType') === 'proportional' && 'Scaled based on account size ratio'}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="maxPositionSize"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Maximum Position Size</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                Maximum number of shares/contracts per trade (0 = no limit)
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="delaySeconds"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Delay (seconds)</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                Seconds to wait before copying a trade (0 = no delay)
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    {/* Safety & Notifications Section */}
                    <Separator />
                    <div>
                      <h3 className="text-lg font-medium">Safety & Notifications</h3>
                      <div className="grid md:grid-cols-2 gap-6 mt-3">
                        <FormField
                          control={form.control}
                          name="riskCheckEnabled"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">
                                  Risk Checks
                                </FormLabel>
                                <FormDescription>
                                  Apply risk management rules to copied trades
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="notificationsEnabled"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">
                                  Notifications
                                </FormLabel>
                                <FormDescription>
                                  Receive notifications about copy trading activities
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="forbidFollowerManualOrders"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">
                                  Restrict Manual Orders
                                </FormLabel>
                                <FormDescription>
                                  Prevent followers from placing manual orders
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <Alert className={form.watch('enabled') ? 'bg-green-50 text-green-800 border-green-200' : 'bg-yellow-50 text-yellow-800 border-yellow-200'}>
                    <AlertTitle className="flex items-center">
                      {form.watch('enabled') ? (
                        <>
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Copy Trading is Enabled
                        </>
                      ) : (
                        <>
                          <AlertCircle className="h-4 w-4 mr-2" />
                          Copy Trading is Disabled
                        </>
                      )}
                    </AlertTitle>
                    <AlertDescription>
                      {form.watch('enabled')
                        ? 'Trades will be automatically copied from leader to follower accounts based on your settings.'
                        : 'No trades will be copied until you enable the copy trading system.'}
                    </AlertDescription>
                  </Alert>
                  
                  <div className="flex justify-end">
                    <Button 
                      type="submit" 
                      disabled={updateSettingsMutation.isPending || isLoadingSettings}
                      className="w-full md:w-auto"
                    >
                      {updateSettingsMutation.isPending && (
                        <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      )}
                      Save Settings
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Logs Tab */}
        <TabsContent value="logs">
          <Card>
            <CardHeader>
              <CardTitle>Copy Trading Logs</CardTitle>
              <CardDescription>History of all copy trading activities</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingLogs ? (
                <div className="flex items-center justify-center p-16">
                  <RefreshCw className="w-6 h-6 text-primary animate-spin" />
                </div>
              ) : logs && logs.length > 0 ? (
                <ScrollArea className="h-[600px]">
                  {logs.map((log: any) => (
                    <CopyTradeLogItem key={log.id} log={log} />
                  ))}
                </ScrollArea>
              ) : (
                <div className="text-center p-16 text-muted-foreground">
                  No copy trading logs available
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}