import { useEffect, useState } from 'react';

/**
 * This is a special redirect page that ensures the user gets to the dashboard
 * even if other routing mechanisms fail. It directly manipulates the DOM to force
 * navigation.
 */
export default function RedirectToDashboard() {
  const [countdown, setCountdown] = useState(3);
  
  useEffect(() => {
    // First approach - immediate redirect
    document.location.href = '/dashboard';
    
    // Fallback approach - set a short countdown and then redirect
    const interval = setInterval(() => {
      setCountdown((prev) => {
        // When countdown reaches 0, force a redirect
        if (prev <= 1) {
          clearInterval(interval);
          console.log('Forcing navigation via window.location.replace');
          window.location.replace('/dashboard');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    // Extra fallback - if nothing else works after 3 seconds
    const timeout = setTimeout(() => {
      console.log('Emergency fallback - hard refresh to dashboard');
      window.location.assign('/dashboard');
    }, 3000);
    
    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, []);
  
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-900 text-white">
      <div className="animate-spin w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full mb-4"></div>
      <div className="text-2xl font-bold">Redirecting to Dashboard</div>
      <div className="text-md mt-2">Please wait... ({countdown})</div>
      <div className="text-xs mt-4 text-slate-400">If you're not redirected, <a href="/dashboard" className="text-blue-400 hover:underline">click here</a>.</div>
    </div>
  );
}