import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { AccountForm } from "@/components/ui/account-form";
import { 
  Tag, 
  LinkIcon, 
  PlusCircle, 
  Search, 
  RefreshCw,
  CheckCircle,
  AlertCircle,
  Trash2
} from "lucide-react";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";

// Symbol form schema
const symbolFormSchema = z.object({
  symbol: z.string().min(1, "Symbol is required").max(10, "Symbol must be 10 characters or less"),
  allowTrading: z.boolean().default(true),
  maxPositionSize: z.coerce.number().min(0, "Must be a positive number").optional(),
  maxPositionValue: z.coerce.number().min(0, "Must be a positive number").optional(),
  notes: z.string().optional(),
});

type SymbolFormValues = z.infer<typeof symbolFormSchema>;

// Options strategy form schema
const strategyFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  symbol: z.string().min(1, "Symbol is required"),
  strategy: z.string().min(1, "Strategy type is required"),
  legs: z.array(z.object({
    optionType: z.enum(["call", "put"]),
    strike: z.coerce.number().min(0, "Strike must be positive"),
    expiration: z.string().min(1, "Expiration is required"),
    action: z.enum(["buy", "sell"]),
    quantity: z.coerce.number().min(1, "Quantity must be at least 1"),
  })).min(1, "At least one leg is required"),
  notes: z.string().optional(),
});

type StrategyFormValues = z.infer<typeof strategyFormSchema>;

export default function Symbols() {
  const [showAccountModal, setShowAccountModal] = useState(false);
  const [showSymbolModal, setShowSymbolModal] = useState(false);
  const [showStrategyModal, setShowStrategyModal] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedSymbol, setSelectedSymbol] = useState<any>(null);
  const [selectedStrategy, setSelectedStrategy] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("symbols");
  const { toast } = useToast();
  
  const { 
    data: { brokersConnected = false } = {}, 
    isLoading: isLoadingBrokerStatus 
  } = useQuery<{brokersConnected: boolean}>({
    queryKey: ['/api/brokers/status'],
  });
  
  const { 
    data: symbols = [], 
    isLoading: isLoadingSymbols,
    refetch: refetchSymbols
  } = useQuery<any[]>({
    queryKey: ['/api/symbols'],
    enabled: brokersConnected,
  });
  
  const { 
    data: strategies = [], 
    isLoading: isLoadingStrategies,
    refetch: refetchStrategies
  } = useQuery<any[]>({
    queryKey: ['/api/symbols/strategies'],
    enabled: brokersConnected,
  });
  
  // Symbol form
  const symbolForm = useForm<SymbolFormValues>({
    resolver: zodResolver(symbolFormSchema),
    defaultValues: {
      symbol: "",
      allowTrading: true,
      maxPositionSize: undefined,
      maxPositionValue: undefined,
      notes: "",
    },
  });
  
  // Strategy form 
  const strategyForm = useForm<StrategyFormValues>({
    resolver: zodResolver(strategyFormSchema),
    defaultValues: {
      name: "",
      symbol: "",
      strategy: "custom",
      legs: [
        { 
          optionType: "call", 
          strike: 0, 
          expiration: "", 
          action: "buy",
          quantity: 1
        }
      ],
      notes: "",
    },
  });
  
  // Add Symbol Mutation
  const addSymbolMutation = useMutation({
    mutationFn: (data: SymbolFormValues) => {
      return apiRequest("POST", "/api/symbols", data);
    },
    onSuccess: () => {
      toast({
        title: "Symbol added",
        description: "Symbol has been added successfully",
      });
      setShowSymbolModal(false);
      symbolForm.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/symbols'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to add symbol",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Update Symbol Mutation
  const updateSymbolMutation = useMutation({
    mutationFn: (data: SymbolFormValues & { id: number }) => {
      return apiRequest("PUT", `/api/symbols/${data.id}`, data);
    },
    onSuccess: () => {
      toast({
        title: "Symbol updated",
        description: "Symbol has been updated successfully",
      });
      setShowSymbolModal(false);
      symbolForm.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/symbols'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update symbol",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Delete Symbol Mutation
  const deleteSymbolMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("DELETE", `/api/symbols/${id}`, {});
    },
    onSuccess: () => {
      toast({
        title: "Symbol deleted",
        description: "Symbol has been deleted successfully",
      });
      setShowDeleteDialog(false);
      setSelectedSymbol(null);
      queryClient.invalidateQueries({ queryKey: ['/api/symbols'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete symbol",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Add Strategy Mutation
  const addStrategyMutation = useMutation({
    mutationFn: (data: StrategyFormValues) => {
      return apiRequest("POST", "/api/symbols/strategies", data);
    },
    onSuccess: () => {
      toast({
        title: "Strategy added",
        description: "Options strategy has been saved successfully",
      });
      setShowStrategyModal(false);
      strategyForm.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/symbols/strategies'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to add strategy",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Handle symbol form submission
  const onSubmitSymbolForm = (data: SymbolFormValues) => {
    if (selectedSymbol) {
      updateSymbolMutation.mutate({ ...data, id: selectedSymbol.id });
    } else {
      addSymbolMutation.mutate(data);
    }
  };
  
  // Handle strategy form submission
  const onSubmitStrategyForm = (data: StrategyFormValues) => {
    addStrategyMutation.mutate(data);
  };
  
  // Open the symbol modal for editing
  const editSymbol = (symbol: any) => {
    setSelectedSymbol(symbol);
    symbolForm.reset({
      symbol: symbol.symbol,
      allowTrading: symbol.allowTrading,
      maxPositionSize: symbol.maxPositionSize,
      maxPositionValue: symbol.maxPositionValue,
      notes: symbol.notes,
    });
    setShowSymbolModal(true);
  };
  
  // Add a leg to the strategy form
  const addLeg = () => {
    const currentLegs = strategyForm.getValues("legs") || [];
    strategyForm.setValue("legs", [
      ...currentLegs,
      { 
        optionType: "call", 
        strike: 0, 
        expiration: "", 
        action: "buy",
        quantity: 1
      }
    ]);
  };
  
  // Remove a leg from the strategy form
  const removeLeg = (index: number) => {
    const currentLegs = strategyForm.getValues("legs");
    if (currentLegs.length > 1) {
      strategyForm.setValue("legs", currentLegs.filter((_, i) => i !== index));
    }
  };
  
  // Filter symbols based on search query
  const filteredSymbols = symbols.filter(symbol => 
    symbol.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (symbol.notes && symbol.notes.toLowerCase().includes(searchQuery.toLowerCase()))
  );
  
  // Filter strategies based on search query
  const filteredStrategies = strategies.filter(strategy => 
    strategy.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    strategy.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (strategy.notes && strategy.notes.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  if (isLoadingBrokerStatus) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  if (!brokersConnected) {
    return (
      <Card className="p-8 text-center">
        <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-slate-100 dark:bg-slate-700 mb-4">
          <Tag className="h-10 w-10 text-slate-500 dark:text-slate-400" />
        </div>
        <h3 className="text-lg font-medium text-slate-900 dark:text-slate-100 mb-2">Broker Connection Required</h3>
        <p className="text-slate-500 dark:text-slate-400 mb-4 max-w-md mx-auto">
          Symbol management requires an active broker connection. Please connect your brokerage account first.
        </p>
        <Button onClick={() => setShowAccountModal(true)}>
          <LinkIcon className="h-4 w-4 mr-2" />
          Connect Broker
        </Button>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <CardTitle>Symbol Management</CardTitle>
              <CardDescription>
                Manage allowed trading symbols and option strategies
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => {
                setActiveTab("symbols");
                setShowSymbolModal(true);
                setSelectedSymbol(null);
                symbolForm.reset({
                  symbol: "",
                  allowTrading: true,
                  maxPositionSize: undefined,
                  maxPositionValue: undefined,
                  notes: "",
                });
              }}>
                <PlusCircle className="h-4 w-4 mr-2" />
                Add Symbol
              </Button>
              <Button variant="outline" onClick={() => {
                setActiveTab("strategies");
                setShowStrategyModal(true);
                strategyForm.reset({
                  name: "",
                  symbol: "",
                  strategy: "custom",
                  legs: [
                    { 
                      optionType: "call", 
                      strike: 0, 
                      expiration: "", 
                      action: "buy",
                      quantity: 1
                    }
                  ],
                  notes: "",
                });
              }}>
                <PlusCircle className="h-4 w-4 mr-2" />
                Add Strategy
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex flex-col md:flex-row gap-4 items-end">
              <div className="grid gap-2 flex-1">
                <label htmlFor="symbolSearch" className="text-sm font-medium">Search</label>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-500 dark:text-slate-400" />
                  <Input
                    id="symbolSearch"
                    type="search"
                    placeholder="Search by symbol or notes"
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="flex gap-2">
                <Button 
                  variant={activeTab === "symbols" ? "default" : "outline"}
                  onClick={() => setActiveTab("symbols")}
                >
                  Symbols
                </Button>
                <Button 
                  variant={activeTab === "strategies" ? "default" : "outline"}
                  onClick={() => setActiveTab("strategies")}
                >
                  Option Strategies
                </Button>
              </div>
            </div>
            
            {activeTab === "symbols" ? (
              <>
                {isLoadingSymbols ? (
                  <div className="flex justify-center py-8">
                    <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                  </div>
                ) : filteredSymbols.length === 0 ? (
                  <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                    No symbols found matching your criteria
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Symbol</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Max Size</TableHead>
                          <TableHead>Max Value</TableHead>
                          <TableHead>Notes</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredSymbols.map((symbol) => (
                          <TableRow key={symbol.id}>
                            <TableCell className="font-mono font-medium">
                              {symbol.symbol}
                            </TableCell>
                            <TableCell>
                              {symbol.allowTrading ? (
                                <Badge variant="success" className="gap-1">
                                  <CheckCircle className="h-3 w-3" />
                                  Allowed
                                </Badge>
                              ) : (
                                <Badge variant="destructive" className="gap-1">
                                  <AlertCircle className="h-3 w-3" />
                                  Restricted
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              {symbol.maxPositionSize || "—"}
                            </TableCell>
                            <TableCell>
                              {symbol.maxPositionValue ? `$${symbol.maxPositionValue.toLocaleString()}` : "—"}
                            </TableCell>
                            <TableCell className="max-w-[200px] truncate">
                              {symbol.notes || "—"}
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => editSymbol(symbol)}
                                >
                                  Edit
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="text-destructive hover:text-destructive"
                                  onClick={() => {
                                    setSelectedSymbol(symbol);
                                    setShowDeleteDialog(true);
                                  }}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </>
            ) : (
              <>
                {isLoadingStrategies ? (
                  <div className="flex justify-center py-8">
                    <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                  </div>
                ) : filteredStrategies.length === 0 ? (
                  <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                    No option strategies found matching your criteria
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Symbol</TableHead>
                          <TableHead>Strategy Type</TableHead>
                          <TableHead>Legs</TableHead>
                          <TableHead>Notes</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredStrategies.map((strategy) => (
                          <TableRow key={strategy.id}>
                            <TableCell className="font-medium">
                              {strategy.name}
                            </TableCell>
                            <TableCell className="font-mono">
                              {strategy.symbol}
                            </TableCell>
                            <TableCell className="capitalize">
                              {strategy.strategy}
                            </TableCell>
                            <TableCell>
                              {strategy.legs.length}
                            </TableCell>
                            <TableCell className="max-w-[200px] truncate">
                              {strategy.notes || "—"}
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  // View strategy details
                                  setSelectedStrategy(strategy);
                                }}
                              >
                                View Details
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Add/Edit Symbol Dialog */}
      <Dialog open={showSymbolModal} onOpenChange={setShowSymbolModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedSymbol ? "Edit Symbol" : "Add Symbol"}</DialogTitle>
            <DialogDescription>
              {selectedSymbol ? "Modify symbol settings" : "Add a new trading symbol to the platform"}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...symbolForm}>
            <form onSubmit={symbolForm.handleSubmit(onSubmitSymbolForm)} className="space-y-4">
              <FormField
                control={symbolForm.control}
                name="symbol"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Symbol</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. AAPL" {...field} />
                    </FormControl>
                    <FormDescription>
                      Enter the ticker symbol (e.g. AAPL, SPY)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={symbolForm.control}
                name="allowTrading"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">
                        Allow Trading
                      </FormLabel>
                      <FormDescription>
                        Enable trading for this symbol
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={symbolForm.control}
                  name="maxPositionSize"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Max Position Size</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="Optional" {...field} />
                      </FormControl>
                      <FormDescription>
                        Maximum number of shares/contracts
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={symbolForm.control}
                  name="maxPositionValue"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Max Position Value ($)</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="Optional" {...field} />
                      </FormControl>
                      <FormDescription>
                        Maximum position value in dollars
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={symbolForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Input placeholder="Optional notes" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setShowSymbolModal(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={addSymbolMutation.isPending || updateSymbolMutation.isPending}>
                  {addSymbolMutation.isPending || updateSymbolMutation.isPending ? "Saving..." : "Save Symbol"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Add Strategy Dialog */}
      <Dialog open={showStrategyModal} onOpenChange={setShowStrategyModal}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Add Options Strategy</DialogTitle>
            <DialogDescription>
              Create a new multi-leg options strategy template
            </DialogDescription>
          </DialogHeader>
          
          <Form {...strategyForm}>
            <form onSubmit={strategyForm.handleSubmit(onSubmitStrategyForm)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={strategyForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Strategy Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. AAPL Iron Condor" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={strategyForm.control}
                  name="symbol"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Underlying Symbol</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. AAPL" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={strategyForm.control}
                name="strategy"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Strategy Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a strategy type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="custom">Custom</SelectItem>
                        <SelectItem value="vertical">Vertical Spread</SelectItem>
                        <SelectItem value="ironCondor">Iron Condor</SelectItem>
                        <SelectItem value="calendar">Calendar Spread</SelectItem>
                        <SelectItem value="butterfly">Butterfly</SelectItem>
                        <SelectItem value="straddle">Straddle</SelectItem>
                        <SelectItem value="strangle">Strangle</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-sm font-medium">Strategy Legs</h3>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addLeg}
                  >
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Add Leg
                  </Button>
                </div>
                
                {strategyForm.watch("legs").map((leg, index) => (
                  <div key={index} className="space-y-2 p-4 border border-slate-200 dark:border-slate-700 rounded-md">
                    <div className="flex justify-between items-center">
                      <h4 className="text-sm font-medium">Leg {index + 1}</h4>
                      {strategyForm.watch("legs").length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeLeg(index)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                      <FormField
                        control={strategyForm.control}
                        name={`legs.${index}.optionType`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Option type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="call">Call</SelectItem>
                                <SelectItem value="put">Put</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={strategyForm.control}
                        name={`legs.${index}.strike`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Strike</FormLabel>
                            <FormControl>
                              <Input type="number" step="0.01" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={strategyForm.control}
                        name={`legs.${index}.expiration`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Expiration</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={strategyForm.control}
                        name={`legs.${index}.action`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Action</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Action" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="buy">Buy</SelectItem>
                                <SelectItem value="sell">Sell</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={strategyForm.control}
                        name={`legs.${index}.quantity`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Quantity</FormLabel>
                            <FormControl>
                              <Input type="number" min="1" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                ))}
              </div>
              
              <FormField
                control={strategyForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Input placeholder="Optional notes" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setShowStrategyModal(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={addStrategyMutation.isPending}>
                  {addStrategyMutation.isPending ? "Saving..." : "Save Strategy"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Delete Symbol Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Symbol</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {selectedSymbol?.symbol}? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={() => selectedSymbol && deleteSymbolMutation.mutate(selectedSymbol.id)}
              disabled={deleteSymbolMutation.isPending}
            >
              {deleteSymbolMutation.isPending ? "Deleting..." : "Delete Symbol"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <AccountForm 
        open={showAccountModal} 
        onOpenChange={setShowAccountModal} 
      />
    </div>
  );
}
