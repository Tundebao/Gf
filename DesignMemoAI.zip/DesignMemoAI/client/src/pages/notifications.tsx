import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardFooter 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Separator } from "@/components/ui/separator";
import { AccountForm } from "@/components/ui/account-form";
import { 
  Bell, 
  LinkIcon, 
  RefreshCw, 
  CheckCircle,
  Mail,
  MessageSquare,
  Smartphone,
  Trash2
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";

// Notification settings schema
const notificationSettingsSchema = z.object({
  emailEnabled: z.boolean().default(false),
  emailAddress: z.string().email("Invalid email address").optional().or(z.literal("")),
  smsEnabled: z.boolean().default(false),
  phoneNumber: z.string().optional().or(z.literal("")),
  slackEnabled: z.boolean().default(false),
  slackWebhook: z.string().url("Invalid webhook URL").optional().or(z.literal("")),
  // Notification types
  notifyOnTradeExecuted: z.boolean().default(true),
  notifyOnOrderFilled: z.boolean().default(true),
  notifyOnOrderCancelled: z.boolean().default(true),
  notifyOnBrokerDisconnect: z.boolean().default(true),
  notifyOnRiskEvent: z.boolean().default(true),
  notifyOnCopyTradeFailure: z.boolean().default(true),
});

type NotificationSettingsValues = z.infer<typeof notificationSettingsSchema>;

export default function NotificationsPage() {
  const [showAccountModal, setShowAccountModal] = useState(false);
  const { toast } = useToast();
  
  const { 
    data: { brokersConnected = false } = {}, 
    isLoading: isLoadingBrokerStatus 
  } = useQuery<{brokersConnected: boolean}>({
    queryKey: ['/api/brokers/status'],
  });
  
  const { 
    data: notifications = [], 
    isLoading: isLoadingNotifications,
    refetch: refetchNotifications 
  } = useQuery<any[]>({
    queryKey: ['/api/notifications'],
    enabled: brokersConnected,
  });
  
  const { 
    data: notificationSettings, 
    isLoading: isLoadingSettings 
  } = useQuery<NotificationSettingsValues>({
    queryKey: ['/api/notifications/settings'],
    enabled: brokersConnected,
  });
  
  // Mark notification as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("PUT", `/api/notifications/${id}/read`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications/unread'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to mark notification as read",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Mark all notifications as read mutation
  const markAllAsReadMutation = useMutation({
    mutationFn: () => {
      return apiRequest("PUT", "/api/notifications/read-all", {});
    },
    onSuccess: () => {
      toast({
        title: "Marked all as read",
        description: "All notifications have been marked as read",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications/unread'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to mark all as read",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Delete notification mutation
  const deleteNotificationMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest("DELETE", `/api/notifications/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications/unread'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete notification",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Delete all notifications mutation
  const deleteAllNotificationsMutation = useMutation({
    mutationFn: () => {
      return apiRequest("DELETE", "/api/notifications/all", {});
    },
    onSuccess: () => {
      toast({
        title: "All notifications deleted",
        description: "All notifications have been removed",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications/unread'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete all notifications",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Update notification settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: (data: NotificationSettingsValues) => {
      return apiRequest("PUT", "/api/notifications/settings", data);
    },
    onSuccess: () => {
      toast({
        title: "Settings updated",
        description: "Notification settings have been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications/settings'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update settings",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Test notification delivery mutation
  const testNotificationMutation = useMutation({
    mutationFn: (channel: string) => {
      return apiRequest("POST", "/api/notifications/test", { channel });
    },
    onSuccess: (_, variables) => {
      toast({
        title: "Test notification sent",
        description: `A test notification has been sent to your ${variables} account`,
      });
    },
    onError: (error, variables) => {
      toast({
        title: `Failed to send test ${variables} notification`,
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Notification settings form
  const form = useForm<NotificationSettingsValues>({
    resolver: zodResolver(notificationSettingsSchema),
    defaultValues: {
      emailEnabled: false,
      emailAddress: "",
      smsEnabled: false,
      phoneNumber: "",
      slackEnabled: false,
      slackWebhook: "",
      notifyOnTradeExecuted: true,
      notifyOnOrderFilled: true,
      notifyOnOrderCancelled: true,
      notifyOnBrokerDisconnect: true,
      notifyOnRiskEvent: true,
      notifyOnCopyTradeFailure: true,
    },
  });
  
  // Set form values when settings are loaded
  useState(() => {
    if (notificationSettings) {
      form.reset(notificationSettings);
    }
  });
  
  // Handle form submission
  const onSubmit = (data: NotificationSettingsValues) => {
    updateSettingsMutation.mutate(data);
  };
  
  // Get badge variant based on notification type
  const getNotificationBadgeVariant = (type: string) => {
    switch (type.toLowerCase()) {
      case "error":
      case "risk":
        return "destructive";
      case "warning":
        return "warning";
      case "success":
        return "success";
      case "info":
      default:
        return "secondary";
    }
  };
  
  // Format notification date
  const formatNotificationDate = (date: string) => {
    const notificationDate = new Date(date);
    const now = new Date();
    const diffMs = now.getTime() - notificationDate.getTime();
    const diffMins = Math.round(diffMs / (1000 * 60));
    const diffHours = Math.round(diffMs / (1000 * 60 * 60));
    const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffMins < 60) {
      return `${diffMins} minute${diffMins !== 1 ? 's' : ''} ago`;
    } else if (diffHours < 24) {
      return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
    } else if (diffDays < 7) {
      return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
    } else {
      return notificationDate.toLocaleDateString();
    }
  };

  if (isLoadingBrokerStatus) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  if (!brokersConnected) {
    return (
      <Card className="p-8 text-center">
        <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-slate-100 dark:bg-slate-700 mb-4">
          <Bell className="h-10 w-10 text-slate-500 dark:text-slate-400" />
        </div>
        <h3 className="text-lg font-medium text-slate-900 dark:text-slate-100 mb-2">Broker Connection Required</h3>
        <p className="text-slate-500 dark:text-slate-400 mb-4 max-w-md mx-auto">
          Notifications require an active broker connection. Please connect your brokerage account first.
        </p>
        <Button onClick={() => setShowAccountModal(true)}>
          <LinkIcon className="h-4 w-4 mr-2" />
          Connect Broker
        </Button>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="inbox" className="space-y-6">
        <div className="flex justify-between items-center">
          <TabsList className="grid grid-cols-2 w-[300px]">
            <TabsTrigger value="inbox">Notification Inbox</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>
          
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => refetchNotifications()}
              disabled={isLoadingNotifications}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isLoadingNotifications ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => markAllAsReadMutation.mutate()}
              disabled={markAllAsReadMutation.isPending || notifications.filter(n => !n.read).length === 0}
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Mark All Read
            </Button>
            
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => deleteAllNotificationsMutation.mutate()}
              disabled={deleteAllNotificationsMutation.isPending || notifications.length === 0}
              className="text-destructive hover:text-destructive"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Clear All
            </Button>
          </div>
        </div>
        
        <TabsContent value="inbox">
          <Card>
            <CardHeader>
              <CardTitle>Notifications</CardTitle>
              <CardDescription>
                Your system notifications and alerts
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingNotifications ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : notifications.length === 0 ? (
                <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                  No notifications available
                </div>
              ) : (
                <div className="space-y-4">
                  {notifications.map((notification) => (
                    <div 
                      key={notification.id} 
                      className={`p-4 border rounded-md ${notification.read ? 'bg-transparent' : 'bg-slate-50 dark:bg-slate-800'}`}
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex items-start gap-4">
                          <div>
                            <Badge variant={getNotificationBadgeVariant(notification.type)}>
                              {notification.type}
                            </Badge>
                            <h3 className="text-base font-medium mt-2">{notification.title}</h3>
                            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{notification.message}</p>
                            <p className="text-xs text-slate-500 dark:text-slate-500 mt-2">
                              {formatNotificationDate(notification.createdAt)}
                            </p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          {!notification.read && (
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => markAsReadMutation.mutate(notification.id)}
                              disabled={markAsReadMutation.isPending}
                            >
                              <CheckCircle className="h-4 w-4" />
                            </Button>
                          )}
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => deleteNotificationMutation.mutate(notification.id)}
                            disabled={deleteNotificationMutation.isPending}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>
                Configure how and when you receive notifications
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingSettings ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : (
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {/* Email Notifications */}
                      <Card>
                        <CardHeader className="pb-2">
                          <div className="flex items-center">
                            <Mail className="h-5 w-5 mr-2 text-blue-600 dark:text-blue-500" />
                            <CardTitle>Email Notifications</CardTitle>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <FormField
                            control={form.control}
                            name="emailEnabled"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between space-y-0">
                                <FormLabel>Enable email notifications</FormLabel>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          
                          {form.watch("emailEnabled") && (
                            <FormField
                              control={form.control}
                              name="emailAddress"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Email Address</FormLabel>
                                  <FormControl>
                                    <Input placeholder="you@example.com" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          )}
                          
                          {form.watch("emailEnabled") && form.watch("emailAddress") && (
                            <Button 
                              type="button" 
                              variant="outline" 
                              size="sm" 
                              className="w-full mt-2"
                              onClick={() => testNotificationMutation.mutate("email")}
                              disabled={testNotificationMutation.isPending}
                            >
                              Send Test Email
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                      
                      {/* SMS Notifications */}
                      <Card>
                        <CardHeader className="pb-2">
                          <div className="flex items-center">
                            <Smartphone className="h-5 w-5 mr-2 text-green-600 dark:text-green-500" />
                            <CardTitle>SMS Notifications</CardTitle>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <FormField
                            control={form.control}
                            name="smsEnabled"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between space-y-0">
                                <FormLabel>Enable SMS notifications</FormLabel>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          
                          {form.watch("smsEnabled") && (
                            <FormField
                              control={form.control}
                              name="phoneNumber"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Phone Number</FormLabel>
                                  <FormControl>
                                    <Input placeholder="+1 (555) 123-4567" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          )}
                          
                          {form.watch("smsEnabled") && form.watch("phoneNumber") && (
                            <Button 
                              type="button" 
                              variant="outline" 
                              size="sm" 
                              className="w-full mt-2"
                              onClick={() => testNotificationMutation.mutate("sms")}
                              disabled={testNotificationMutation.isPending}
                            >
                              Send Test SMS
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                      
                      {/* Slack Notifications */}
                      <Card>
                        <CardHeader className="pb-2">
                          <div className="flex items-center">
                            <MessageSquare className="h-5 w-5 mr-2 text-purple-600 dark:text-purple-500" />
                            <CardTitle>Slack Notifications</CardTitle>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <FormField
                            control={form.control}
                            name="slackEnabled"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between space-y-0">
                                <FormLabel>Enable Slack notifications</FormLabel>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          
                          {form.watch("slackEnabled") && (
                            <FormField
                              control={form.control}
                              name="slackWebhook"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Webhook URL</FormLabel>
                                  <FormControl>
                                    <Input placeholder="https://hooks.slack.com/..." {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          )}
                          
                          {form.watch("slackEnabled") && form.watch("slackWebhook") && (
                            <Button 
                              type="button" 
                              variant="outline" 
                              size="sm" 
                              className="w-full mt-2"
                              onClick={() => testNotificationMutation.mutate("slack")}
                              disabled={testNotificationMutation.isPending}
                            >
                              Send Test Message
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-lg font-medium mb-4">Notification Types</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="notifyOnTradeExecuted"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">
                                  Trade Executed
                                </FormLabel>
                                <FormDescription>
                                  When a trade is executed
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="notifyOnOrderFilled"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">
                                  Order Filled
                                </FormLabel>
                                <FormDescription>
                                  When an order is filled
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="notifyOnOrderCancelled"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">
                                  Order Cancelled
                                </FormLabel>
                                <FormDescription>
                                  When an order is cancelled
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="notifyOnBrokerDisconnect"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">
                                  Broker Disconnection
                                </FormLabel>
                                <FormDescription>
                                  When a broker is disconnected
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="notifyOnRiskEvent"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">
                                  Risk Events
                                </FormLabel>
                                <FormDescription>
                                  When a risk control is triggered
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="notifyOnCopyTradeFailure"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">
                                  Copy Trade Failures
                                </FormLabel>
                                <FormDescription>
                                  When a copy trade fails
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <CardFooter className="flex justify-end border-t pt-6 px-0">
                      <Button 
                        type="submit"
                        disabled={updateSettingsMutation.isPending || !form.formState.isDirty}
                      >
                        {updateSettingsMutation.isPending ? "Saving..." : "Save Settings"}
                      </Button>
                    </CardFooter>
                  </form>
                </Form>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <AccountForm 
        open={showAccountModal} 
        onOpenChange={setShowAccountModal} 
      />
    </div>
  );
}
