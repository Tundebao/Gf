import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { AccountForm } from "@/components/ui/account-form";
import { 
  FileText, 
  LinkIcon, 
  RefreshCw, 
  Search, 
  Download,
  AlertCircle,
  Info,
  CheckCircle,
  Calendar as CalendarIcon
} from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { useWebSocket } from "@/context/WebSocketContext";

export default function Logs() {
  const [showAccountModal, setShowAccountModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [componentFilter, setComponentFilter] = useState<string>("all");
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [currentPage, setCurrentPage] = useState(1);
  const [logsPerPage] = useState(20);
  const { connected } = useWebSocket();
  
  const { 
    data: { brokersConnected = false } = {}, 
    isLoading: isLoadingBrokerStatus 
  } = useQuery<{brokersConnected: boolean}>({
    queryKey: ['/api/brokers/status'],
  });
  
  const { 
    data: { logs = [], total = 0 } = { logs: [], total: 0 }, 
    isLoading: isLoadingLogs,
    refetch: refetchLogs
  } = useQuery<{logs: any[], total: number}>({
    queryKey: ['/api/logs', currentPage, logsPerPage, date?.toISOString().split('T')[0], typeFilter, componentFilter, searchQuery],
    enabled: brokersConnected,
  });

  // Filter logs based on search, type, and component
  const filteredLogs = logs.filter(log => {
    let matches = true;
    
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      matches = matches && (
        log.message.toLowerCase().includes(query) ||
        log.component.toLowerCase().includes(query)
      );
    }
    
    // Apply type filter
    if (typeFilter !== "all") {
      matches = matches && log.type === typeFilter;
    }
    
    // Apply component filter
    if (componentFilter !== "all") {
      matches = matches && log.component === componentFilter;
    }
    
    return matches;
  });

  // Format date for display
  const formattedDate = date ? format(date, "PPP") : "Select date";

  // Get badge variant based on log type
  const getBadgeVariant = (type: string) => {
    switch (type.toLowerCase()) {
      case "error":
        return "destructive";
      case "warning":
        return "warning";
      case "success":
        return "success";
      case "info":
      default:
        return "secondary";
    }
  };

  // Get icon based on log type
  const getTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "error":
        return <AlertCircle className="h-4 w-4" />;
      case "warning":
        return <AlertCircle className="h-4 w-4" />;
      case "success":
        return <CheckCircle className="h-4 w-4" />;
      case "info":
      default:
        return <Info className="h-4 w-4" />;
    }
  };

  // Handle pagination
  const totalPages = Math.ceil(total / logsPerPage);

  const handlePageChange = (page: number) => {
    if (page < 1 || page > totalPages) return;
    setCurrentPage(page);
  };

  // Export logs to CSV
  const exportLogs = () => {
    const csvContent = [
      // CSV header
      ["Timestamp", "Type", "Component", "Message"].join(","),
      // CSV rows
      ...filteredLogs.map(log => [
        new Date(log.timestamp).toISOString(),
        log.type,
        log.component,
        `"${log.message.replace(/"/g, '""')}"`
      ].join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', `logs_export_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (isLoadingBrokerStatus) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  if (!brokersConnected) {
    return (
      <Card className="p-8 text-center">
        <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-slate-100 dark:bg-slate-700 mb-4">
          <FileText className="h-10 w-10 text-slate-500 dark:text-slate-400" />
        </div>
        <h3 className="text-lg font-medium text-slate-900 dark:text-slate-100 mb-2">Broker Connection Required</h3>
        <p className="text-slate-500 dark:text-slate-400 mb-4 max-w-md mx-auto">
          System logs require an active broker connection. Please connect your brokerage account first.
        </p>
        <Button onClick={() => setShowAccountModal(true)}>
          <LinkIcon className="h-4 w-4 mr-2" />
          Connect Broker
        </Button>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <CardTitle>System Logs</CardTitle>
              <CardDescription>
                View detailed system logs and events
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={() => refetchLogs()}
                disabled={isLoadingLogs}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${isLoadingLogs ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <Button 
                variant="outline"
                onClick={exportLogs}
                disabled={filteredLogs.length === 0}
              >
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex flex-col md:flex-row gap-4 items-end">
              <div className="grid gap-2 flex-1">
                <label htmlFor="search" className="text-sm font-medium">Search</label>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-500 dark:text-slate-400" />
                  <Input
                    id="search"
                    type="search"
                    placeholder="Search logs by content or component"
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="grid gap-2 w-full md:w-[180px]">
                <label htmlFor="type" className="text-sm font-medium">Log Type</label>
                <Select
                  value={typeFilter}
                  onValueChange={setTypeFilter}
                >
                  <SelectTrigger id="type">
                    <SelectValue placeholder="All types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All types</SelectItem>
                    <SelectItem value="info">Info</SelectItem>
                    <SelectItem value="success">Success</SelectItem>
                    <SelectItem value="warning">Warning</SelectItem>
                    <SelectItem value="error">Error</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2 w-full md:w-[200px]">
                <label htmlFor="component" className="text-sm font-medium">Component</label>
                <Select
                  value={componentFilter}
                  onValueChange={setComponentFilter}
                >
                  <SelectTrigger id="component">
                    <SelectValue placeholder="All components" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All components</SelectItem>
                    <SelectItem value="auth">Authentication</SelectItem>
                    <SelectItem value="broker">Broker</SelectItem>
                    <SelectItem value="trading">Trading</SelectItem>
                    <SelectItem value="copy-trading">Copy Trading</SelectItem>
                    <SelectItem value="risk">Risk Management</SelectItem>
                    <SelectItem value="system">System</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2 w-full md:w-[240px]">
                <label htmlFor="date" className="text-sm font-medium">Date</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      id="date"
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formattedDate}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            
            {isLoadingLogs ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : filteredLogs.length === 0 ? (
              <div className="text-center py-12 text-slate-500 dark:text-slate-400">
                No logs found matching your criteria
              </div>
            ) : (
              <>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[180px]">Timestamp</TableHead>
                        <TableHead className="w-[100px]">Type</TableHead>
                        <TableHead className="w-[150px]">Component</TableHead>
                        <TableHead>Message</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredLogs.map((log) => (
                        <TableRow key={log.id}>
                          <TableCell className="font-mono text-xs">
                            {new Date(log.timestamp).toLocaleString()}
                          </TableCell>
                          <TableCell>
                            <Badge variant={getBadgeVariant(log.type)} className="flex items-center gap-1">
                              {getTypeIcon(log.type)}
                              {log.type}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {log.component}
                          </TableCell>
                          <TableCell className="font-mono text-xs">
                            {log.message}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                
                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-between pt-4">
                    <div className="text-sm text-slate-500 dark:text-slate-400">
                      Showing {(currentPage - 1) * logsPerPage + 1} to {Math.min(currentPage * logsPerPage, total)} of {total} logs
                    </div>
                    <div className="flex gap-1">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(1)}
                        disabled={currentPage === 1}
                      >
                        First
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                      >
                        Previous
                      </Button>
                      <span className="flex items-center px-3 h-8">
                        {currentPage} / {totalPages}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === totalPages}
                      >
                        Next
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(totalPages)}
                        disabled={currentPage === totalPages}
                      >
                        Last
                      </Button>
                    </div>
                  </div>
                )}
                
                <div className="flex justify-end">
                  <Badge variant={connected ? "success" : "destructive"} className="text-xs">
                    {connected ? "Realtime Updates Active" : "Realtime Updates Disconnected"}
                  </Badge>
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>
      
      <AccountForm 
        open={showAccountModal} 
        onOpenChange={setShowAccountModal} 
      />
    </div>
  );
}
