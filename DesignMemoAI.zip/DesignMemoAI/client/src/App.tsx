import { Switch, Route, useLocation } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import Accounts from "@/pages/accounts";
import ManualTrading from "@/pages/manual-trading";
import CopyTrading from "@/pages/copy-trading";
import Trades from "@/pages/trades";
import Symbols from "@/pages/symbols";
import RiskSettings from "@/pages/risk-settings";
import NotificationsPage from "@/pages/notifications";
import Logs from "@/pages/logs";
import Settings from "@/pages/settings";
import { useAuth, AuthProvider } from "@/context/AuthContext";
import { WebSocketProvider } from "@/context/WebSocketContext";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import AppLayout from "@/components/Layout/AppLayout";
import { useBrokerStatus } from "@/hooks/use-broker-status";
import { useEffect, useState, useCallback } from "react";

// Create a custom Redirect component since wouter doesn't export one directly
function Redirect({ to }: { to: string }) {
  const [, navigate] = useLocation();
  
  useEffect(() => {
    navigate(to);
  }, [to, navigate]);
  
  return null;
}

function ProtectedRoutes() {
  // Use the broker status hook at the top level to ensure it's always active
  // This will keep the broker status query fresh across all child components
  const { refetch: refreshBrokerStatus } = useBrokerStatus();
  
  // Refresh broker status on route changes
  useEffect(() => {
    console.log("[App] Routes mounted/changed, refreshing broker status");
    refreshBrokerStatus();
    
    // Set up interval for frequent checks
    const intervalId = setInterval(() => {
      refreshBrokerStatus();
    }, 5000);
    
    return () => clearInterval(intervalId);
  }, [refreshBrokerStatus]);
  
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/accounts" component={Accounts} />
        <Route path="/manual-trading" component={ManualTrading} />
        <Route path="/copy-trading" component={CopyTrading} />
        <Route path="/trades" component={Trades} />
        <Route path="/symbols" component={Symbols} />
        <Route path="/risk-settings" component={RiskSettings} />
        <Route path="/notifications" component={NotificationsPage} />
        <Route path="/logs" component={Logs} />
        <Route path="/settings" component={Settings} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function Router() {
  const { isAuthenticated, isLoading, error, user } = useAuth();
  const [timeoutOccurred, setTimeoutOccurred] = useState(false);
  const [, navigate] = useLocation();
  const [forceLogin, setForceLogin] = useState(false);

  // Simple way to detect the current route
  const isLoginPage = window.location.pathname === '/login';
  const isDashboardPage = window.location.pathname === '/dashboard';
  
  // Force redirect to login page when needed
  const redirectToLogin = () => {
    if (process.env.NODE_ENV === 'development') {
      console.log("Hard redirect to login");
      // In development, do a full page refresh to avoid router issues
      window.location.href = '/login';
    } else {
      navigate('/login');
    }
  };
  
  // Force redirect to dashboard when needed
  const redirectToDashboard = () => {
    if (process.env.NODE_ENV === 'development') {
      console.log("Hard redirect to dashboard");
      // In development, do a full page refresh to avoid router issues
      window.location.href = '/dashboard';
    } else {
      navigate('/dashboard');
    }
  };

  // Add a much shorter safety timeout to avoid infinite loading
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (isLoading) {
        console.log("Loading timeout occurred - reducing timeout to 1 second");
        setTimeoutOccurred(true);
        setForceLogin(false); // Don't force login, allow normal flow
      }
    }, 1000); // Much shorter timeout (1 second instead of 3)
    
    return () => clearTimeout(timeoutId);
  }, [isLoading]);

  // Debug logging
  useEffect(() => {
    console.log("Auth state changed:", { 
      isAuthenticated, 
      isLoading, 
      timeoutOccurred, 
      forceLogin,
      page: window.location.pathname 
    });
  }, [isAuthenticated, isLoading, timeoutOccurred, forceLogin]);

  // Handle loading state
  if (isLoading && !timeoutOccurred) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-900 text-white">
        <div className="animate-spin w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full mb-4"></div>
        <div className="text-sm">Loading application...</div>
        <div className="text-xs mt-2 text-slate-400">If loading takes too long, you'll be redirected to login.</div>
      </div>
    );
  }

  // Handle authentication errors
  if (error || forceLogin) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-900 text-white">
        {error && (
          <>
            <div className="text-red-500 mb-2">Authentication Error</div>
            <div className="text-sm mb-4">{error}</div>
          </>
        )}
        {forceLogin && !error && (
          <>
            <div className="text-orange-500 mb-2">Session Timeout</div>
            <div className="text-sm mb-4">Loading took too long, please log in again.</div>
          </>
        )}
        <div className="flex space-x-4">
          <button 
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Retry
          </button>
          <button 
            onClick={() => window.location.href = '/login'}
            className="px-4 py-2 bg-slate-600 text-white rounded hover:bg-slate-700"
          >
            Go to Login
          </button>
        </div>
      </div>
    );
  }

  // Simple routing logic to minimize complexity
  
  // Return Login component for login page
  if (isLoginPage) {
    return <Login />;
  }
  
  // Return ProtectedRoutes for all other routes if authenticated
  if (isAuthenticated) {
    return <ProtectedRoutes />;
  }
  
  // If we get here, user is not authenticated and not on login page
  // Redirect them to login
  redirectToLogin();
  return <div>Redirecting to login...</div>;
}

function App() {
  return (
    <TooltipProvider>
      <Toaster />
      <Router />
    </TooltipProvider>
  );
}

export default App;
