import {
  users, type User, type InsertUser,
  brokers, type Broker, type InsertBroker,
  symbols, type Symbol, type InsertSymbol,
  optionStrategies, type OptionStrategy, type InsertOptionStrategy,
  orders, type Order, type InsertOrder,
  positions, type Position, type InsertPosition,
  riskSettings, type RiskSetting, type InsertRiskSetting,
  riskEvents, type RiskEvent, type InsertRiskEvent,
  copyTradingSettings, type CopyTradingSetting, type InsertCopyTradingSetting,
  copyTradingLogs, type CopyTradingLog, type InsertCopyTradingLog,
  systemLogs, type SystemLog, type InsertSystemLog,
  notifications, type Notification, type InsertNotification,
  notificationSettings, type NotificationSetting, type InsertNotificationSetting,
  generalSettings, type GeneralSetting, type InsertGeneralSetting,
  apiSettings, type ApiSetting, type InsertApiSetting,
  sessions, type Session, type InsertSession
} from "@shared/schema";

// Storage interface for all database operations
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Broker methods
  getBrokers(): Promise<Broker[]>;
  getBroker(id: number): Promise<Broker | undefined>;
  createBroker(broker: InsertBroker): Promise<Broker>;
  updateBroker(id: number, broker: Partial<Broker>): Promise<Broker | undefined>;
  deleteBroker(id: number): Promise<boolean>;
  
  // Symbol methods
  getSymbols(): Promise<Symbol[]>;
  getSymbol(id: number): Promise<Symbol | undefined>;
  getSymbolByName(symbol: string): Promise<Symbol | undefined>;
  createSymbol(symbol: InsertSymbol): Promise<Symbol>;
  updateSymbol(id: number, symbol: Partial<Symbol>): Promise<Symbol | undefined>;
  deleteSymbol(id: number): Promise<boolean>;
  
  // Option strategy methods
  getOptionStrategies(): Promise<OptionStrategy[]>;
  getOptionStrategy(id: number): Promise<OptionStrategy | undefined>;
  createOptionStrategy(strategy: InsertOptionStrategy): Promise<OptionStrategy>;
  deleteOptionStrategy(id: number): Promise<boolean>;
  
  // Order methods
  getOrders(): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, order: Partial<Order>): Promise<Order | undefined>;
  deleteOrder(id: number): Promise<boolean>;
  
  // Position methods
  getPositions(): Promise<Position[]>;
  getPosition(id: number): Promise<Position | undefined>;
  createPosition(position: InsertPosition): Promise<Position>;
  updatePosition(id: number, position: Partial<Position>): Promise<Position | undefined>;
  deletePosition(id: number): Promise<boolean>;
  
  // Risk settings methods
  getRiskSettings(): Promise<RiskSetting[]>;
  getRiskSetting(id: number): Promise<RiskSetting | undefined>;
  getRiskSettingByBrokerId(brokerId: number): Promise<RiskSetting | undefined>;
  createRiskSetting(setting: InsertRiskSetting): Promise<RiskSetting>;
  updateRiskSetting(id: number, setting: Partial<RiskSetting>): Promise<RiskSetting | undefined>;
  
  // Risk events methods
  getRiskEvents(): Promise<RiskEvent[]>;
  getRiskEvent(id: number): Promise<RiskEvent | undefined>;
  createRiskEvent(event: InsertRiskEvent): Promise<RiskEvent>;
  updateRiskEvent(id: number, event: Partial<RiskEvent>): Promise<RiskEvent | undefined>;
  
  // Copy trading settings methods
  getCopyTradingSettings(): Promise<CopyTradingSetting | undefined>;
  createOrUpdateCopyTradingSettings(settings: InsertCopyTradingSetting): Promise<CopyTradingSetting>;
  
  // Copy trading logs methods
  getCopyTradingLogs(): Promise<CopyTradingLog[]>;
  createCopyTradingLog(log: InsertCopyTradingLog): Promise<CopyTradingLog>;
  
  // System logs methods
  getSystemLogs(limit?: number, offset?: number): Promise<SystemLog[]>;
  getSystemLogCount(): Promise<number>;
  createSystemLog(log: InsertSystemLog): Promise<SystemLog>;
  
  // Notification methods
  getNotifications(): Promise<Notification[]>;
  getUnreadNotifications(): Promise<Notification[]>;
  getNotification(id: number): Promise<Notification | undefined>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<boolean>;
  markAllNotificationsAsRead(): Promise<boolean>;
  deleteNotification(id: number): Promise<boolean>;
  deleteAllNotifications(): Promise<boolean>;
  
  // Notification settings methods
  getNotificationSettings(): Promise<NotificationSetting | undefined>;
  createOrUpdateNotificationSettings(settings: InsertNotificationSetting): Promise<NotificationSetting>;
  
  // General settings methods
  getGeneralSettings(): Promise<GeneralSetting | undefined>;
  createOrUpdateGeneralSettings(settings: InsertGeneralSetting): Promise<GeneralSetting>;
  
  // API settings methods
  getApiSettings(): Promise<ApiSetting | undefined>;
  createOrUpdateApiSettings(settings: InsertApiSetting): Promise<ApiSetting>;
  
  // Session methods
  createSession(session: InsertSession): Promise<Session>;
  getSessionByToken(token: string): Promise<Session | undefined>;
  deleteSession(id: number): Promise<boolean>;
  deleteSessionsByUserId(userId: number): Promise<boolean>;
  
  // Initialize default settings
  initializeSettings(): Promise<void>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private brokers: Map<number, Broker>;
  private symbols: Map<number, Symbol>;
  private optionStrategies: Map<number, OptionStrategy>;
  private orders: Map<number, Order>;
  private positions: Map<number, Position>;
  private riskSettings: Map<number, RiskSetting>;
  private riskEvents: Map<number, RiskEvent>;
  private copyTradingSettings: CopyTradingSetting | undefined;
  private copyTradingLogs: Map<number, CopyTradingLog>;
  private systemLogs: Map<number, SystemLog>;
  private notifications: Map<number, Notification>;
  private notificationSettings: NotificationSetting | undefined;
  private generalSettings: GeneralSetting | undefined;
  private apiSettings: ApiSetting | undefined;
  private sessions: Map<number, Session>;
  
  private nextIds: {
    users: number;
    brokers: number;
    symbols: number;
    optionStrategies: number;
    orders: number;
    positions: number;
    riskSettings: number;
    riskEvents: number;
    copyTradingSettings: number;
    copyTradingLogs: number;
    systemLogs: number;
    notifications: number;
    notificationSettings: number;
    generalSettings: number;
    apiSettings: number;
    sessions: number;
  };

  constructor() {
    this.users = new Map();
    this.brokers = new Map();
    this.symbols = new Map();
    this.optionStrategies = new Map();
    this.orders = new Map();
    this.positions = new Map();
    this.riskSettings = new Map();
    this.riskEvents = new Map();
    this.copyTradingLogs = new Map();
    this.systemLogs = new Map();
    this.notifications = new Map();
    this.sessions = new Map();
    
    this.nextIds = {
      users: 1,
      brokers: 1,
      symbols: 1,
      optionStrategies: 1,
      orders: 1,
      positions: 1,
      riskSettings: 1,
      riskEvents: 1,
      copyTradingSettings: 1,
      copyTradingLogs: 1,
      systemLogs: 1,
      notifications: 1,
      notificationSettings: 1,
      generalSettings: 1,
      apiSettings: 1,
      sessions: 1
    };
    
    // Add system start log
    this.createSystemLog({
      type: "info",
      component: "system",
      message: "System started"
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.nextIds.users++;
    const createdAt = new Date();
    const user: User = { 
      ...userData, 
      id,
      createdAt
    };
    this.users.set(id, user);
    return user;
  }
  
  // Broker methods
  async getBrokers(): Promise<Broker[]> {
    return Array.from(this.brokers.values());
  }
  
  async getBroker(id: number): Promise<Broker | undefined> {
    return this.brokers.get(id);
  }
  
  async createBroker(brokerData: InsertBroker): Promise<Broker> {
    const id = this.nextIds.brokers++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const broker: Broker = {
      ...brokerData,
      id,
      connected: false,
      createdAt,
      updatedAt
    };
    this.brokers.set(id, broker);
    
    // Create default risk settings for this broker
    await this.createRiskSetting({
      brokerId: id,
      maxDailyLoss: 1000,
      maxPositionSize: 100,
      maxPositionValue: 10000,
      maxLeverage: 1,
      enforceStopLoss: false
    });
    
    // Log broker creation
    await this.createSystemLog({
      type: "info",
      component: "broker",
      message: `Broker ${brokerData.type} account ${brokerData.accountId} added with role ${brokerData.role}`
    });
    
    return broker;
  }
  
  async updateBroker(id: number, brokerData: Partial<Broker>): Promise<Broker | undefined> {
    const broker = this.brokers.get(id);
    if (!broker) return undefined;
    
    const updatedBroker = {
      ...broker,
      ...brokerData,
      updatedAt: new Date()
    };
    
    this.brokers.set(id, updatedBroker);
    return updatedBroker;
  }
  
  async deleteBroker(id: number): Promise<boolean> {
    const broker = this.brokers.get(id);
    if (!broker) return false;
    
    // Log broker deletion
    await this.createSystemLog({
      type: "info",
      component: "broker",
      message: `Broker ${broker.type} account ${broker.accountId} removed`
    });
    
    return this.brokers.delete(id);
  }
  
  // Symbol methods
  async getSymbols(): Promise<Symbol[]> {
    return Array.from(this.symbols.values());
  }
  
  async getSymbol(id: number): Promise<Symbol | undefined> {
    return this.symbols.get(id);
  }
  
  async getSymbolByName(symbolName: string): Promise<Symbol | undefined> {
    return Array.from(this.symbols.values()).find(
      (symbol) => symbol.symbol.toUpperCase() === symbolName.toUpperCase(),
    );
  }
  
  async createSymbol(symbolData: InsertSymbol): Promise<Symbol> {
    const id = this.nextIds.symbols++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const symbol: Symbol = {
      ...symbolData,
      id,
      createdAt,
      updatedAt
    };
    this.symbols.set(id, symbol);
    return symbol;
  }
  
  async updateSymbol(id: number, symbolData: Partial<Symbol>): Promise<Symbol | undefined> {
    const symbol = this.symbols.get(id);
    if (!symbol) return undefined;
    
    const updatedSymbol = {
      ...symbol,
      ...symbolData,
      updatedAt: new Date()
    };
    
    this.symbols.set(id, updatedSymbol);
    return updatedSymbol;
  }
  
  async deleteSymbol(id: number): Promise<boolean> {
    return this.symbols.delete(id);
  }
  
  // Option strategy methods
  async getOptionStrategies(): Promise<OptionStrategy[]> {
    return Array.from(this.optionStrategies.values());
  }
  
  async getOptionStrategy(id: number): Promise<OptionStrategy | undefined> {
    return this.optionStrategies.get(id);
  }
  
  async createOptionStrategy(strategyData: InsertOptionStrategy): Promise<OptionStrategy> {
    const id = this.nextIds.optionStrategies++;
    const createdAt = new Date();
    const strategy: OptionStrategy = {
      ...strategyData,
      id,
      createdAt
    };
    this.optionStrategies.set(id, strategy);
    return strategy;
  }
  
  async deleteOptionStrategy(id: number): Promise<boolean> {
    return this.optionStrategies.delete(id);
  }
  
  // Order methods
  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }
  
  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }
  
  async createOrder(orderData: InsertOrder): Promise<Order> {
    const id = this.nextIds.orders++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const order: Order = {
      ...orderData,
      id,
      filledQuantity: 0,
      createdAt,
      updatedAt
    };
    this.orders.set(id, order);
    
    // Log order creation
    const broker = await this.getBroker(orderData.brokerId);
    await this.createSystemLog({
      type: "info",
      component: "trading",
      message: `New ${orderData.action} order created for ${orderData.quantity} ${orderData.symbol} on account ${broker?.accountId}`
    });
    
    return order;
  }
  
  async updateOrder(id: number, orderData: Partial<Order>): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updatedOrder = {
      ...order,
      ...orderData,
      updatedAt: new Date()
    };
    
    this.orders.set(id, updatedOrder);
    
    // Log order update if status changed
    if (orderData.status && orderData.status !== order.status) {
      const broker = await this.getBroker(order.brokerId);
      await this.createSystemLog({
        type: orderData.status === "filled" ? "success" : "info",
        component: "trading",
        message: `Order ${id} for ${order.symbol} changed to ${orderData.status} on account ${broker?.accountId}`
      });
      
      // Create notification for filled orders
      if (orderData.status === "filled") {
        await this.createNotification({
          title: "Order Filled",
          message: `Your ${order.action} order for ${order.quantity} ${order.symbol} has been filled`,
          type: "success"
        });
      }
    }
    
    return updatedOrder;
  }
  
  async deleteOrder(id: number): Promise<boolean> {
    return this.orders.delete(id);
  }
  
  // Position methods
  async getPositions(): Promise<Position[]> {
    return Array.from(this.positions.values());
  }
  
  async getPosition(id: number): Promise<Position | undefined> {
    return this.positions.get(id);
  }
  
  async createPosition(positionData: InsertPosition): Promise<Position> {
    const id = this.nextIds.positions++;
    const openDate = new Date();
    const updatedAt = new Date();
    const position: Position = {
      ...positionData,
      id,
      openDate,
      updatedAt
    };
    this.positions.set(id, position);
    return position;
  }
  
  async updatePosition(id: number, positionData: Partial<Position>): Promise<Position | undefined> {
    const position = this.positions.get(id);
    if (!position) return undefined;
    
    const updatedPosition = {
      ...position,
      ...positionData,
      updatedAt: new Date()
    };
    
    this.positions.set(id, updatedPosition);
    return updatedPosition;
  }
  
  async deletePosition(id: number): Promise<boolean> {
    return this.positions.delete(id);
  }
  
  // Risk settings methods
  async getRiskSettings(): Promise<RiskSetting[]> {
    return Array.from(this.riskSettings.values());
  }
  
  async getRiskSetting(id: number): Promise<RiskSetting | undefined> {
    return this.riskSettings.get(id);
  }
  
  async getRiskSettingByBrokerId(brokerId: number): Promise<RiskSetting | undefined> {
    return Array.from(this.riskSettings.values()).find(
      (setting) => setting.brokerId === brokerId,
    );
  }
  
  async createRiskSetting(settingData: InsertRiskSetting): Promise<RiskSetting> {
    const id = this.nextIds.riskSettings++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const setting: RiskSetting = {
      ...settingData,
      id,
      createdAt,
      updatedAt
    };
    this.riskSettings.set(id, setting);
    return setting;
  }
  
  async updateRiskSetting(id: number, settingData: Partial<RiskSetting>): Promise<RiskSetting | undefined> {
    const setting = this.riskSettings.get(id);
    if (!setting) return undefined;
    
    const updatedSetting = {
      ...setting,
      ...settingData,
      updatedAt: new Date()
    };
    
    this.riskSettings.set(id, updatedSetting);
    return updatedSetting;
  }
  
  // Risk events methods
  async getRiskEvents(): Promise<RiskEvent[]> {
    return Array.from(this.riskEvents.values()).sort((a, b) => {
      return b.timestamp.getTime() - a.timestamp.getTime();
    });
  }
  
  async getRiskEvent(id: number): Promise<RiskEvent | undefined> {
    return this.riskEvents.get(id);
  }
  
  async createRiskEvent(eventData: InsertRiskEvent): Promise<RiskEvent> {
    const id = this.nextIds.riskEvents++;
    const timestamp = new Date();
    const event: RiskEvent = {
      ...eventData,
      id,
      timestamp
    };
    this.riskEvents.set(id, event);
    
    // Create notification for risk events
    await this.createNotification({
      title: "Risk Event Triggered",
      message: eventData.description,
      type: "warning"
    });
    
    return event;
  }
  
  async updateRiskEvent(id: number, eventData: Partial<RiskEvent>): Promise<RiskEvent | undefined> {
    const event = this.riskEvents.get(id);
    if (!event) return undefined;
    
    const updatedEvent = {
      ...event,
      ...eventData,
    };
    
    if (eventData.active === false) {
      updatedEvent.resolvedAt = new Date();
    }
    
    this.riskEvents.set(id, updatedEvent);
    return updatedEvent;
  }
  
  // Copy trading settings methods
  async getCopyTradingSettings(): Promise<CopyTradingSetting | undefined> {
    return this.copyTradingSettings;
  }
  
  async createOrUpdateCopyTradingSettings(settingsData: InsertCopyTradingSetting): Promise<CopyTradingSetting> {
    const updatedAt = new Date();
    
    if (!this.copyTradingSettings) {
      // Create new settings
      const id = this.nextIds.copyTradingSettings++;
      this.copyTradingSettings = {
        ...settingsData,
        id,
        updatedAt
      };
    } else {
      // Update existing settings
      this.copyTradingSettings = {
        ...this.copyTradingSettings,
        ...settingsData,
        updatedAt
      };
      
      // Set startedAt timestamp if copy trading is started
      if (settingsData.isRunning && !this.copyTradingSettings.startedAt) {
        this.copyTradingSettings.startedAt = new Date();
      } else if (settingsData.isRunning === false) {
        this.copyTradingSettings.startedAt = undefined;
      }
    }
    
    return this.copyTradingSettings;
  }
  
  // Copy trading logs methods
  async getCopyTradingLogs(): Promise<CopyTradingLog[]> {
    return Array.from(this.copyTradingLogs.values()).sort((a, b) => {
      return b.timestamp.getTime() - a.timestamp.getTime();
    });
  }
  
  async createCopyTradingLog(logData: InsertCopyTradingLog): Promise<CopyTradingLog> {
    const id = this.nextIds.copyTradingLogs++;
    const timestamp = new Date();
    const log: CopyTradingLog = {
      ...logData,
      id,
      timestamp
    };
    this.copyTradingLogs.set(id, log);
    
    // Create a system log entry too
    await this.createSystemLog({
      type: logData.success ? "success" : "error",
      component: "copy-trading",
      message: logData.message
    });
    
    // Create notification for failed copy trades
    if (!logData.success) {
      await this.createNotification({
        title: "Copy Trade Failed",
        message: logData.message,
        type: "error"
      });
    }
    
    return log;
  }
  
  // System logs methods
  async getSystemLogs(limit: number = 100, offset: number = 0): Promise<SystemLog[]> {
    return Array.from(this.systemLogs.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(offset, offset + limit);
  }
  
  async getSystemLogCount(): Promise<number> {
    return this.systemLogs.size;
  }
  
  async createSystemLog(logData: InsertSystemLog): Promise<SystemLog> {
    const id = this.nextIds.systemLogs++;
    const timestamp = new Date();
    const log: SystemLog = {
      ...logData,
      id,
      timestamp
    };
    this.systemLogs.set(id, log);
    return log;
  }
  
  // Notification methods
  async getNotifications(): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async getUnreadNotifications(): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(notification => !notification.read)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async getNotification(id: number): Promise<Notification | undefined> {
    return this.notifications.get(id);
  }
  
  async createNotification(notificationData: InsertNotification): Promise<Notification> {
    const id = this.nextIds.notifications++;
    const createdAt = new Date();
    const notification: Notification = {
      ...notificationData,
      id,
      read: false,
      createdAt
    };
    this.notifications.set(id, notification);
    return notification;
  }
  
  async markNotificationAsRead(id: number): Promise<boolean> {
    const notification = this.notifications.get(id);
    if (!notification) return false;
    
    notification.read = true;
    this.notifications.set(id, notification);
    return true;
  }
  
  async markAllNotificationsAsRead(): Promise<boolean> {
    for (const notification of this.notifications.values()) {
      notification.read = true;
    }
    return true;
  }
  
  async deleteNotification(id: number): Promise<boolean> {
    return this.notifications.delete(id);
  }
  
  async deleteAllNotifications(): Promise<boolean> {
    this.notifications.clear();
    return true;
  }
  
  // Notification settings methods
  async getNotificationSettings(): Promise<NotificationSetting | undefined> {
    return this.notificationSettings;
  }
  
  async createOrUpdateNotificationSettings(settingsData: InsertNotificationSetting): Promise<NotificationSetting> {
    const updatedAt = new Date();
    
    if (!this.notificationSettings) {
      // Create new settings
      const id = this.nextIds.notificationSettings++;
      this.notificationSettings = {
        ...settingsData,
        id,
        updatedAt
      };
    } else {
      // Update existing settings
      this.notificationSettings = {
        ...this.notificationSettings,
        ...settingsData,
        updatedAt
      };
    }
    
    return this.notificationSettings;
  }
  
  // General settings methods
  async getGeneralSettings(): Promise<GeneralSetting | undefined> {
    return this.generalSettings;
  }
  
  async createOrUpdateGeneralSettings(settingsData: InsertGeneralSetting): Promise<GeneralSetting> {
    const updatedAt = new Date();
    
    if (!this.generalSettings) {
      // Create new settings
      const id = this.nextIds.generalSettings++;
      this.generalSettings = {
        ...settingsData,
        id,
        updatedAt
      };
    } else {
      // Update existing settings
      this.generalSettings = {
        ...this.generalSettings,
        ...settingsData,
        updatedAt
      };
    }
    
    return this.generalSettings;
  }
  
  // API settings methods
  async getApiSettings(): Promise<ApiSetting | undefined> {
    return this.apiSettings;
  }
  
  async createOrUpdateApiSettings(settingsData: InsertApiSetting): Promise<ApiSetting> {
    const updatedAt = new Date();
    
    if (!this.apiSettings) {
      // Create new settings
      const id = this.nextIds.apiSettings++;
      this.apiSettings = {
        ...settingsData,
        id,
        updatedAt
      };
    } else {
      // Update existing settings
      this.apiSettings = {
        ...this.apiSettings,
        ...settingsData,
        updatedAt
      };
    }
    
    return this.apiSettings;
  }
  
  // Session methods
  async createSession(sessionData: InsertSession): Promise<Session> {
    const id = this.nextIds.sessions++;
    const createdAt = new Date();
    const session: Session = {
      ...sessionData,
      id,
      createdAt
    };
    this.sessions.set(id, session);
    return session;
  }
  
  async getSessionByToken(token: string): Promise<Session | undefined> {
    return Array.from(this.sessions.values()).find(
      (session) => session.token === token,
    );
  }
  
  async deleteSession(id: number): Promise<boolean> {
    return this.sessions.delete(id);
  }
  
  async deleteSessionsByUserId(userId: number): Promise<boolean> {
    for (const [id, session] of this.sessions.entries()) {
      if (session.userId === userId) {
        this.sessions.delete(id);
      }
    }
    return true;
  }
  
  // Initialize default settings
  async initializeSettings(): Promise<void> {
    // Initialize general settings if they don't exist
    if (!this.generalSettings) {
      await this.createOrUpdateGeneralSettings({
        timezone: "America/New_York",
        dateFormat: "MM/DD/YYYY",
        timeFormat: "12h",
        copyTradeDelay: 0,
        defaultTradingHours: {
          start: "09:30",
          end: "16:00"
        },
        autoRefresh: true,
        refreshInterval: 30
      });
    }
    
    // Initialize API settings if they don't exist
    if (!this.apiSettings) {
      await this.createOrUpdateApiSettings({
        webhookEnabled: false,
        webhookUrl: "",
        webhookSecret: ""
      });
    }
    
    // Initialize notification settings if they don't exist
    if (!this.notificationSettings) {
      await this.createOrUpdateNotificationSettings({
        emailEnabled: false,
        emailAddress: "",
        smsEnabled: false,
        phoneNumber: "",
        slackEnabled: false,
        slackWebhook: "",
        notifyOnTradeExecuted: true,
        notifyOnOrderFilled: true,
        notifyOnOrderCancelled: true,
        notifyOnBrokerDisconnect: true,
        notifyOnRiskEvent: true,
        notifyOnCopyTradeFailure: true
      });
    }
    
    // Initialize copy trading settings if they don't exist
    if (!this.copyTradingSettings) {
      await this.createOrUpdateCopyTradingSettings({
        isRunning: false,
        mode: "exact",
        delay: 0,
        handlePartialFills: true,
        autoStart: false
      });
    }
  }
}

export const storage = new MemStorage();
