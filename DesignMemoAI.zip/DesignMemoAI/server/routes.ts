import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { WebSocketServer } from "ws";
import WebSocket from "ws";
import session from "express-session";
import MemoryStore from "memorystore";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import jwt from "jsonwebtoken";

// Import services
import { setupAuthRoutes } from "./services/auth";
import { setupBrokerRoutes } from "./services/broker";
import { setupTradingRoutes } from "./services/trading";
import { setupWebSocketServer } from "./services/websocket";
import { setupOrderRoutes } from "./services/orderRoutes";
import { setupCopyTradingRoutes } from "./services/copyTradingRoutes";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Initialize WebSocket server on a distinct path
  const wss = new WebSocketServer({ 
    server: httpServer, 
    path: '/ws',
    // Allow all origins
    verifyClient: (info, cb) => {
      // Always allow connections
      cb(true);
    },
    // Make sure WebSocket is also accessible
    host: '0.0.0.0'
  });
  
  // Setup WebSocket handling
  setupWebSocketServer(wss);
  
  // Configure session middleware
  const MemoryStoreSession = MemoryStore(session);
  app.use(session({
    secret: process.env.JWT_SECRET || 'default_jwt_secret_key_for_development',
    resave: false,
    saveUninitialized: false,
    cookie: { 
      secure: process.env.NODE_ENV === 'production',
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    },
    store: new MemoryStoreSession({
      checkPeriod: 86400000 // prune expired entries every 24h
    })
  }));
  
  // Configure passport for authentication
  app.use(passport.initialize());
  app.use(passport.session());
  
  // Configure passport local strategy
  passport.use(new LocalStrategy(async (username, password, done) => {
    try {
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return done(null, false, { message: 'Invalid username or password' });
      }
      
      // In a real app, you'd use a proper password comparison with bcrypt
      // For simplicity, we're using direct comparison here
      if (user.password !== password) {
        return done(null, false, { message: 'Invalid username or password' });
      }
      
      return done(null, user);
    } catch (error) {
      return done(error);
    }
  }));
  
  // Serialize user for session
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });
  
  // Deserialize user from session
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });
  
  // Setup API routes grouped by functionality
  setupAuthRoutes(app);
  setupBrokerRoutes(app);
  setupTradingRoutes(app);
  setupOrderRoutes(app);
  await setupCopyTradingRoutes(app);
  
  // Add default admin user if none exists
  try {
    const adminExists = await storage.getUserByUsername('admin');
    if (!adminExists) {
      await storage.createUser({
        username: 'admin',
        password: 'admin', // This should be properly hashed in production
        isAdmin: true
      });
      console.log('Created default admin user');
    }
  } catch (error) {
    console.error('Error creating default admin user:', error);
  }
  
  // Add initial settings if they don't exist
  try {
    await storage.initializeSettings();
  } catch (error) {
    console.error('Error initializing settings:', error);
  }
  
  // Middleware to check if user is authenticated
  const isAuthenticated = (req: any, res: any, next: any) => {
    // Check JWT token in Authorization header
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'default_jwt_secret_key_for_development');
        req.user = decoded;
        return next();
      } catch (error) {
        // If token is invalid, check session
        if (req.isAuthenticated()) {
          return next();
        }
        return res.status(401).json({ message: 'Unauthorized' });
      }
    } else if (req.isAuthenticated()) {
      // If no token, check session
      return next();
    }
    
    return res.status(401).json({ message: 'Unauthorized' });
  };
  
  // Root API route
  app.get('/api', (_req, res) => {
    res.json({ message: 'TradeCopy Pro API' });
  });
  
  // Health check endpoint to confirm the server is running and accessible
  app.get('/health', (_req, res) => {
    res.status(200).json({ 
      status: 'ok',
      message: 'Server is running',
      timestamp: new Date().toISOString()
    });
  });
  
  // Catch-all route for missing endpoints
  app.use('/api/*', (_req, res) => {
    res.status(404).json({ message: 'API endpoint not found' });
  });
  
  return httpServer;
}
