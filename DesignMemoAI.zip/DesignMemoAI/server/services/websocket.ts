import { WebSocketServer } from 'ws';
import WebSocket from 'ws';
import { storage } from '../storage';
import jwt from 'jsonwebtoken';
import { URL } from 'url';

// Extend WebSocket type to add isAlive property
declare module 'ws' {
  interface WebSocket {
    isAlive?: boolean;
  }
}

// Map to store active WebSocket connections
const clients = new Map<string, WebSocket>();
// Map to store authenticated user data
const authenticatedClients = new Map<string, any>();

// Store channels that clients are subscribed to
const clientSubscriptions = new Map<string, Set<string>>();

// Store heartbeat intervals
const heartbeatIntervals = new Map<string, NodeJS.Timeout>();

// Function to cleanup client resources when disconnected
function cleanupClient(clientId: string) {
  // Remove client from all maps
  clients.delete(clientId);
  authenticatedClients.delete(clientId);
  
  // Remove from subscriptions
  subscriptions.delete(clientId);
  
  // Clear any heartbeat intervals
  const intervalId = heartbeatIntervals.get(clientId);
  if (intervalId) {
    clearInterval(intervalId);
    heartbeatIntervals.delete(clientId);
  }
  
  console.log(`Cleaned up resources for client ${clientId}`);
}

export function setupWebSocketServer(wss: WebSocketServer) {
  // Setup server heartbeat mechanism to keep connections alive
  const heartbeatInterval = setInterval(() => {
    const timestamp = new Date().toISOString();
    
    // Send heartbeat to all connected clients
    clients.forEach((client, clientId) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({
          type: 'heartbeat',
          data: { timestamp }
        }));
      } else if (client.readyState === WebSocket.CLOSED || client.readyState === WebSocket.CLOSING) {
        // Clean up closed connections
        cleanupClient(clientId);
      }
    });
  }, 30000); // Send heartbeat every 30 seconds
  
  // Clean up on server shutdown
  wss.on('close', () => {
    clearInterval(heartbeatInterval);
    
    // Clean up all client heartbeat intervals
    heartbeatIntervals.forEach((interval) => {
      clearInterval(interval);
    });
    
    // Close all client connections
    clients.forEach((client) => {
      try {
        client.close();
      } catch (e) {
        // Ignore errors on close
      }
    });
    
    // Clear all maps
    clients.clear();
    authenticatedClients.clear();
    clientSubscriptions.clear();
    heartbeatIntervals.clear();
  });
  
  // Setup WebSocket connection handler
  wss.on('connection', (ws: WebSocket, req) => {
    // Generate a unique client ID or extract from request
    const clientId = req.headers['sec-websocket-key'] as string;
    
    console.log(`WebSocket client connected: ${clientId}`);
    
    // Add ping/pong protocol for connection management
    ws.isAlive = true;
    ws.on('pong', () => {
      ws.isAlive = true;
    });
    
    // Check for token in URL query parameters
    try {
      if (req.url) {
        const parsedUrl = new URL(`http://localhost${req.url}`);
        const token = parsedUrl.searchParams.get('token');
        
        if (token) {
          // Verify token
          try {
            const secret = process.env.JWT_SECRET || 'default_jwt_secret_key_for_development';
            const decoded = jwt.verify(token, secret);
            authenticatedClients.set(clientId, decoded);
            console.log(`Client ${clientId} authenticated via URL token`);
          } catch (error) {
            console.error(`Invalid token in URL for client ${clientId}:`, error);
          }
        }
      }
    } catch (error) {
      console.error(`Error parsing WebSocket URL for client ${clientId}:`, error);
    }
    
    // Store client connection
    clients.set(clientId, ws);
    
    // Send initial connection status
    ws.send(JSON.stringify({
      type: 'status',
      data: { 
        connected: true,
        authenticated: authenticatedClients.has(clientId)
      }
    }));
    
    // Handle client messages
    ws.on('message', async (message: string) => {
      try {
        const data = JSON.parse(message);
        console.log(`Received message from ${clientId}:`, data);
        
        // Check for token in the message
        if (data.token && !authenticatedClients.has(clientId)) {
          try {
            const secret = process.env.JWT_SECRET || 'default_jwt_secret_key_for_development';
            const decoded = jwt.verify(data.token, secret);
            authenticatedClients.set(clientId, decoded);
            console.log(`Client ${clientId} authenticated via message token`);
            
            // Send updated auth status
            ws.send(JSON.stringify({
              type: 'status',
              data: { 
                connected: true,
                authenticated: true
              }
            }));
          } catch (error) {
            console.error(`Invalid token in message for client ${clientId}:`, error);
          }
        }
        
        // Handle different message types
        switch (data.type) {
          case 'ping':
            ws.send(JSON.stringify({
              type: 'pong',
              data: { 
                timestamp: new Date().toISOString(),
                authenticated: authenticatedClients.has(clientId)
              }
            }));
            break;
          
          case 'subscribe':
            // Subscribe to specific events
            handleSubscription(clientId, data);
            break;
          
          default:
            console.log(`Unknown message type: ${data.type}`);
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });
    
    // Handle client disconnection
    ws.on('close', () => {
      console.log(`WebSocket client disconnected: ${clientId}`);
      cleanupClient(clientId);
    });
    
    // Handle errors
    ws.on('error', (error) => {
      console.error(`WebSocket error for client ${clientId}:`, error);
    });
  });
  
  // Setup interval to ping clients to keep connections alive and check liveness
  setInterval(() => {
    const timestamp = new Date().toISOString();
    
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        // Send heartbeat
        client.send(JSON.stringify({
          type: 'heartbeat',
          data: { timestamp }
        }));
        
        // Check if client is still alive 
        if (client.isAlive === false) {
          console.log("Terminating inactive WebSocket connection");
          return client.terminate();
        }
        
        // Mark as inactive, ping will set to true if client responds
        client.isAlive = false;
        client.ping(() => {});
      }
    });
  }, 15000); // Ping clients every 15 seconds
}

// Map to store client subscriptions
const subscriptions = new Map<string, Set<string>>();

// Handle client subscription requests
function handleSubscription(clientId: string, data: any) {
  // Extract subscription data
  const { channel, brokerId } = data;
  
  // Initialize client subscriptions if needed
  if (!subscriptions.has(clientId)) {
    subscriptions.set(clientId, new Set());
  }
  
  // Add the subscription
  const clientSubscriptions = subscriptions.get(clientId);
  if (clientSubscriptions) {
    // Format: channel:brokerId or just channel for global subscriptions
    const subscriptionKey = brokerId ? `${channel}:${brokerId}` : channel;
    clientSubscriptions.add(subscriptionKey);
    
    console.log(`Client ${clientId} subscribed to ${subscriptionKey}`);
  }
  
  // Acknowledge subscription
  const client = clients.get(clientId);
  if (client && client.readyState === WebSocket.OPEN) {
    client.send(JSON.stringify({
      type: 'subscribed',
      data: { 
        channel: channel,
        brokerId: brokerId,
        success: true 
      }
    }));
  }
}

// Broadcast message to all connected clients
export function broadcastMessage(message: any, options: { channel?: string, brokerId?: number } = {}) {
  const messageStr = JSON.stringify(message);
  const { channel, brokerId } = options;
  
  // If no channel specified, broadcast to all clients
  if (!channel) {
    clients.forEach((client, clientId) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(messageStr);
      }
    });
    return;
  }
  
  // Otherwise, send only to clients who have subscribed to this channel/brokerId
  const channelKey = channel;
  const specificKey = brokerId ? `${channel}:${brokerId}` : null;
  
  clients.forEach((client, clientId) => {
    if (client.readyState !== WebSocket.OPEN) return;
    
    const clientSubs = subscriptions.get(clientId);
    if (!clientSubs) return;
    
    // Send if client is subscribed to the specific channel:brokerId
    // or to the general channel
    if (clientSubs.has(channelKey) || 
        (specificKey && clientSubs.has(specificKey))) {
      client.send(messageStr);
    }
  });
}

// Send message to specific client
export function sendMessageToClient(clientId: string, message: any) {
  const client = clients.get(clientId);
  if (client && client.readyState === WebSocket.OPEN) {
    client.send(JSON.stringify(message));
    return true;
  }
  return false;
}

// Broadcast system log
export async function broadcastSystemLog(logData: any) {
  try {
    // Create system log in database
    const log = await storage.createSystemLog(logData);
    
    // Broadcast to all clients
    broadcastMessage({
      type: 'log',
      data: log
    });
    
    return log;
  } catch (error) {
    console.error('Error broadcasting system log:', error);
    return null;
  }
}

// Broadcast notification
export async function broadcastNotification(notificationData: any) {
  try {
    // Create notification in database
    const notification = await storage.createNotification(notificationData);
    
    // Broadcast to all clients
    broadcastMessage({
      type: 'notification',
      data: notification
    });
    
    return notification;
  } catch (error) {
    console.error('Error broadcasting notification:', error);
    return null;
  }
}

// Broadcast order update
export async function broadcastOrderUpdate(order: any, status: string = 'created') {
  try {
    // Broadcast to all clients
    broadcastMessage({
      type: 'order_update',
      data: {
        order,
        status
      }
    });
    
    // Also broadcast to clients subscribed to this specific broker
    if (order.brokerId) {
      broadcastMessage({
        type: 'order_update',
        data: {
          order,
          status
        }
      }, { 
        channel: 'orders', 
        brokerId: order.brokerId 
      });
    }
    
    return true;
  } catch (error) {
    console.error('Error broadcasting order update:', error);
    return false;
  }
}

// Broadcast position update
export async function broadcastPositionUpdate(position: any, action: string = 'updated') {
  try {
    // Broadcast to all clients
    broadcastMessage({
      type: 'position_update',
      data: {
        position,
        action
      }
    });
    
    // Also broadcast to clients subscribed to this specific broker
    if (position.brokerId) {
      broadcastMessage({
        type: 'position_update',
        data: {
          position,
          action
        }
      }, {
        channel: 'positions',
        brokerId: position.brokerId
      });
    }
    
    return true;
  } catch (error) {
    console.error('Error broadcasting position update:', error);
    return false;
  }
}

// Broadcast copy trading log
export async function broadcastCopyTradingLog(logData: any) {
  try {
    // Broadcast to all clients
    broadcastMessage({
      type: 'copy_trading_log',
      data: logData
    }, {
      channel: 'copy_trading' // Use channel for subscription filtering
    });
    
    return true;
  } catch (error) {
    console.error('Error broadcasting copy trading log:', error);
    return false;
  }
}