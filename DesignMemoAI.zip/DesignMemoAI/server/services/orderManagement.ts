import { storage } from '../storage';
import { Order, InsertOrder } from '@shared/schema';
import * as schwab from './schwab';
import * as tastytrade from './tastytrade';

/**
 * Creates and places a new order
 * @param orderData Order data to be placed
 * @returns Created order with API response
 */
export async function createOrder(orderData: InsertOrder): Promise<Order> {
  try {
    // Log order creation attempt
    console.log('Creating order:', JSON.stringify(orderData));
    await storage.createSystemLog({
      type: 'info',
      component: 'orderManagement',
      message: `Creating ${orderData.type} order for ${orderData.quantity} ${orderData.symbol} with broker ID ${orderData.brokerId}`
    });

    // Get broker details
    const broker = await storage.getBroker(orderData.brokerId);
    if (!broker) {
      throw new Error(`Broker with ID ${orderData.brokerId} not found`);
    }

    // Create order in local storage first
    const createdOrder = await storage.createOrder(orderData);

    // Place order with broker API based on broker type
    let brokerOrderResult: any = null;

    if (broker.type === 'schwab') {
      // Extract connection data from broker
      const connectionData = broker.connectionData as any;
      const accessToken = connectionData?.accessToken;
      
      if (!accessToken) {
        throw new Error('Schwab access token not found. Please reconnect your broker account.');
      }

      // Create Schwab order format
      const schwabOrder: schwab.SchwabOrder = {
        accountId: broker.accountId,
        symbol: orderData.symbol,
        quantity: orderData.quantity,
        price: orderData.limitPrice || undefined,
        stopPrice: orderData.stopPrice || undefined,
        orderType: mapToSchwabOrderType(orderData.type),
        duration: mapToSchwabOrderDuration(orderData.timeInForce),
        session: orderData.extendedHours ? 'SEAMLESS' : 'NORMAL',
        orderStrategy: 'SINGLE', // Default to single, would be updated for multi-leg
        assetType: orderData.instrumentType === 'option' ? 'OPTION' : 'EQUITY',
        instruction: mapToSchwabOrderInstruction(orderData.side, orderData.instrumentType)
      };

      // For options, add additional options data
      if (orderData.instrumentType === 'option' && orderData.optionData) {
        const optionData = orderData.optionData as any;
        // Add option legs if needed for multi-leg options
        if (optionData.legs && optionData.legs.length > 0) {
          schwabOrder.orderStrategy = 'OCO'; // Order cancels other
          schwabOrder.legs = optionData.legs.map((leg: any) => ({
            symbol: leg.symbol,
            instruction: mapToSchwabOrderInstruction(leg.side, 'option'),
            quantity: leg.quantity,
            putCall: leg.putCall,
            strike: leg.strike,
            expirationDate: leg.expirationDate
          }));
        }
      }

      // Place order with Schwab API
      brokerOrderResult = await schwab.placeSchwabOrder(accessToken, schwabOrder);
      
      // Update order with broker response data
      const updatedOrder = await storage.updateOrder(createdOrder.id, {
        status: 'open',
        statusMessage: 'Order placed with broker',
        externalOrderId: brokerOrderResult.orderId,
        externalOrderData: brokerOrderResult
      });

      // Log successful order placement
      await storage.createSystemLog({
        type: 'success',
        component: 'orderManagement',
        message: `Successfully placed ${orderData.type} order for ${orderData.quantity} ${orderData.symbol} with Schwab`
      });

      // Create notification
      await storage.createNotification({
        title: 'Order Placed',
        message: `${orderData.quantity} ${orderData.symbol} ${orderData.side} order placed successfully`,
        type: 'success'
      });

      return updatedOrder || createdOrder;
    } 
    else if (broker.type === 'tastytrade') {
      // Extract connection data
      const connectionData = broker.connectionData as any;
      const sessionToken = connectionData?.sessionToken;

      if (!sessionToken) {
        throw new Error('Tastytrade session token not found. Please reconnect your broker account.');
      }

      // Implementation for Tastytrade would go here
      // For now we'll throw an error
      throw new Error('Tastytrade order placement not yet implemented');
    } 
    else {
      throw new Error(`Unsupported broker type: ${broker.type}`);
    }
  } catch (error: any) {
    // Log error
    console.error('Order creation error:', error);
    await storage.createSystemLog({
      type: 'error',
      component: 'orderManagement',
      message: `Order creation error: ${error.message}`
    });

    // Create notification
    await storage.createNotification({
      title: 'Order Error',
      message: `Failed to place order: ${error.message}`,
      type: 'error'
    });

    throw error;
  }
}

/**
 * Cancels an existing order
 * @param orderId Order ID to cancel
 * @returns True if cancelled successfully
 */
export async function cancelOrder(orderId: number): Promise<boolean> {
  try {
    // Get order details
    const order = await storage.getOrder(orderId);
    if (!order) {
      throw new Error(`Order with ID ${orderId} not found`);
    }

    // Check if order can be cancelled
    if (['filled', 'cancelled', 'rejected', 'expired'].includes(order.status)) {
      throw new Error(`Cannot cancel order with status: ${order.status}`);
    }

    // Get broker details
    const broker = await storage.getBroker(order.brokerId);
    if (!broker) {
      throw new Error(`Broker with ID ${order.brokerId} not found`);
    }

    // Cancel order with broker API
    if (broker.type === 'schwab') {
      // Extract connection data
      const connectionData = broker.connectionData as any;
      const accessToken = connectionData?.accessToken;
      
      if (!accessToken) {
        throw new Error('Schwab access token not found. Please reconnect your broker account.');
      }

      // We need the external order ID to cancel with Schwab
      if (!order.externalOrderId) {
        throw new Error('External order ID not found. Cannot cancel order with broker.');
      }

      // Cancel order with Schwab API
      await schwab.cancelSchwabOrder(accessToken, broker.accountId, order.externalOrderId);

      // Update order status
      await storage.updateOrder(orderId, {
        status: 'cancelled',
        statusMessage: 'Order cancelled by user'
      });

      // Log successful cancellation
      await storage.createSystemLog({
        type: 'info',
        component: 'orderManagement',
        message: `Cancelled order ${orderId} (${order.symbol} ${order.side})`
      });

      // Create notification
      await storage.createNotification({
        title: 'Order Cancelled',
        message: `${order.symbol} ${order.side} order cancelled successfully`,
        type: 'info'
      });

      return true;
    } 
    else if (broker.type === 'tastytrade') {
      // Implementation for Tastytrade would go here
      throw new Error('Tastytrade order cancellation not yet implemented');
    } 
    else {
      throw new Error(`Unsupported broker type: ${broker.type}`);
    }
  } catch (error: any) {
    // Log error
    console.error('Order cancellation error:', error);
    await storage.createSystemLog({
      type: 'error',
      component: 'orderManagement',
      message: `Order cancellation error: ${error.message}`
    });

    // Create notification
    await storage.createNotification({
      title: 'Cancellation Error',
      message: `Failed to cancel order: ${error.message}`,
      type: 'error'
    });

    throw error;
  }
}

/**
 * Modifies an existing order
 * @param orderId Order ID to modify
 * @param updatedData Updated order data
 * @returns Updated order
 */
export async function modifyOrder(orderId: number, updatedData: Partial<Order>): Promise<Order> {
  try {
    // Get order details
    const order = await storage.getOrder(orderId);
    if (!order) {
      throw new Error(`Order with ID ${orderId} not found`);
    }

    // Check if order can be modified
    if (['filled', 'cancelled', 'rejected', 'expired'].includes(order.status)) {
      throw new Error(`Cannot modify order with status: ${order.status}`);
    }

    // Get broker details
    const broker = await storage.getBroker(order.brokerId);
    if (!broker) {
      throw new Error(`Broker with ID ${order.brokerId} not found`);
    }

    // Modify order with broker API
    if (broker.type === 'schwab') {
      // Extract connection data
      const connectionData = broker.connectionData as any;
      const accessToken = connectionData?.accessToken;
      
      if (!accessToken) {
        throw new Error('Schwab access token not found. Please reconnect your broker account.');
      }

      // We need the external order ID to modify with Schwab
      if (!order.externalOrderId) {
        throw new Error('External order ID not found. Cannot modify order with broker.');
      }

      // Create Schwab order format for modification
      const modifiedSchwabOrder: Partial<schwab.SchwabOrder> = {
        price: updatedData.limitPrice,
        stopPrice: updatedData.stopPrice,
        quantity: updatedData.quantity,
        orderType: updatedData.type ? mapToSchwabOrderType(updatedData.type) : undefined,
        duration: updatedData.timeInForce ? mapToSchwabOrderDuration(updatedData.timeInForce) : undefined
      };

      // Modify order with Schwab API
      const brokerResult = await schwab.modifySchwabOrder(
        accessToken, 
        broker.accountId, 
        order.externalOrderId, 
        modifiedSchwabOrder
      );

      // Update order in database
      const updatedOrder = await storage.updateOrder(orderId, {
        ...updatedData,
        externalOrderData: brokerResult
      });

      if (!updatedOrder) {
        throw new Error('Failed to update order in database');
      }

      // Log successful modification
      await storage.createSystemLog({
        type: 'info',
        component: 'orderManagement',
        message: `Modified order ${orderId} (${order.symbol} ${order.side})`
      });

      // Create notification
      await storage.createNotification({
        title: 'Order Modified',
        message: `${order.symbol} ${order.side} order modified successfully`,
        type: 'info'
      });

      return updatedOrder;
    } 
    else if (broker.type === 'tastytrade') {
      // Implementation for Tastytrade would go here
      throw new Error('Tastytrade order modification not yet implemented');
    } 
    else {
      throw new Error(`Unsupported broker type: ${broker.type}`);
    }
  } catch (error: any) {
    // Log error
    console.error('Order modification error:', error);
    await storage.createSystemLog({
      type: 'error',
      component: 'orderManagement',
      message: `Order modification error: ${error.message}`
    });

    // Create notification
    await storage.createNotification({
      title: 'Modification Error',
      message: `Failed to modify order: ${error.message}`,
      type: 'error'
    });

    throw error;
  }
}

/**
 * Gets account details for specified broker
 * @param brokerId Broker ID to get account details for
 * @returns Account details including positions, balances, etc.
 */
export async function getAccountDetails(brokerId: number) {
  try {
    // Get broker details
    const broker = await storage.getBroker(brokerId);
    if (!broker) {
      throw new Error(`Broker with ID ${brokerId} not found`);
    }

    if (broker.type === 'schwab') {
      // Extract connection data
      const connectionData = broker.connectionData as any;
      const accessToken = connectionData?.accessToken;
      
      if (!accessToken) {
        throw new Error('Schwab access token not found. Please reconnect your broker account.');
      }

      // Get account balances
      const balances = await schwab.fetchSchwabAccountBalances(accessToken, broker.accountId);
      
      // Get positions
      const positions = await schwab.fetchSchwabPositions(accessToken, broker.accountId);

      // Update broker with latest balance data
      await storage.updateBroker(brokerId, {
        balance: balances.equityValue,
        buyingPower: balances.buyingPower,
        updatedAt: new Date()
      });

      return {
        accountId: broker.accountId,
        accountType: broker.accountType,
        balances,
        positions,
        brokerName: broker.name,
        brokerType: broker.type
      };
    } 
    else if (broker.type === 'tastytrade') {
      // Implementation for Tastytrade would go here
      throw new Error('Tastytrade account details not yet implemented');
    } 
    else {
      throw new Error(`Unsupported broker type: ${broker.type}`);
    }
  } catch (error: any) {
    // Log error
    console.error('Account details error:', error);
    await storage.createSystemLog({
      type: 'error',
      component: 'orderManagement',
      message: `Account details error: ${error.message}`
    });

    throw error;
  }
}

/**
 * Gets multiple accounts details at once
 * @returns Array of account details
 */
export async function getAllAccountsDetails() {
  try {
    // Get all brokers
    const brokers = await storage.getBrokers();
    
    // Get account details for each broker
    const accountsPromises = brokers.map(broker => 
      getAccountDetails(broker.id).catch(error => {
        console.error(`Error getting account details for broker ${broker.id}:`, error);
        return {
          brokerId: broker.id,
          accountId: broker.accountId,
          brokerName: broker.name,
          brokerType: broker.type,
          error: error.message
        };
      })
    );
    
    const accounts = await Promise.all(accountsPromises);
    
    return accounts;
  } catch (error: any) {
    // Log error
    console.error('Get all accounts details error:', error);
    await storage.createSystemLog({
      type: 'error',
      component: 'orderManagement',
      message: `Get all accounts details error: ${error.message}`
    });

    throw error;
  }
}

/**
 * Gets quotes for specified symbols
 * @param brokerId Broker ID to use for market data
 * @param symbols Array of symbols to get quotes for
 * @returns Quote data for the symbols
 */
export async function getQuotes(brokerId: number, symbols: string[]) {
  try {
    // Get broker details
    const broker = await storage.getBroker(brokerId);
    if (!broker) {
      throw new Error(`Broker with ID ${brokerId} not found`);
    }

    if (broker.type === 'schwab') {
      // Extract connection data
      const connectionData = broker.connectionData as any;
      const accessToken = connectionData?.accessToken;
      
      if (!accessToken) {
        throw new Error('Schwab access token not found. Please reconnect your broker account.');
      }

      // Get quotes from Schwab
      const quotes = await schwab.fetchSchwabQuotes(accessToken, symbols);
      
      return quotes;
    } 
    else if (broker.type === 'tastytrade') {
      // Implementation for Tastytrade would go here
      throw new Error('Tastytrade quotes not yet implemented');
    } 
    else {
      throw new Error(`Unsupported broker type: ${broker.type}`);
    }
  } catch (error: any) {
    // Log error
    console.error('Get quotes error:', error);
    await storage.createSystemLog({
      type: 'error',
      component: 'orderManagement',
      message: `Get quotes error: ${error.message}`
    });

    throw error;
  }
}

/**
 * Gets option chain data for a symbol
 * @param brokerId Broker ID to use for market data
 * @param symbol Symbol to get option chain for
 * @returns Option chain data
 */
export async function getOptionChain(brokerId: number, symbol: string) {
  try {
    // Get broker details
    const broker = await storage.getBroker(brokerId);
    if (!broker) {
      throw new Error(`Broker with ID ${brokerId} not found`);
    }

    if (broker.type === 'schwab') {
      // Extract connection data
      const connectionData = broker.connectionData as any;
      const accessToken = connectionData?.accessToken;
      
      if (!accessToken) {
        throw new Error('Schwab access token not found. Please reconnect your broker account.');
      }

      // Get option chain from Schwab
      const optionChain = await schwab.fetchSchwabOptionChain(accessToken, symbol);
      
      return optionChain;
    } 
    else if (broker.type === 'tastytrade') {
      // Implementation for Tastytrade would go here
      throw new Error('Tastytrade option chain not yet implemented');
    } 
    else {
      throw new Error(`Unsupported broker type: ${broker.type}`);
    }
  } catch (error: any) {
    // Log error
    console.error('Get option chain error:', error);
    await storage.createSystemLog({
      type: 'error',
      component: 'orderManagement',
      message: `Get option chain error: ${error.message}`
    });

    throw error;
  }
}

/**
 * Searches for instruments (stocks, ETFs, etc)
 * @param brokerId Broker ID to use for searching
 * @param query Search query
 * @returns Search results
 */
export async function searchInstruments(brokerId: number, query: string) {
  try {
    // Get broker details
    const broker = await storage.getBroker(brokerId);
    if (!broker) {
      throw new Error(`Broker with ID ${brokerId} not found`);
    }

    if (broker.type === 'schwab') {
      // Extract connection data
      const connectionData = broker.connectionData as any;
      const accessToken = connectionData?.accessToken;
      
      if (!accessToken) {
        throw new Error('Schwab access token not found. Please reconnect your broker account.');
      }

      // Search instruments with Schwab
      const instruments = await schwab.searchSchwabInstruments(accessToken, query);
      
      return instruments;
    } 
    else if (broker.type === 'tastytrade') {
      // Implementation for Tastytrade would go here
      throw new Error('Tastytrade instrument search not yet implemented');
    } 
    else {
      throw new Error(`Unsupported broker type: ${broker.type}`);
    }
  } catch (error: any) {
    // Log error
    console.error('Search instruments error:', error);
    await storage.createSystemLog({
      type: 'error',
      component: 'orderManagement',
      message: `Search instruments error: ${error.message}`
    });

    throw error;
  }
}

// Utility function to map order types to Schwab format
function mapToSchwabOrderType(type: string): schwab.OrderType {
  switch (type.toLowerCase()) {
    case 'market':
      return 'MARKET';
    case 'limit':
      return 'LIMIT';
    case 'stop':
      return 'STOP';
    case 'stop_limit':
    case 'stop limit':
      return 'STOP_LIMIT';
    case 'trailing_stop':
    case 'trailing stop':
      return 'TRAILING_STOP';
    case 'trailing_stop_limit':
    case 'trailing stop limit':
      return 'TRAILING_STOP_LIMIT';
    default:
      return 'MARKET'; // Default to market order
  }
}

// Utility function to map order durations to Schwab format
function mapToSchwabOrderDuration(timeInForce: string): schwab.OrderDuration {
  switch (timeInForce.toLowerCase()) {
    case 'day':
      return 'DAY';
    case 'gtc':
      return 'GTC';
    case 'gtc_ext':
    case 'gtc ext':
      return 'GTC_EXT';
    case 'ioc':
    case 'immediate_or_cancel':
      return 'IMMEDIATE_OR_CANCEL';
    case 'fok':
    case 'fill_or_kill':
      return 'FILL_OR_KILL';
    default:
      return 'DAY'; // Default to day order
  }
}

// Utility function to map order side to Schwab instruction
function mapToSchwabOrderInstruction(side: string, instrumentType: string): schwab.SchwabOrder['instruction'] {
  if (instrumentType === 'option') {
    switch (side.toLowerCase()) {
      case 'buy':
      case 'buy_to_open':
        return 'BUY_TO_OPEN';
      case 'sell':
      case 'sell_to_close':
        return 'SELL_TO_CLOSE';
      case 'sell_to_open':
        return 'SELL_TO_OPEN';
      case 'buy_to_close':
        return 'BUY_TO_CLOSE';
      default:
        return 'BUY_TO_OPEN'; // Default to buy to open for options
    }
  } else {
    // For stocks, ETFs, etc.
    switch (side.toLowerCase()) {
      case 'buy':
        return 'BUY';
      case 'sell':
        return 'SELL';
      case 'sell_short':
      case 'short':
        return 'SELL_SHORT';
      case 'buy_to_cover':
      case 'cover':
        return 'BUY_TO_COVER';
      default:
        return 'BUY'; // Default to buy
    }
  }
}