import { Express, Request, Response } from "express";
import { storage } from "../storage";
import { authenticate } from "./auth";
import { z } from "zod";
import { insertOrderSchema, insertPositionSchema } from "@shared/schema";

// Setup trading routes
export function setupTradingRoutes(app: Express) {
  // Get all orders
  app.get('/api/trading/orders', authenticate, async (req: Request, res: Response) => {
    try {
      const orders = await storage.getOrders();
      res.status(200).json(orders);
    } catch (error: any) {
      console.error('Get orders error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Place new order
  app.post('/api/trading/orders', authenticate, async (req: Request, res: Response) => {
    try {
      // Validate request body
      const validationResult = insertOrderSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          message: 'Validation error',
          errors: validationResult.error.errors,
        });
      }
      
      const orderData = validationResult.data;
      
      // Verify broker exists and is connected
      const broker = await storage.getBroker(Number(orderData.brokerId));
      if (!broker) {
        return res.status(404).json({ message: 'Broker not found' });
      }
      
      if (!broker.connected) {
        return res.status(400).json({ message: 'Broker is not connected' });
      }
      
      // Create order
      const order = await storage.createOrder(orderData);
      
      // In a real implementation, we would submit the order to the broker API
      // and update the order status based on the response
      
      // For this implementation, we'll simulate a successful order submission
      // and update the status after a short delay
      
      // Simulate order processing
      setTimeout(async () => {
        // Update order status to simulate processing
        await storage.updateOrder(order.id, {
          status: 'filled',
          filledQuantity: order.quantity,
          filledPrice: order.price || Math.floor(Math.random() * 1000), // Random price if market order
          brokerOrderId: `broker-${Date.now().toString().slice(-6)}`,
          updatedAt: new Date()
        });
        
        // Create system log
        await storage.createSystemLog({
          type: 'success',
          component: 'trading',
          message: `Order for ${order.quantity} ${order.symbol} ${order.action} filled successfully`
        });
        
        // Create notification
        await storage.createNotification({
          title: 'Order Filled',
          message: `Your ${order.action} order for ${order.quantity} ${order.symbol} has been filled`,
          type: 'success'
        });
        
        // If it's a buy order, create a new position or update existing one
        if (['buy', 'buy_to_open'].includes(order.action.toLowerCase())) {
          const existingPosition = (await storage.getPositions()).find(p => 
            p.brokerId === order.brokerId && 
            p.symbol === order.symbol && 
            p.type === order.instrumentType
          );
          
          if (existingPosition) {
            // Update existing position
            const newQuantity = existingPosition.quantity + order.quantity;
            const newAverageCost = Math.floor(
              ((existingPosition.averageCost * existingPosition.quantity) + 
               ((order.price || 0) * order.quantity)) / newQuantity
            );
            
            await storage.updatePosition(existingPosition.id, {
              quantity: newQuantity,
              averageCost: newAverageCost,
              currentPrice: order.price || existingPosition.currentPrice,
              marketValue: newQuantity * (order.price || existingPosition.currentPrice),
              updatedAt: new Date()
            });
          } else {
            // Create new position
            await storage.createPosition({
              brokerId: order.brokerId,
              symbol: order.symbol,
              type: order.instrumentType as 'stock' | 'option',
              quantity: order.quantity,
              averageCost: order.price || 0,
              currentPrice: order.price || 0,
              marketValue: order.quantity * (order.price || 0),
              unrealizedPnl: 0,
              unrealizedPnlPercent: 0,
              openDate: new Date()
            });
          }
        } 
        // If it's a sell order, reduce or close position
        else if (['sell', 'sell_to_close'].includes(order.action.toLowerCase())) {
          const existingPosition = (await storage.getPositions()).find(p => 
            p.brokerId === order.brokerId && 
            p.symbol === order.symbol && 
            p.type === order.instrumentType
          );
          
          if (existingPosition) {
            if (existingPosition.quantity <= order.quantity) {
              // Close position
              await storage.deletePosition(existingPosition.id);
            } else {
              // Reduce position
              const newQuantity = existingPosition.quantity - order.quantity;
              await storage.updatePosition(existingPosition.id, {
                quantity: newQuantity,
                marketValue: newQuantity * (order.price || existingPosition.currentPrice),
                updatedAt: new Date()
              });
            }
          }
        }
      }, 2000);
      
      res.status(201).json(order);
    } catch (error: any) {
      console.error('Place order error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Get order by ID
  app.get('/api/trading/orders/:id', authenticate, async (req: Request, res: Response) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: 'Invalid order ID' });
      }
      
      const order = await storage.getOrder(orderId);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      
      res.status(200).json(order);
    } catch (error: any) {
      console.error('Get order error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Update order (e.g., cancel)
  app.put('/api/trading/orders/:id', authenticate, async (req: Request, res: Response) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: 'Invalid order ID' });
      }
      
      const order = await storage.getOrder(orderId);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      
      // Only allow cancellation of open orders
      if (order.status !== 'open' && req.body.status === 'canceled') {
        return res.status(400).json({ message: `Cannot cancel order with status '${order.status}'` });
      }
      
      // Update order
      const updatedOrder = await storage.updateOrder(orderId, {
        ...req.body,
        updatedAt: new Date()
      });
      
      if (!updatedOrder) {
        return res.status(500).json({ message: 'Failed to update order' });
      }
      
      // Create system log
      await storage.createSystemLog({
        type: 'info',
        component: 'trading',
        message: `Order ${orderId} updated to status '${updatedOrder.status}'`
      });
      
      res.status(200).json(updatedOrder);
    } catch (error: any) {
      console.error('Update order error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Get all positions
  app.get('/api/trading/positions', authenticate, async (req: Request, res: Response) => {
    try {
      const positions = await storage.getPositions();
      res.status(200).json(positions);
    } catch (error: any) {
      console.error('Get positions error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Get position by ID
  app.get('/api/trading/positions/:id', authenticate, async (req: Request, res: Response) => {
    try {
      const positionId = parseInt(req.params.id);
      if (isNaN(positionId)) {
        return res.status(400).json({ message: 'Invalid position ID' });
      }
      
      const position = await storage.getPosition(positionId);
      if (!position) {
        return res.status(404).json({ message: 'Position not found' });
      }
      
      res.status(200).json(position);
    } catch (error: any) {
      console.error('Get position error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Update position (e.g., adjust price)
  app.put('/api/trading/positions/:id', authenticate, async (req: Request, res: Response) => {
    try {
      const positionId = parseInt(req.params.id);
      if (isNaN(positionId)) {
        return res.status(400).json({ message: 'Invalid position ID' });
      }
      
      const position = await storage.getPosition(positionId);
      if (!position) {
        return res.status(404).json({ message: 'Position not found' });
      }
      
      // Update position
      const updatedPosition = await storage.updatePosition(positionId, {
        ...req.body,
        updatedAt: new Date()
      });
      
      if (!updatedPosition) {
        return res.status(500).json({ message: 'Failed to update position' });
      }
      
      res.status(200).json(updatedPosition);
    } catch (error: any) {
      console.error('Update position error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
}