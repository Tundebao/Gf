import { Express, Request, Response } from 'express';
import { z } from 'zod';
import { storage } from '../storage';
import { authenticate } from './auth';
import { initializeCopyTrading, updateCopyTradingSettings } from './copyTrading';

// Copy trading settings validation schema
const copyTradingSettingsSchema = z.object({
  enabled: z.boolean(),
  copyMode: z.enum(['all', 'whitelist', 'blacklist']),
  symbolWhitelist: z.array(z.string()).optional(),
  symbolBlacklist: z.array(z.string()).optional(),
  positionSizeType: z.enum(['fixed', 'percentage', 'proportional']),
  positionSizeValue: z.number().nonnegative(),
  maxPositionSize: z.number().nonnegative(),
  delaySeconds: z.number().nonnegative(),
  riskCheckEnabled: z.boolean(),
  notificationsEnabled: z.boolean(),
  forbidFollowerManualOrders: z.boolean().optional()
});

/**
 * Setup copy trading API routes
 * @param app Express application
 */
export async function setupCopyTradingRoutes(app: Express) {
  // Initialize copy trading system
  await initializeCopyTrading();
  
  // Get copy trading settings
  app.get('/api/copy-trading/settings', authenticate, async (req: Request, res: Response) => {
    try {
      const settings = await storage.getCopyTradingSettings();
      res.status(200).json(settings || {});
    } catch (error: any) {
      console.error('Get copy trading settings error:', error);
      res.status(500).json({ 
        message: 'Failed to get copy trading settings', 
        error: error.message 
      });
    }
  });

  // Update copy trading settings
  app.put('/api/copy-trading/settings', authenticate, async (req: Request, res: Response) => {
    try {
      // Validate request body
      const validationResult = copyTradingSettingsSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          message: 'Validation error',
          errors: validationResult.error.errors
        });
      }

      const settingsData = validationResult.data;

      // Update settings
      const updatedSettings = await updateCopyTradingSettings(settingsData);

      res.status(200).json({
        message: 'Copy trading settings updated successfully',
        settings: updatedSettings
      });
    } catch (error: any) {
      console.error('Update copy trading settings error:', error);
      res.status(500).json({ 
        message: 'Failed to update copy trading settings', 
        error: error.message 
      });
    }
  });

  // Get copy trading logs
  app.get('/api/copy-trading/logs', authenticate, async (req: Request, res: Response) => {
    try {
      const logs = await storage.getCopyTradingLogs();
      res.status(200).json(logs);
    } catch (error: any) {
      console.error('Get copy trading logs error:', error);
      res.status(500).json({ 
        message: 'Failed to get copy trading logs', 
        error: error.message 
      });
    }
  });

  // Get broker stats for copy trading dashboard
  app.get('/api/copy-trading/stats', authenticate, async (req: Request, res: Response) => {
    try {
      // Get all brokers
      const brokers = await storage.getBrokers();
      
      // Check if any brokers are connected before proceeding
      const anyConnected = brokers.some(broker => broker.connected);
      
      if (!anyConnected) {
        // If no brokers are connected, return a specific response indicating this status
        return res.status(200).json({
          brokerConnected: false,
          message: "No brokers are currently connected. Please connect to a broker to view copy trading statistics."
        });
      }
      
      // Count leaders and followers
      const leaderCount = brokers.filter(b => b.role === 'leader').length;
      const followerCount = brokers.filter(b => b.role === 'follower').length;
      
      // Get connected counts
      const connectedLeaderCount = brokers.filter(b => b.role === 'leader' && b.connected).length;
      const connectedFollowerCount = brokers.filter(b => b.role === 'follower' && b.connected).length;
      
      // Get copy trading logs
      const logs = await storage.getCopyTradingLogs();
      
      // Filter logs to only include those from connected brokers
      const connectedBrokerIds = brokers.filter(b => b.connected).map(b => b.id);
      const relevantLogs = logs.filter(log => {
        // Check if leaderId exists and is in connected brokers
        const leaderConnected = log.leaderId !== null && connectedBrokerIds.includes(log.leaderId);
        
        // Check if followerOrderId exists (as a proxy for followerId)
        // If we have a valid follower order ID, we need to get the broker ID from that order
        let followerConnected = false;
        if (log.followerOrderId !== null) {
          // In a real implementation, we would fetch the order and check its broker ID
          // For now, we'll just include logs with follower order IDs as they're likely relevant
          followerConnected = true;
        }
        
        return leaderConnected || followerConnected;
      });
      
      // Calculate success and failure rates
      const totalCopies = relevantLogs.length;
      const successfulCopies = relevantLogs.filter(l => l.status === 'completed').length;
      const failedCopies = relevantLogs.filter(l => ['error', 'rejected'].includes(l.status)).length;
      
      // Get copy trading settings
      const settings = await storage.getCopyTradingSettings();
      
      res.status(200).json({
        brokerConnected: true,
        brokers: {
          total: brokers.length,
          leaders: {
            total: leaderCount,
            connected: connectedLeaderCount
          },
          followers: {
            total: followerCount,
            connected: connectedFollowerCount
          }
        },
        copies: {
          total: totalCopies,
          successful: successfulCopies,
          failed: failedCopies,
          successRate: totalCopies > 0 ? (successfulCopies / totalCopies) * 100 : 0
        },
        settings: {
          enabled: settings?.enabled || false,
          copyMode: settings?.copyMode || 'all'
        }
      });
    } catch (error: any) {
      console.error('Get copy trading stats error:', error);
      res.status(500).json({ 
        message: 'Failed to get copy trading statistics', 
        error: error.message 
      });
    }
  });

  // Manually trigger a copy trade (for testing)
  app.post('/api/copy-trading/test', authenticate, async (req: Request, res: Response) => {
    try {
      // Validate request
      const { leaderId, symbol, quantity, side, type } = req.body;
      
      if (!leaderId || !symbol || !quantity || !side || !type) {
        return res.status(400).json({
          message: 'Missing required fields',
          required: ['leaderId', 'symbol', 'quantity', 'side', 'type']
        });
      }
      
      // Get the leader broker
      const leaderBrokerId = parseInt(leaderId);
      const leaderBroker = await storage.getBroker(leaderBrokerId);
      if (!leaderBroker) {
        return res.status(404).json({ message: 'Leader broker not found' });
      }
      
      // Check if broker is connected
      if (!leaderBroker.connected) {
        return res.status(400).json({ 
          message: 'Leader broker is not connected',
          status: leaderBroker.status
        });
      }
      
      // Parse quantity
      const orderQuantity = parseInt(quantity);
      if (isNaN(orderQuantity) || orderQuantity <= 0) {
        return res.status(400).json({ message: 'Invalid quantity value' });
      }
      
      // Create a test order for the leader
      const orderData = {
        brokerId: leaderBroker.id,
        symbol,
        quantity: orderQuantity,
        side,
        orderType: type,
        action: side, // For consistency
        timeInForce: 'day',
        status: 'filled',
        instrumentType: 'equity',
        notes: 'Test order for copy trading'
      };
      
      // Create the order
      const leaderOrder = await storage.createOrder(orderData);
      
      // Log the test
      await storage.createSystemLog({
        type: 'info',
        component: 'copyTrading',
        message: `Manual test copy trade initiated for ${symbol} ${side}`
      });
      
      // Import here to avoid circular dependency
      const { handleLeaderOrder } = await import('./copyTrading');
      
      // Process the order for copying
      await handleLeaderOrder(leaderOrder);
      
      res.status(200).json({
        message: 'Test copy trade initiated successfully',
        leaderOrder
      });
    } catch (error: any) {
      console.error('Test copy trade error:', error);
      res.status(500).json({ 
        message: 'Failed to initiate test copy trade', 
        error: error.message 
      });
    }
  });
}