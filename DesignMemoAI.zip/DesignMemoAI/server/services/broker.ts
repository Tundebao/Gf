import { Express, Request, Response } from "express";
import { storage } from "../storage";
import { authenticate } from "./auth";
import { z } from "zod";
import { insertBrokerSchema } from "@shared/schema";
import { connectToTastytrade, fetchTastytradeAccounts } from "./tastytrade";
import { 
  initiateSchwabOAuth, 
  authenticateWithSchwab, 
  fetchSchwabAccounts, 
  fetchSchwabAccountBalances 
} from "./schwab";
import WebSocket from 'ws';

// Define the global type for Schwab OAuth state and WebSocket server
declare global {
  var schwabOAuthState: {
    state: string;
    role: "leader" | "follower";
    timestamp: number;
  } | undefined;
  
  var wss: WebSocket.Server | undefined;
}

// Form validation schemas
const connectTastytradeSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
  role: z.enum(["leader", "follower"]).default("follower")
});

const schwabConnectSchema = z.object({
  clientId: z.string().min(1, "Client ID is required"),
  clientSecret: z.string().min(1, "Client Secret is required"),
  redirectUri: z.string().url("Must be a valid URL"),
  role: z.enum(["leader", "follower"]).default("follower")
});

// Setup broker-related routes
export function setupBrokerRoutes(app: Express) {
  // Connect to Tastytrade API directly
  app.post('/api/brokers/tastytrade/connect', async (req: Request, res: Response) => {
    try {
      // Validate request
      const validationResult = connectTastytradeSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          message: 'Validation error',
          errors: validationResult.error.errors,
        });
      }
      
      const { username, password, role } = validationResult.data;
      
      // Log connection attempt
      await storage.createSystemLog({
        type: 'info',
        component: 'broker',
        message: `Attempting to connect to Tastytrade with username: ${username}`
      });
      
      // Connect to Tastytrade API
      const connectionResult = await connectToTastytrade(username, password);
      
      if (!connectionResult.accounts || connectionResult.accounts.length === 0) {
        throw new Error('No accounts found for this Tastytrade user');
      }
      
      // Get the first account for simplicity
      // In a real app, you might want to let the user choose which account to use
      const account = connectionResult.accounts[0];
      
      // Create broker record
      const broker = await storage.createBroker({
        name: username,
        type: "tastytrade",
        accountId: account.accountId,
        accountType: account.accountType || "unknown",
        role: role,
        connectionData: {
          sessionToken: connectionResult.sessionToken,
          userId: connectionResult.userId,
          accounts: connectionResult.accounts
        }
      });
      
      // Update connection status
      const updatedBroker = await storage.updateBroker(broker.id, {
        connected: true,
        connectedAt: new Date(),
        status: 'active',
        balance: 0, // This would be fetched in a separate call
        buyingPower: 0 // This would be fetched in a separate call
      });
      
      // Create notification
      await storage.createNotification({
        title: 'Tastytrade Connected',
        message: `Successfully connected to Tastytrade account ${account.accountId}`,
        type: 'success'
      });
      
      // Broadcast the connection status change to all WebSocket clients
      if (global.wss && updatedBroker) {
        const message = {
          type: 'broker_status_change',
          data: {
            brokerId: updatedBroker.id,
            connected: true,
            accountId: updatedBroker.accountId || ''
          }
        };
        global.wss.clients.forEach((client: WebSocket) => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(message));
          }
        });
      }
      
      res.status(200).json({
        message: 'Tastytrade connection successful',
        broker: updatedBroker
      });
      
    } catch (error: any) {
      console.error('Tastytrade connection error:', error);
      
      // Create system log for error
      await storage.createSystemLog({
        type: 'error',
        component: 'broker',
        message: `Tastytrade connection error: ${error.message}`
      });
      
      res.status(500).json({ 
        message: 'Failed to connect to Tastytrade', 
        error: error.message 
      });
    }
  });
  
  // Initiate Schwab OAuth flow
  app.post('/api/brokers/schwab/initiate', authenticate, async (req: Request, res: Response) => {
    try {
      const validationResult = schwabConnectSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          message: 'Validation error',
          errors: validationResult.error.errors,
        });
      }
      
      const { clientId, clientSecret, redirectUri, role } = validationResult.data;
      
      // Store OAuth parameters in environment variables
      process.env.SCHWAB_CLIENT_ID = clientId;
      process.env.SCHWAB_CLIENT_SECRET = clientSecret;
      process.env.SCHWAB_REDIRECT_URI = redirectUri;
      
      // Generate OAuth URL
      const { authUrl, state } = await initiateSchwabOAuth();
      
      // Store state with role for later use
      // In a real app, you'd store this in a database
      global.schwabOAuthState = {
        state,
        role,
        timestamp: Date.now()
      };
      
      // Create system log
      await storage.createSystemLog({
        type: 'info',
        component: 'broker',
        message: 'Schwab OAuth flow initiated'
      });
      
      res.status(200).json({
        authUrl,
        message: 'Schwab OAuth flow initiated'
      });
    } catch (error: any) {
      console.error('Schwab OAuth initiation error:', error);
      
      // Create system log for error
      await storage.createSystemLog({
        type: 'error',
        component: 'broker',
        message: `Schwab OAuth initiation error: ${error.message}`
      });
      
      res.status(500).json({ 
        message: 'Failed to initiate Schwab OAuth flow', 
        error: error.message 
      });
    }
  });
  
  // Schwab OAuth callback endpoint
  app.get('/auth/schwab/callback', async (req: Request, res: Response) => {
    try {
      const { code, state } = req.query;
      
      if (!code || !state) {
        throw new Error('Missing code or state parameter');
      }
      
      // Verify state matches the stored state
      if (!global.schwabOAuthState || global.schwabOAuthState.state !== state) {
        throw new Error('Invalid OAuth state parameter');
      }
      
      // Check if state is expired (30 minutes)
      if (Date.now() - global.schwabOAuthState.timestamp > 30 * 60 * 1000) {
        throw new Error('OAuth state expired, please try again');
      }
      
      // Exchange auth code for tokens
      const authResponse = await authenticateWithSchwab(code as string);
      
      // Fetch accounts
      const accounts = await fetchSchwabAccounts(authResponse.access_token);
      
      if (!accounts || accounts.length === 0) {
        throw new Error('No accounts found for this Schwab user');
      }
      
      // Get the first account for simplicity
      const account = accounts[0];
      
      // Create broker record
      const broker = await storage.createBroker({
        name: "Schwab Account",
        type: "schwab",
        accountId: account.accountId,
        accountType: account.accountType || "Cash Account",
        balance: account.balance || 0,
        buyingPower: account.buyingPower || 0,
        pdtStatus: account.pdtStatus || "N/A",
        role: global.schwabOAuthState.role,
        connectionData: {
          accessToken: authResponse.access_token,
          refreshToken: authResponse.refresh_token,
          expiresIn: authResponse.expires_in,
          accounts: accounts
        }
      });
      
      // Update connection status
      await storage.updateBroker(broker.id, {
        connected: true,
        connectedAt: new Date(),
        status: 'active'
      });
      
      // Create notification
      await storage.createNotification({
        title: 'Schwab Connected',
        message: `Successfully connected to Schwab account ${account.accountId}`,
        type: 'success'
      });
      
      // Broadcast the connection status change to all WebSocket clients
      if (global.wss && broker) {
        const message = {
          type: 'broker_status_change',
          data: {
            brokerId: broker.id,
            connected: true,
            accountId: account.accountId || ''
          }
        };
        global.wss.clients.forEach((client: WebSocket) => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(message));
          }
        });
      }
      
      // Redirect to the success page
      res.redirect('/accounts?success=true');
      
    } catch (error: any) {
      console.error('Schwab OAuth callback error:', error);
      
      // Create system log for error
      await storage.createSystemLog({
        type: 'error',
        component: 'broker',
        message: `Schwab OAuth callback error: ${error.message}`
      });
      
      // Redirect to error page
      res.redirect(`/accounts?error=${encodeURIComponent(error.message)}`);
    }
  });
  // Get all brokers
  app.get('/api/brokers', authenticate, async (req: Request, res: Response) => {
    try {
      const brokers = await storage.getBrokers();
      res.status(200).json(brokers);
    } catch (error: any) {
      console.error('Get brokers error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Get broker by ID
  app.get('/api/brokers/:id', authenticate, async (req: Request, res: Response) => {
    try {
      const brokerId = parseInt(req.params.id);
      if (isNaN(brokerId)) {
        return res.status(400).json({ message: 'Invalid broker ID' });
      }
      
      const broker = await storage.getBroker(brokerId);
      if (!broker) {
        return res.status(404).json({ message: 'Broker not found' });
      }
      
      res.status(200).json(broker);
    } catch (error: any) {
      console.error('Get broker error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Create new broker
  app.post('/api/brokers', authenticate, async (req: Request, res: Response) => {
    try {
      // Validate request body
      const validationResult = insertBrokerSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          message: 'Validation error',
          errors: validationResult.error.errors,
        });
      }
      
      const brokerData = validationResult.data;
      
      // Create broker
      const broker = await storage.createBroker(brokerData);
      
      // Create system log
      await storage.createSystemLog({
        type: 'info',
        component: 'broker',
        message: `New broker account created: ${broker.name}`
      });
      
      // Create notification
      await storage.createNotification({
        title: 'New Broker Added',
        message: `Broker account "${broker.name}" has been added to the system`,
        type: 'info'
      });
      
      res.status(201).json(broker);
    } catch (error: any) {
      console.error('Create broker error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Update broker
  app.put('/api/brokers/:id', authenticate, async (req: Request, res: Response) => {
    try {
      const brokerId = parseInt(req.params.id);
      if (isNaN(brokerId)) {
        return res.status(400).json({ message: 'Invalid broker ID' });
      }
      
      const broker = await storage.getBroker(brokerId);
      if (!broker) {
        return res.status(404).json({ message: 'Broker not found' });
      }
      
      // Update broker
      const updatedBroker = await storage.updateBroker(brokerId, req.body);
      if (!updatedBroker) {
        return res.status(500).json({ message: 'Failed to update broker' });
      }
      
      // Create system log
      await storage.createSystemLog({
        type: 'info',
        component: 'broker',
        message: `Broker account updated: ${updatedBroker.name}`
      });
      
      res.status(200).json(updatedBroker);
    } catch (error: any) {
      console.error('Update broker error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Delete broker
  app.delete('/api/brokers/:id', authenticate, async (req: Request, res: Response) => {
    try {
      const brokerId = parseInt(req.params.id);
      if (isNaN(brokerId)) {
        return res.status(400).json({ message: 'Invalid broker ID' });
      }
      
      const broker = await storage.getBroker(brokerId);
      if (!broker) {
        return res.status(404).json({ message: 'Broker not found' });
      }
      
      // Delete broker
      const success = await storage.deleteBroker(brokerId);
      if (!success) {
        return res.status(500).json({ message: 'Failed to delete broker' });
      }
      
      // Create system log
      await storage.createSystemLog({
        type: 'warning',
        component: 'broker',
        message: `Broker account deleted: ${broker.name}`
      });
      
      // Create notification
      await storage.createNotification({
        title: 'Broker Removed',
        message: `Broker account "${broker.name}" has been removed from the system`,
        type: 'warning'
      });
      
      res.status(200).json({ message: 'Broker deleted successfully' });
    } catch (error: any) {
      console.error('Delete broker error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Connect broker API
  app.post('/api/brokers/:id/connect', authenticate, async (req: Request, res: Response) => {
    try {
      const brokerId = parseInt(req.params.id);
      if (isNaN(brokerId)) {
        return res.status(400).json({ message: 'Invalid broker ID' });
      }
      
      const broker = await storage.getBroker(brokerId);
      if (!broker) {
        return res.status(404).json({ message: 'Broker not found' });
      }
      
      // Extract credentials from request if present
      const { username, password } = req.body;
      
      // Create a variable to store updates to the broker record
      let brokerUpdates: any = {
        connected: true,
        connectedAt: new Date(),
        status: 'active'
      };
      
      // Establish a real connection to the broker API based on broker type
      if (broker.type === 'tastytrade') {
        if (!username || !password) {
          return res.status(400).json({ 
            message: 'Tastytrade connection requires username and password', 
            required: ['username', 'password']
          });
        }
        
        try {
          // Connect to Tastytrade with real credentials
          const connectionResult = await connectToTastytrade(username, password);
          
          if (!connectionResult.accounts || connectionResult.accounts.length === 0) {
            throw new Error('No accounts found for this Tastytrade user');
          }
          
          // Use the first account for simplicity
          const account = connectionResult.accounts[0];
          
          // Add the connection data and account info to the updates
          brokerUpdates.connectionData = {
            sessionToken: connectionResult.sessionToken,
            userId: connectionResult.userId,
            accounts: connectionResult.accounts
          };
          
          // Update account details
          brokerUpdates.accountId = account.accountId;
          brokerUpdates.accountType = account.accountType || 'Margin Account';
          brokerUpdates.balance = account.balance || 0;
          brokerUpdates.buyingPower = account.buyingPower || 0;
          brokerUpdates.pdtStatus = account.pdtStatus || 'Unknown';
        } catch (error: any) {
          return res.status(400).json({ 
            message: 'Failed to connect to Tastytrade API', 
            error: error.message 
          });
        }
      } else if (broker.type === 'schwab') {
        // For Schwab, we would verify the OAuth token is valid
        // This would be a separate flow using the Schwab API
        // For now, we'll check if there's a valid token in the connection data
        
        if (!broker.connectionData || !broker.connectionData.accessToken) {
          return res.status(400).json({ 
            message: 'Schwab connection requires OAuth authentication first' 
          });
        }
        
        // In a real implementation, we would verify the token is valid
        // For now, we'll just update the connection status
      } else {
        return res.status(400).json({ 
          message: `Unsupported broker type: ${broker.type}`
        });
      }
      
      // Update broker connection status
      const updatedBroker = await storage.updateBroker(brokerId, brokerUpdates);
      
      if (!updatedBroker) {
        return res.status(500).json({ message: 'Failed to update broker connection status' });
      }
      
      // Create system log
      await storage.createSystemLog({
        type: 'success',
        component: 'broker',
        message: `Connected to broker API: ${updatedBroker.name} (${updatedBroker.accountId})`
      });
      
      // Create notification
      await storage.createNotification({
        title: 'Broker Connected',
        message: `Successfully connected to ${updatedBroker.name} API using account ${updatedBroker.accountId}`,
        type: 'success'
      });
      
      // Broadcast the connection status change to all WebSocket clients
      if (global.wss && updatedBroker) {
        const message = {
          type: 'broker_status_change',
          data: {
            brokerId: updatedBroker.id,
            connected: true,
            accountId: updatedBroker.accountId || ''
          }
        };
        global.wss.clients.forEach((client: WebSocket) => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(message));
          }
        });
      }
      
      res.status(200).json({
        message: 'Broker API connected successfully',
        broker: updatedBroker
      });
    } catch (error: any) {
      console.error('Connect broker error:', error);
      
      // Create system log for error
      await storage.createSystemLog({
        type: 'error',
        component: 'broker',
        message: `Error connecting to broker API: ${error.message}`
      });
      
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Disconnect broker API
  app.post('/api/brokers/:id/disconnect', authenticate, async (req: Request, res: Response) => {
    try {
      const brokerId = parseInt(req.params.id);
      if (isNaN(brokerId)) {
        return res.status(400).json({ message: 'Invalid broker ID' });
      }
      
      const broker = await storage.getBroker(brokerId);
      if (!broker) {
        return res.status(404).json({ message: 'Broker not found' });
      }
      
      // Update broker connection status
      const updatedBroker = await storage.updateBroker(brokerId, {
        connected: false,
        status: 'inactive'
      });
      
      if (!updatedBroker) {
        return res.status(500).json({ message: 'Failed to update broker connection status' });
      }
      
      // Create system log
      await storage.createSystemLog({
        type: 'info',
        component: 'broker',
        message: `Disconnected from broker API: ${updatedBroker.name}`
      });
      
      // Create notification
      await storage.createNotification({
        title: 'Broker Disconnected',
        message: `Disconnected from ${updatedBroker.name} API`,
        type: 'info'
      });
      
      // Broadcast the disconnection status to all WebSocket clients
      if (global.wss && updatedBroker) {
        const message = {
          type: 'broker_status_change',
          data: {
            brokerId: updatedBroker.id,
            connected: false,
            accountId: updatedBroker.accountId || ''
          }
        };
        global.wss.clients.forEach((client: WebSocket) => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(message));
          }
        });
      }
      
      res.status(200).json({
        message: 'Broker API disconnected successfully',
        broker: updatedBroker
      });
    } catch (error: any) {
      console.error('Disconnect broker error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Get broker account information
  app.get('/api/brokers/:id/account', authenticate, async (req: Request, res: Response) => {
    try {
      const brokerId = parseInt(req.params.id);
      if (isNaN(brokerId)) {
        return res.status(400).json({ message: 'Invalid broker ID' });
      }
      
      const broker = await storage.getBroker(brokerId);
      if (!broker) {
        return res.status(404).json({ message: 'Broker not found' });
      }
      
      if (!broker.connected) {
        return res.status(400).json({ message: 'Broker is not connected' });
      }
      
      // For Charles Schwab or Tastytrade API integration
      // We need to use the broker's connection data to make real API calls
      // This would typically involve calling the respective broker service
      // with their respective tokens/credentials
      
      if (broker.type === 'schwab') {
        // Use Schwab API integration to get real account data
        // This is where we'd make actual API calls using the stored tokens
        if (!broker.connectionData || !broker.connectionData.accessToken) {
          return res.status(401).json({ message: 'Missing access token for Schwab API' });
        }
        
        // In production, we'd call the Schwab API here
        // and return real account data based on the response
        
        // For now, return broker data from storage without random generation
        return res.status(200).json({
          accountId: broker.accountId,
          balance: broker.balance || 0,
          equity: broker.equity || 0,
          margin: broker.margin || 0,
          buyingPower: broker.buyingPower || 0,
          currency: 'USD',
          lastUpdated: broker.updatedAt || new Date()
        });
      } else if (broker.type === 'tastytrade') {
        // Use Tastytrade API integration to get real account data
        if (!broker.connectionData || !broker.connectionData.sessionToken) {
          return res.status(401).json({ message: 'Missing session token for Tastytrade API' });
        }
        
        // In production, we'd call the Tastytrade API here
        // and return real account data based on the response
        
        // For now, return broker data from storage without random generation
        return res.status(200).json({
          accountId: broker.accountId,
          balance: broker.balance || 0,
          equity: broker.equity || 0,
          margin: broker.margin || 0,
          buyingPower: broker.buyingPower || 0,
          currency: 'USD',
          lastUpdated: broker.updatedAt || new Date()
        });
      }
      
      // If we reach here, we have an unsupported broker type
      return res.status(400).json({ message: 'Unsupported broker type' });
    } catch (error: any) {
      console.error('Get broker account error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Refresh broker account information
  app.post('/api/brokers/:id/refresh', authenticate, async (req: Request, res: Response) => {
    try {
      const brokerId = parseInt(req.params.id);
      if (isNaN(brokerId)) {
        return res.status(400).json({ message: 'Invalid broker ID' });
      }
      
      const broker = await storage.getBroker(brokerId);
      if (!broker) {
        return res.status(404).json({ message: 'Broker not found' });
      }
      
      if (!broker.connected) {
        return res.status(400).json({ message: 'Broker is not connected' });
      }
      
      // In a real implementation, this would call the broker API to get the latest account data
      // For now, we'll just update random values for demonstration purposes
      let updatedAccount: any = {};
      
      if (broker.type === 'tastytrade') {
        if (!broker.connectionData || !broker.connectionData.sessionToken) {
          return res.status(401).json({ message: 'Missing session token for Tastytrade API' });
        }
        
        try {
          // Get the latest account data from Tastytrade API
          const sessionToken = broker.connectionData.sessionToken;
          const accounts = await fetchTastytradeAccounts(sessionToken);
          
          if (!accounts || accounts.length === 0) {
            throw new Error('No accounts found for this Tastytrade session');
          }
          
          // Find the matching account by account number
          const matchingAccount = accounts.find((acct: { account_number: string }) => 
            acct.account_number === broker.accountId
          );
          
          if (!matchingAccount) {
            throw new Error(`Account ${broker.accountId} not found in Tastytrade accounts`);
          }
          
          // Map account data to our model
          updatedAccount = {
            accountType: matchingAccount.account_type_name || broker.accountType,
            balance: matchingAccount.cash_balance || 0,
            buyingPower: matchingAccount.available_trading_buying_power || 0,
            pdtStatus: matchingAccount.day_trader_status || 'Unknown'
          };
        } catch (error: any) {
          console.error('Failed to refresh Tastytrade account:', error);
          return res.status(500).json({ 
            message: 'Failed to refresh Tastytrade account information', 
            error: error.message 
          });
        }
      } else if (broker.type === 'schwab') {
        if (!broker.connectionData || !broker.connectionData.accessToken) {
          return res.status(401).json({ message: 'Missing access token for Schwab API' });
        }
        
        try {
          // Get the latest account data from Schwab API
          const accessToken = broker.connectionData.accessToken;
          
          // Fetch account balances for the specific account
          const balances = await fetchSchwabAccountBalances(accessToken, broker.accountId);
          
          if (!balances) {
            throw new Error(`Failed to fetch balances for account ${broker.accountId}`);
          }
          
          // Fetch account details to check PDT status if needed
          const accounts = await fetchSchwabAccounts(accessToken);
          const matchingAccount = accounts.find((acct: { accountId: string }) => 
            acct.accountId === broker.accountId
          );
          
          if (!matchingAccount) {
            throw new Error(`Account ${broker.accountId} not found in Schwab accounts`);
          }
          
          // Map account data to our model
          updatedAccount = {
            accountType: matchingAccount.accountType || broker.accountType,
            balance: balances.cashBalance || 0,
            buyingPower: balances.buyingPower || 0,
            pdtStatus: matchingAccount.pdtStatus || (matchingAccount.isDayTrader ? "Pattern Day Trader" : "No PDT Restrictions")
          };
        } catch (error: any) {
          console.error('Failed to refresh Schwab account:', error);
          return res.status(500).json({ 
            message: 'Failed to refresh Schwab account information', 
            error: error.message 
          });
        }
      } else {
        return res.status(400).json({ message: 'Unsupported broker type' });
      }
      
      // Update the broker record with the new account information
      const updatedBroker = await storage.updateBroker(brokerId, updatedAccount);
      
      if (!updatedBroker) {
        return res.status(500).json({ message: 'Failed to update broker account information' });
      }
      
      // Create system log
      await storage.createSystemLog({
        type: 'info',
        component: 'broker',
        message: `Refreshed ${updatedBroker.name} account information (${updatedBroker.accountId})`
      });
      
      // Broadcast the connection status change to all WebSocket clients
      if (global.wss && updatedBroker) {
        const message = {
          type: 'broker_status_change',
          data: {
            brokerId: updatedBroker.id,
            connected: updatedBroker.connected,
            accountId: updatedBroker.accountId || ''
          }
        };
        global.wss.clients.forEach((client: WebSocket) => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(message));
          }
        });
      }
      
      res.status(200).json({
        message: 'Broker account information refreshed successfully',
        broker: updatedBroker
      });
    } catch (error: any) {
      console.error('Refresh broker error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
  
  // Get broker connection status
  app.get('/api/brokers/status', authenticate, async (req: Request, res: Response) => {
    try {
      const brokerId = req.query.id ? parseInt(req.query.id as string) : undefined;
      
      if (req.query.id && isNaN(brokerId as number)) {
        return res.status(400).json({ message: 'Invalid broker ID' });
      }
      
      // If specific broker ID is provided, check that broker's status
      if (brokerId) {
        const broker = await storage.getBroker(brokerId);
        if (!broker) {
          return res.status(404).json({ message: 'Broker not found' });
        }
        
        return res.status(200).json({
          id: broker.id,
          connected: broker.connected,
          status: broker.status,
          type: broker.type,
          name: broker.name,
          role: broker.role
        });
      }
      
      // Otherwise, return status of all brokers
      const brokers = await storage.getBrokers();
      const anyConnected = brokers.some(broker => broker.connected);
      const leaderConnected = brokers.some(broker => broker.connected && broker.role === 'leader');
      const followerConnected = brokers.some(broker => broker.connected && broker.role === 'follower');
      
      res.status(200).json({
        connected: anyConnected,
        totalBrokers: brokers.length,
        connectedBrokers: brokers.filter(broker => broker.connected).length,
        leaderConnected,
        followerConnected,
        brokers: brokers.map(broker => ({
          id: broker.id,
          connected: broker.connected,
          status: broker.status,
          type: broker.type,
          name: broker.name,
          role: broker.role
        }))
      });
    } catch (error: any) {
      console.error('Get broker status error:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });
}