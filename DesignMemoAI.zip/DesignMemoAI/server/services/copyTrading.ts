import { storage } from '../storage';
import { Order, InsertOrder, CopyTradingSetting } from '../../shared/schema';
import { 
  broadcastMessage,
  broadcastSystemLog, 
  broadcastNotification,
  broadcastCopyTradingLog,
  broadcastOrderUpdate,
  broadcastPositionUpdate
} from './websocket';

// Interface to pass only required fields when processing a new order
interface OrderData {
  symbol: string;
  side: 'buy' | 'sell';
  quantity: number;
  type: string;
  limitPrice?: number;
  stopPrice?: number;
  timeInForce: string;
  extendedHours?: boolean;
}

/**
 * Initializes the copy trading system
 * Sets up listeners for new orders from leader accounts
 */
export async function initializeCopyTrading() {
  try {
    console.log('Initializing copy trading system');
    
    // Ensure copy trading settings exist
    const settings = await storage.getCopyTradingSettings();
    
    if (!settings) {
      // Create default settings if none exist
      await storage.createOrUpdateCopyTradingSettings({
        enabled: false,
        isRunning: false,
        copyMode: 'all',
        symbolWhitelist: [],
        symbolBlacklist: [],
        positionSizeType: 'percentage',
        positionSizeValue: 100,
        maxPositionSize: 0,
        mode: 'exact',
        delay: 0,
        delaySeconds: 0,
        handlePartialFills: true,
        riskCheckEnabled: true,
        notificationsEnabled: true,
        forbidFollowerManualOrders: false,
        autoStart: false
      });
    }
    
    // Log initialization
    await storage.createSystemLog({
      type: 'info',
      component: 'copyTrading',
      message: 'Copy trading system initialized successfully'
    });
    
    console.log('Copy trading system initialized successfully');
    
    return { success: true };
  } catch (error: any) {
    console.error('Error initializing copy trading system:', error);
    
    // Log error
    await storage.createSystemLog({
      type: 'error',
      component: 'copyTrading',
      message: `Failed to initialize copy trading system: ${error.message}`
    });
    
    return { success: false, error: error.message };
  }
}

/**
 * Handle a new order from a leader account
 * @param order Order from leader account
 */
export async function handleLeaderOrder(order: Order) {
  try {
    // Get copy trading settings
    const settings = await storage.getCopyTradingSettings();
    
    // Check if copy trading is enabled
    if (!settings || !settings.enabled) {
      await storage.createCopyTradingLog({
        leaderId: order.brokerId,
        leaderOrderId: order.id,
        followerOrderId: null,
        symbol: order.symbol,
        quantity: order.quantity,
        side: order.action === 'buy' ? 'buy' : 'sell',
        status: 'skipped',
        success: false,
        message: 'Copy trading is disabled',
        details: 'Enable copy trading in settings to start copying trades'
      });
      
      return { 
        success: false, 
        message: 'Copy trading is disabled',
        leaderOrderId: order.id
      };
    }
    
    // Get leader broker
    const leaderBroker = await storage.getBroker(order.brokerId);
    if (!leaderBroker) {
      await storage.createCopyTradingLog({
        leaderId: order.brokerId,
        leaderOrderId: order.id,
        followerOrderId: null,
        symbol: order.symbol,
        quantity: order.quantity,
        side: order.action === 'buy' ? 'buy' : 'sell',
        status: 'error',
        success: false,
        message: 'Leader broker not found',
        details: `Broker ID ${order.brokerId} not found in database`
      });
      
      return {
        success: false,
        message: 'Leader broker not found',
        leaderOrderId: order.id
      };
    }
    
    // Check if the broker is a leader
    if (leaderBroker.role !== 'leader') {
      await storage.createCopyTradingLog({
        leaderId: order.brokerId,
        leaderOrderId: order.id,
        followerOrderId: null,
        symbol: order.symbol,
        quantity: order.quantity,
        side: order.action === 'buy' ? 'buy' : 'sell',
        status: 'error',
        success: false,
        message: 'Broker is not a leader',
        details: `Broker ${leaderBroker.name} is not configured as a leader account`
      });
      
      return {
        success: false,
        message: 'Broker is not a leader',
        leaderOrderId: order.id
      };
    }
    
    // Filter by symbol based on copyMode
    if (!isSymbolAllowed(order.symbol, settings)) {
      await storage.createCopyTradingLog({
        leaderId: order.brokerId,
        leaderOrderId: order.id,
        followerOrderId: null,
        symbol: order.symbol,
        quantity: order.quantity,
        side: order.action === 'buy' ? 'buy' : 'sell',
        status: 'filtered',
        success: false,
        message: 'Symbol filtered out by trading settings',
        details: `Symbol ${order.symbol} is not allowed by copy trading settings`
      });
      
      return {
        success: false,
        message: `Symbol ${order.symbol} filtered out by trading settings`,
        leaderOrderId: order.id
      };
    }
    
    // Get all follower brokers
    const followers = await storage.getBrokers();
    const followerBrokers = followers.filter(b => b.role === 'follower' && b.connected);
    
    if (followerBrokers.length === 0) {
      await storage.createCopyTradingLog({
        leaderId: order.brokerId,
        leaderOrderId: order.id,
        followerOrderId: null,
        symbol: order.symbol,
        quantity: order.quantity,
        side: order.action === 'buy' ? 'buy' : 'sell',
        status: 'error',
        success: false,
        message: 'No connected follower accounts',
        details: 'Configure and connect follower accounts to copy trades'
      });
      
      return {
        success: false,
        message: 'No connected follower accounts',
        leaderOrderId: order.id
      };
    }
    
    // Apply delay if configured
    if (settings.delaySeconds > 0) {
      await storage.createCopyTradingLog({
        leaderId: order.brokerId,
        leaderOrderId: order.id,
        followerOrderId: null,
        symbol: order.symbol,
        quantity: order.quantity, 
        side: order.action === 'buy' ? 'buy' : 'sell',
        status: 'processing',
        success: true,
        message: `Delaying order copy for ${settings.delaySeconds} seconds`,
        details: null
      });
      
      // Schedule the processing after delay
      setTimeout(async () => {
        await processCopyOrder(order, followerBrokers, settings);
      }, settings.delaySeconds * 1000);
      
      return {
        success: true,
        message: `Order will be copied after ${settings.delaySeconds} second delay`,
        leaderOrderId: order.id
      };
    }
    
    // Process order immediately if no delay
    return await processCopyOrder(order, followerBrokers, settings);
  
  } catch (error: any) {
    console.error('Error handling leader order:', error);
    
    // Log error
    await storage.createSystemLog({
      type: 'error',
      component: 'copyTrading',
      message: `Failed to process leader order: ${error.message}`
    });
    
    await storage.createCopyTradingLog({
      leaderId: order.brokerId,
      leaderOrderId: order.id,
      followerOrderId: null,
      symbol: order.symbol,
      quantity: order.quantity,
      side: order.action === 'buy' ? 'buy' : 'sell',
      status: 'error',
      success: false,
      message: 'Error processing leader order',
      details: error.message
    });
    
    return { 
      success: false, 
      message: 'Error processing leader order',
      error: error.message,
      leaderOrderId: order.id
    };
  }
}

/**
 * Process copying of an order to all followers
 */
async function processCopyOrder(order: Order, followers: any[], settings: CopyTradingSetting) {
  try {
    const results = {
      total: followers.length,
      successful: 0,
      failed: 0,
      details: [] as any[]
    };
    
    // Log order receipt
    await storage.createCopyTradingLog({
      leaderId: order.brokerId,
      leaderOrderId: order.id,
      followerOrderId: null,
      symbol: order.symbol,
      quantity: order.quantity,
      side: order.action === 'buy' ? 'buy' : 'sell',
      status: 'received',
      success: true,
      message: `Processing copy of ${order.symbol} order to ${followers.length} followers`,
      details: null
    });
    
    // Process for each follower
    for (const follower of followers) {
      try {
        // Prepare order data for the follower based on leader order
        const orderData: OrderData = {
          symbol: order.symbol,
          side: order.action === 'buy' ? 'buy' : 'sell',
          type: order.orderType,
          quantity: calculateFollowerQuantity(order.quantity, settings.positionSizeType, settings.positionSizeValue, settings.maxPositionSize),
          timeInForce: order.timeInForce,
          limitPrice: order.price || undefined,
          // Add any additional order parameters needed
        };
        
        // Skip if quantity became 0 after calculation (due to rules/rounding)
        if (orderData.quantity <= 0) {
          await storage.createCopyTradingLog({
            leaderId: order.brokerId,
            leaderOrderId: order.id,
            followerOrderId: null,
            symbol: order.symbol,
            quantity: 0,
            side: orderData.side,
            status: 'skipped',
            success: false,
            message: `Zero quantity after applying sizing rules for ${follower.name}`,
            details: 'Adjust position sizing settings to allow smaller trades'
          });
          
          results.failed++;
          results.details.push({
            follower: follower.name,
            status: 'skipped',
            message: 'Zero quantity after applying sizing rules'
          });
          continue;
        }
        
        // Check risk settings before placing the order
        const riskCheckPassed = await performRiskCheck(order, follower, orderData.quantity);
        if (!settings.riskCheckEnabled || riskCheckPassed) {
          // Create follower order record
          const followerOrder = await storage.createOrder({
            brokerId: follower.id,
            symbol: orderData.symbol,
            action: orderData.side,
            orderType: orderData.type,
            quantity: orderData.quantity,
            price: orderData.limitPrice || null,
            status: 'pending',
            timeInForce: orderData.timeInForce,
            brokerOrderId: null, // Will be updated once the order is placed
            parentOrderId: order.id,
            isCopyTrade: true,
            instrumentType: order.instrumentType
          });
          
          // Log success
          const log = await storage.createCopyTradingLog({
            leaderId: order.brokerId,
            leaderOrderId: order.id,
            followerOrderId: followerOrder.id,
            symbol: order.symbol,
            quantity: orderData.quantity,
            side: orderData.side,
            status: 'completed',
            success: true,
            message: `Successfully copied ${order.symbol} ${orderData.side} order to ${follower.name}`,
            details: `Follower quantity: ${orderData.quantity}, Leader quantity: ${order.quantity}`
          });
          
          // Broadcast the log via WebSocket for real-time updates
          await broadcastCopyTradingLog(log);
          
          results.successful++;
          results.details.push({
            follower: follower.name,
            status: 'completed',
            orderId: followerOrder.id,
            quantity: orderData.quantity
          });
        } else {
          // Log risk check failure
          const rejectionLog = await storage.createCopyTradingLog({
            leaderId: order.brokerId,
            leaderOrderId: order.id,
            followerOrderId: null,
            symbol: order.symbol,
            quantity: orderData.quantity,
            side: orderData.side,
            status: 'rejected',
            success: false,
            message: `Risk check failed for ${follower.name}`,
            details: 'Order exceeds risk parameters'
          });
          
          // Broadcast risk check failure via WebSocket
          await broadcastCopyTradingLog(rejectionLog);
          
          results.failed++;
          results.details.push({
            follower: follower.name,
            status: 'rejected',
            message: 'Risk check failed'
          });
        }
      } catch (error: any) {
        // Log error for this follower
        const errorLog = await storage.createCopyTradingLog({
          leaderId: order.brokerId,
          leaderOrderId: order.id,
          followerOrderId: null,
          symbol: order.symbol,
          quantity: order.quantity,
          side: order.action === 'buy' ? 'buy' : 'sell',
          status: 'error',
          success: false,
          message: `Error copying to ${follower.name}`,
          details: error.message
        });
        
        // Broadcast the error via WebSocket
        await broadcastCopyTradingLog(errorLog);
        
        results.failed++;
        results.details.push({
          follower: follower.name,
          status: 'error',
          message: error.message
        });
      }
    }
    
    return {
      success: true,
      message: `Processed copy order for ${order.symbol} to ${followers.length} followers. Success: ${results.successful}, Failed: ${results.failed}`,
      leaderOrderId: order.id,
      results
    };
  } catch (error: any) {
    console.error('Error processing copy order:', error);
    return { 
      success: false, 
      message: 'Error processing copy order',
      error: error.message,
      leaderOrderId: order.id
    };
  }
}

/**
 * Calculate the quantity for a follower order based on the copy trading settings
 * @param leaderQuantity Original order quantity from the leader
 * @param positionSizeType Type of position sizing ('fixed', 'percentage', 'proportional')
 * @param positionSizeValue Value used for position sizing calculation
 * @param maxPositionSize Maximum position size allowed (0 = no limit)
 * @returns Calculated quantity for the follower
 */
function calculateFollowerQuantity(
  leaderQuantity: number,
  positionSizeType: string,
  positionSizeValue: number,
  maxPositionSize: number
): number {
  let quantity = 0;
  
  switch (positionSizeType) {
    case 'fixed':
      // Fixed quantity regardless of leader size
      quantity = positionSizeValue;
      break;
      
    case 'percentage':
      // Percentage of leader position
      quantity = Math.floor(leaderQuantity * (positionSizeValue / 100));
      break;
      
    case 'proportional':
      // Proportional to account size ratio (simplified here)
      // In a real implementation, would account for account equity ratios
      quantity = Math.floor(leaderQuantity * (positionSizeValue / 100));
      break;
      
    default:
      // Default to exact copy
      quantity = leaderQuantity;
  }
  
  // Enforce minimum quantity of 1
  quantity = Math.max(1, quantity);
  
  // Apply max position size limit if set
  if (maxPositionSize > 0) {
    quantity = Math.min(quantity, maxPositionSize);
  }
  
  return quantity;
}

/**
 * Check if a symbol is allowed based on copy trading settings
 * @param symbol Symbol to check
 * @param settings Copy trading settings
 * @returns Whether the symbol is allowed
 */
function isSymbolAllowed(symbol: string, settings: CopyTradingSetting): boolean {
  // Allow all symbols mode
  if (settings.copyMode === 'all') {
    return true;
  }
  
  // Check whitelist if in whitelist mode
  if (settings.copyMode === 'whitelist' && settings.symbolWhitelist) {
    return settings.symbolWhitelist.includes(symbol);
  }
  
  // Check blacklist if in blacklist mode
  if (settings.copyMode === 'blacklist' && settings.symbolBlacklist) {
    return !settings.symbolBlacklist.includes(symbol);
  }
  
  // Default allow (should never reach here with properly configured settings)
  return true;
}

/**
 * Perform risk check for a copy trade
 * @param leaderOrder Original order from leader
 * @param follower Follower broker information
 * @param followerQuantity Calculated quantity for follower
 * @returns Whether the trade passes risk check
 */
async function performRiskCheck(
  leaderOrder: Order,
  follower: any,
  followerQuantity: number
): Promise<boolean> {
  try {
    // Get risk settings for the follower
    const riskSettings = await storage.getRiskSettingByBrokerId(follower.id);
    if (!riskSettings) {
      // No risk settings found, create default log entry
      await storage.createSystemLog({
        type: 'warning',
        component: 'copyTrading',
        message: `No risk settings found for broker ${follower.name} (ID: ${follower.id})`
      });
      return true; // Default to allow if no risk settings
    }
    
    // Get symbol information
    const symbol = await storage.getSymbolByName(leaderOrder.symbol);
    
    // Check max position size
    if (followerQuantity > riskSettings.maxPositionSize) {
      // Create risk event
      const riskEvent = await storage.createRiskEvent({
        type: 'position_size_exceeded',
        eventType: 'position_size_exceeded',
        brokerId: follower.id,
        symbol: leaderOrder.symbol,
        description: `Quantity ${followerQuantity} exceeds max position size of ${riskSettings.maxPositionSize}`,
        active: true
      });
      
      // Broadcast risk event via WebSocket
      broadcastMessage({
        type: 'risk_event',
        data: riskEvent
      });
      
      return false;
    }
    
    // Check max position value (if we have price info)
    const orderValue = leaderOrder.price ? leaderOrder.price * followerQuantity : 0;
    if (orderValue > 0 && orderValue > riskSettings.maxPositionValue) {
      // Create risk event
      const valueRiskEvent = await storage.createRiskEvent({
        type: 'position_value_exceeded',
        eventType: 'position_value_exceeded',
        brokerId: follower.id,
        symbol: leaderOrder.symbol,
        description: `Order value $${orderValue} exceeds max position value of $${riskSettings.maxPositionValue}`,
        active: true
      });
      
      // Broadcast risk event via WebSocket
      broadcastMessage({
        type: 'risk_event',
        data: valueRiskEvent
      });
      
      return false;
    }
    
    // If we have account equity info, check max position as % of account
    if (follower.balance && follower.balance > 0) {
      const positionPercentOfAccount = orderValue / follower.balance * 100;
      // Note: maxPositionPercent would be a field to add to risk settings
      if (positionPercentOfAccount > 0 && positionPercentOfAccount > riskSettings.maxPositionPercent) {
        // Create risk event
        const percentRiskEvent = await storage.createRiskEvent({
          type: 'position_percent_exceeded',
          eventType: 'position_percent_exceeded',
          brokerId: follower.id,
          symbol: leaderOrder.symbol, 
          description: `Position is ${positionPercentOfAccount.toFixed(2)}% of account, exceeds limit of ${riskSettings.maxPositionPercent}%`,
          active: true
        });
        
        // Broadcast risk event via WebSocket
        broadcastMessage({
          type: 'risk_event',
          data: percentRiskEvent
        });
        
        return false;
      }
    }
    
    // Check restricted symbols
    if (riskSettings.restrictedSymbols && 
        Array.isArray(riskSettings.restrictedSymbols) && 
        riskSettings.restrictedSymbols.includes(leaderOrder.symbol)) {
      // Create risk event
      const symbolRiskEvent = await storage.createRiskEvent({
        type: 'restricted_symbol',
        eventType: 'restricted_symbol',
        brokerId: follower.id,
        symbol: leaderOrder.symbol,
        description: `Symbol ${leaderOrder.symbol} is in the restricted list`,
        active: true
      });
      
      // Broadcast risk event via WebSocket
      broadcastMessage({
        type: 'risk_event',
        data: symbolRiskEvent
      });
      
      return false;
    }
    
    // All checks passed
    return true;
  } catch (error: any) {
    console.error(`Risk check error for ${follower.name}:`, error);
    
    // Log error
    await storage.createSystemLog({
      type: 'error', 
      component: 'copyTrading',
      message: `Risk check error for ${follower.name}: ${error.message}`
    });
    
    return false; // Fail closed for safety
  }
}

/**
 * Update copy trading settings
 * @param settings New settings to apply
 * @returns Updated settings
 */
export async function updateCopyTradingSettings(settings: any) {
  try {
    // Ensure proper types for array fields
    const formattedSettings = {
      ...settings,
      symbolWhitelist: Array.isArray(settings.symbolWhitelist) ? settings.symbolWhitelist : [],
      symbolBlacklist: Array.isArray(settings.symbolBlacklist) ? settings.symbolBlacklist : []
    };
    
    // Update settings in database
    const updatedSettings = await storage.createOrUpdateCopyTradingSettings(formattedSettings);
    
    // Log settings update
    const settingsLog = await storage.createSystemLog({
      type: 'info',
      component: 'copyTrading',
      message: `Copy trading settings updated. Enabled: ${settings.enabled ? 'Yes' : 'No'}`
    });
    
    // Broadcast settings change via WebSocket
    broadcastMessage({
      type: 'copy_trading_settings_updated',
      data: updatedSettings
    });
    
    // Also broadcast the log
    broadcastSystemLog(settingsLog);
    
    return updatedSettings;
  } catch (error: any) {
    console.error('Error updating copy trading settings:', error);
    
    // Log error
    await storage.createSystemLog({
      type: 'error',
      component: 'copyTrading',
      message: `Failed to update copy trading settings: ${error.message}`
    });
    
    throw error;
  }
}

/**
 * Check if a broker is permitted to place a manual order
 * @param brokerId Broker ID to check
 * @returns Whether the broker can place manual orders
 */
export async function canPlaceManualOrder(brokerId: number): Promise<boolean> {
  try {
    // Get broker details
    const broker = await storage.getBroker(brokerId);
    if (!broker) {
      return false;
    }
    
    // Leaders can always place manual orders
    if (broker.role === 'leader') {
      return true;
    }
    
    // For followers, check settings
    const settings = await storage.getCopyTradingSettings();
    
    // If copy trading is disabled or follower manual orders are allowed, return true
    if (!settings || !settings.enabled || !settings.forbidFollowerManualOrders) {
      return true;
    }
    
    // Otherwise, followers cannot place manual orders when copy trading is enabled
    return false;
  } catch (error) {
    console.error('Error checking manual order permission:', error);
    return false; // Default to not allowing on error
  }
}