import { Express, Request, Response } from "express";
import passport from "passport";
import jwt from "jsonwebtoken";
import { storage } from "../storage";

// Export authenticate middleware for other routes
export const authenticate = (req: Request, res: Response, next: any) => {
  const authHeader = req.headers.authorization;
  
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7);
    try {
      const secret = process.env.JWT_SECRET || 'default_jwt_secret_key_for_development';
      const decoded = jwt.verify(token, secret) as {id: number; username: string};
      req.user = decoded;
      return next();
    } catch (error) {
      return res.status(401).json({ message: 'Invalid token' });
    }
  } else {
    return passport.authenticate('local', { session: false })(req, res, next);
  }
};

// Setup authentication routes
export function setupAuthRoutes(app: Express) {
  // Login route
  app.post('/api/auth/login', (req: Request, res: Response, next) => {
    passport.authenticate('local', { session: true }, (err: any, user: any, info: any) => {
      if (err) {
        return next(err);
      }
      
      if (!user) {
        return res.status(401).json({ message: info.message || 'Authentication failed' });
      }
      
      req.login(user, { session: true }, (loginErr) => {
        if (loginErr) {
          return next(loginErr);
        }
        
        // Generate JWT token
        const secret = process.env.JWT_SECRET || 'default_jwt_secret_key_for_development';
        const token = jwt.sign(
          { id: user.id, username: user.username },
          secret,
          { expiresIn: '24h' }
        );
        
        // Create system log
        storage.createSystemLog({
          type: 'info',
          component: 'auth',
          message: `User ${user.username} logged in`
        });
        
        // Return user and token
        return res.json({ 
          message: 'Login successful',
          user: {
            id: user.id,
            username: user.username,
            isAdmin: user.isAdmin
          },
          token 
        });
      });
    })(req, res, next);
  });
  
  // Logout route
  app.post('/api/auth/logout', (req: Request, res: Response) => {
    if (req.user) {
      // Create system log
      storage.createSystemLog({
        type: 'info',
        component: 'auth',
        message: `User logged out`
      });
    }
    
    req.logout(function(err) {
      if (err) { 
        return res.status(500).json({ message: 'Logout failed', error: err.message });
      }
      res.json({ message: 'Logout successful' });
    });
  });
  
  // User profile route (authenticated)
  app.get('/api/auth/profile', authenticate, (req: Request, res: Response) => {
    // User will be available on req.user from the middleware
    res.json({ user: req.user });
  });
  
  // Check auth status route
  app.get('/api/auth/status', (req: Request, res: Response) => {
    if (req.isAuthenticated() || req.user) {
      res.json({ authenticated: true, user: req.user });
    } else {
      res.json({ authenticated: false });
    }
  });
  
  // Register route (for future use)
  app.post('/api/auth/register', async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      // Check if username exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: 'Username already exists' });
      }
      
      // Create new user
      const user = await storage.createUser({
        username,
        password, // In production, this should be hashed
        isAdmin: false
      });
      
      // Create system log
      storage.createSystemLog({
        type: 'info',
        component: 'auth',
        message: `New user registered: ${username}`
      });
      
      // Return success
      res.status(201).json({ 
        message: 'Registration successful',
        user: {
          id: user.id,
          username: user.username,
          isAdmin: user.isAdmin
        }
      });
    } catch (error: any) {
      console.error('Registration error:', error);
      res.status(500).json({ message: 'Registration failed', error: error.message });
    }
  });
}