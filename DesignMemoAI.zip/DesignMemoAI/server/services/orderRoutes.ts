import { Express, Request, Response } from 'express';
import { z } from 'zod';
import { storage } from '../storage';
import { authenticate } from './auth';
import { createOrder, cancelOrder, modifyOrder, getAccountDetails, getAllAccountsDetails, getQuotes, getOptionChain, searchInstruments } from './orderManagement';
import { insertOrderSchema } from '@shared/schema';

// Create order validation schema
const createOrderValidationSchema = insertOrderSchema.extend({
  brokerId: z.number().int().positive('Broker ID is required')
});

// Update order validation schema
const updateOrderValidationSchema = z.object({
  quantity: z.number().int().positive().optional(),
  limitPrice: z.number().positive().optional(),
  stopPrice: z.number().positive().optional(),
  type: z.string().optional(),
  timeInForce: z.string().optional(),
  status: z.string().optional()
});

// Symbol search validation schema
const symbolSearchValidationSchema = z.object({
  query: z.string().min(1, 'Search query is required'),
  brokerId: z.number().int().positive('Broker ID is required')
});

// Quotes validation schema
const quotesValidationSchema = z.object({
  symbols: z.array(z.string()).min(1, 'At least one symbol is required'),
  brokerId: z.number().int().positive('Broker ID is required')
});

// Option chain validation schema
const optionChainValidationSchema = z.object({
  symbol: z.string().min(1, 'Symbol is required'),
  brokerId: z.number().int().positive('Broker ID is required')
});

/**
 * Setup order management API routes
 * @param app Express application
 */
export function setupOrderRoutes(app: Express) {
  // Get all orders
  app.get('/api/orders', authenticate, async (req: Request, res: Response) => {
    try {
      const orders = await storage.getOrders();
      res.status(200).json(orders);
    } catch (error: any) {
      console.error('Get orders error:', error);
      res.status(500).json({ 
        message: 'Failed to get orders', 
        error: error.message 
      });
    }
  });

  // Get order by ID
  app.get('/api/orders/:id', authenticate, async (req: Request, res: Response) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: 'Invalid order ID' });
      }

      const order = await storage.getOrder(orderId);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }

      res.status(200).json(order);
    } catch (error: any) {
      console.error('Get order error:', error);
      res.status(500).json({ 
        message: 'Failed to get order', 
        error: error.message 
      });
    }
  });

  // Create new order
  app.post('/api/orders', authenticate, async (req: Request, res: Response) => {
    try {
      // Validate request body
      const validationResult = createOrderValidationSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          message: 'Validation error',
          errors: validationResult.error.errors
        });
      }

      const orderData = validationResult.data;

      // Create and place order
      const createdOrder = await createOrder(orderData);

      res.status(201).json({
        message: 'Order created successfully',
        order: createdOrder
      });
    } catch (error: any) {
      console.error('Create order error:', error);
      res.status(500).json({ 
        message: 'Failed to create order', 
        error: error.message 
      });
    }
  });

  // Cancel order
  app.post('/api/orders/:id/cancel', authenticate, async (req: Request, res: Response) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: 'Invalid order ID' });
      }

      // Cancel order
      const cancelled = await cancelOrder(orderId);

      res.status(200).json({
        message: 'Order cancelled successfully',
        cancelled
      });
    } catch (error: any) {
      console.error('Cancel order error:', error);
      res.status(500).json({ 
        message: 'Failed to cancel order', 
        error: error.message 
      });
    }
  });

  // Update order
  app.put('/api/orders/:id', authenticate, async (req: Request, res: Response) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: 'Invalid order ID' });
      }

      // Validate request body
      const validationResult = updateOrderValidationSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          message: 'Validation error',
          errors: validationResult.error.errors
        });
      }

      const orderData = validationResult.data;

      // Modify order
      const updatedOrder = await modifyOrder(orderId, orderData);

      res.status(200).json({
        message: 'Order updated successfully',
        order: updatedOrder
      });
    } catch (error: any) {
      console.error('Update order error:', error);
      res.status(500).json({ 
        message: 'Failed to update order', 
        error: error.message 
      });
    }
  });

  // Get account details
  app.get('/api/accounts/:brokerId/details', authenticate, async (req: Request, res: Response) => {
    try {
      const brokerId = parseInt(req.params.brokerId);
      if (isNaN(brokerId)) {
        return res.status(400).json({ message: 'Invalid broker ID' });
      }

      // Get account details
      const accountDetails = await getAccountDetails(brokerId);

      res.status(200).json(accountDetails);
    } catch (error: any) {
      console.error('Get account details error:', error);
      res.status(500).json({ 
        message: 'Failed to get account details', 
        error: error.message 
      });
    }
  });

  // Get all accounts details
  app.get('/api/accounts/details', authenticate, async (req: Request, res: Response) => {
    try {
      // Get all accounts details
      const accountsDetails = await getAllAccountsDetails();

      res.status(200).json(accountsDetails);
    } catch (error: any) {
      console.error('Get all accounts details error:', error);
      res.status(500).json({ 
        message: 'Failed to get all accounts details', 
        error: error.message 
      });
    }
  });

  // Search for instruments (stocks, ETFs, etc)
  app.post('/api/instruments/search', authenticate, async (req: Request, res: Response) => {
    try {
      // Validate request body
      const validationResult = symbolSearchValidationSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          message: 'Validation error',
          errors: validationResult.error.errors
        });
      }

      const { query, brokerId } = validationResult.data;

      // Search for instruments
      const searchResults = await searchInstruments(brokerId, query);

      res.status(200).json(searchResults);
    } catch (error: any) {
      console.error('Search instruments error:', error);
      res.status(500).json({ 
        message: 'Failed to search instruments', 
        error: error.message 
      });
    }
  });

  // Get quotes for symbols
  app.post('/api/marketdata/quotes', authenticate, async (req: Request, res: Response) => {
    try {
      // Validate request body
      const validationResult = quotesValidationSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          message: 'Validation error',
          errors: validationResult.error.errors
        });
      }

      const { symbols, brokerId } = validationResult.data;

      // Get quotes
      const quotes = await getQuotes(brokerId, symbols);

      res.status(200).json(quotes);
    } catch (error: any) {
      console.error('Get quotes error:', error);
      res.status(500).json({ 
        message: 'Failed to get quotes', 
        error: error.message 
      });
    }
  });

  // Get option chain for a symbol
  app.post('/api/marketdata/optionchain', authenticate, async (req: Request, res: Response) => {
    try {
      // Validate request body
      const validationResult = optionChainValidationSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          message: 'Validation error',
          errors: validationResult.error.errors
        });
      }

      const { symbol, brokerId } = validationResult.data;

      // Get option chain
      const optionChain = await getOptionChain(brokerId, symbol);

      res.status(200).json(optionChain);
    } catch (error: any) {
      console.error('Get option chain error:', error);
      res.status(500).json({ 
        message: 'Failed to get option chain', 
        error: error.message 
      });
    }
  });
}