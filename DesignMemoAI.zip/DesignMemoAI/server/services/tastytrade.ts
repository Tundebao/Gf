import axios from 'axios';
import { storage } from '../storage';

// Tastytrade API base URL (using tastyworks.com as specified)
const API_BASE_URL = 'https://api.tastyworks.com';

// Alternative API URL if needed
const ALTERNATE_API_BASE_URL = 'https://api.tastytrade.com';

// API endpoints
const endpoints = {
  login: `${API_BASE_URL}/sessions`,
  accounts: `${API_BASE_URL}/accounts`,
  // Alternative endpoints
  loginAlt: `${ALTERNATE_API_BASE_URL}/sessions`,
  accountsAlt: `${ALTERNATE_API_BASE_URL}/customers/me/accounts`,
};

// Interface for Tastytrade authentication response
interface TastytradeAuthResponse {
  data?: {
    user_id?: string;
    session_token?: string;
    remember_token?: string;
  };
  session_token: string; // Make this required
  user_id?: string;
  remember_token?: string;
}

// Interface for Tastytrade account response
interface TastytradeAccount {
  account_number: string;
  nickname?: string;
  account_type_name?: string;
  is_margin?: boolean;
  margin_or_cash?: 'margin' | 'cash';
  // Additional properties for account details
  available_trading_buying_power?: number;
  cash_balance?: number;
  equity_value?: number;
  net_liquidating_value?: number;
  day_trader_status?: string;
}

// Interface for Tastytrade accounts response
interface TastytradeAccountsResponse {
  data?: TastytradeAccount[];
  items?: TastytradeAccount[];
  accounts?: TastytradeAccount[];
}

// Interface for mapped account data used in our application
interface MappedTastytradeAccount {
  accountId: string;
  nickname?: string;
  accountType?: string;
  isMargin?: boolean;
  marginOrCash?: 'margin' | 'cash';
  balance?: number;
  buyingPower?: number; 
  pdtStatus?: string;
}

/**
 * Authenticates with Tastytrade API and returns a session token
 * @param username Tastytrade username
 * @param password Tastytrade password
 * @returns Authentication response including session token
 */
export async function authenticateWithTastytrade(username: string, password: string): Promise<TastytradeAuthResponse> {
  try {
    console.log(`Attempting to authenticate with Tastytrade using username: ${username}`);
    
    // Make authentication request exactly as specified
    const response = await axios.post(endpoints.login, {
      login: username,
      password: password,
    }, {
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Log the complete raw response for debugging
    console.log('Auth response received. Status:', response.status);
    console.log('Response data:', JSON.stringify(response.data));
    console.log('Response headers:', JSON.stringify(response.headers));

    // Handle different possible response formats for the session token
    let sessionToken = '';
    let userId = '';

    // Check all possible paths where the session token might be located
    if (response.data && response.data.data && response.data.data["session-token"]) {
      // Format in actual Tastytrade API: { data: { "session-token": "..." } }
      sessionToken = response.data.data["session-token"];
      userId = response.data.data.user && response.data.data.user["external-id"] || '';
      console.log('Found session token in response.data.data[session-token]');
    } else if (response.data && response.data.data && response.data.data.session_token) {
      // Format: { data: { session_token: "..." } }
      sessionToken = response.data.data.session_token;
      userId = response.data.data.user_id || '';
      console.log('Found session token in response.data.data.session_token');
    } else if (response.data && response.data.session_token) {
      // Format: { session_token: "..." }
      sessionToken = response.data.session_token;
      userId = response.data.user_id || '';
      console.log('Found session token in response.data.session_token');
    } else if (response.data && response.data["session-token"]) {
      // Format: { "session-token": "..." }
      sessionToken = response.data["session-token"];
      userId = response.data.user_id || '';
      console.log('Found session token in response.data[session-token]');
    } else if (response.data) {
      // Try to parse the response more generically with regex for both formats
      console.log('Looking for session token in entire response object');
      const responseStr = JSON.stringify(response.data);
      
      // Try with hyphen (session-token) which is what the real API uses
      let sessionTokenMatch = responseStr.match(/"session-token"\s*:\s*"([^"]+)"/);
      if (sessionTokenMatch && sessionTokenMatch[1]) {
        sessionToken = sessionTokenMatch[1];
        console.log('Found session token via regex match for session-token');
      } else {
        // Try with underscore (session_token)
        sessionTokenMatch = responseStr.match(/"session_token"\s*:\s*"([^"]+)"/);
        if (sessionTokenMatch && sessionTokenMatch[1]) {
          sessionToken = sessionTokenMatch[1];
          console.log('Found session token via regex match for session_token');
        }
      }
    }

    if (!sessionToken) {
      console.error('No session token found in API response:', JSON.stringify(response.data));
      throw new Error('No session token found in API response');
    }

    console.log('Successfully authenticated with Tastytrade. Token received.');
    return {
      session_token: sessionToken,
      user_id: userId
    };
  } catch (error: any) {
    console.error('Tastytrade authentication error:', error.response?.data || error.message);
    
    // Provide user-friendly error messages
    if (error.response) {
      if (error.response.status === 401) {
        throw new Error('Invalid username or password for Tastytrade');
      } else if (error.response.status === 403) {
        throw new Error('Access forbidden. Your account may be locked or disabled');
      } else if (error.response.status === 429) {
        throw new Error('Too many login attempts. Please try again later');
      } else if (error.code === 'ECONNABORTED') {
        throw new Error('Connection timed out. Please check your internet connection and try again');
      } else if (error.code === 'ENOTFOUND') {
        throw new Error('Unable to reach Tastytrade servers. Please check your internet connection');
      }
    }
    
    // Generic error message for other cases
    throw new Error(error.response?.data?.error || 'Failed to authenticate with Tastytrade');
  }
}

/**
 * Fetches accounts for the authenticated user
 * @param sessionToken Session token obtained from authentication
 * @returns List of user accounts
 */
export async function fetchTastytradeAccounts(sessionToken: string): Promise<TastytradeAccount[]> {
  let retryCount = 0;
  const maxRetries = 3; // Try more approaches
  
  while (retryCount <= maxRetries) {
    try {
      console.log(`Fetching Tastytrade accounts with token (attempt ${retryCount + 1})`);
      
      // Try different approaches based on retry count
      let endpoint = endpoints.accounts;
      let headers: Record<string, string> = {};
      
      if (retryCount === 0) {
        // First try: Use token directly as Authorization header (no Bearer)
        console.log('Using authorization header: [token]');
        headers = {
          'Authorization': sessionToken,
          'Accept': 'application/json',
        };
      } else if (retryCount === 1) {
        // Second try: Use Bearer prefix
        console.log('Using authorization header: Bearer [token]');
        headers = {
          'Authorization': `Bearer ${sessionToken}`,
          'Accept': 'application/json',
        };
      } else if (retryCount === 2) {
        // Third try: Try alternative API endpoint without Bearer
        endpoint = endpoints.accountsAlt;
        console.log('Using alternative endpoint with authorization header: [token]');
        headers = {
          'Authorization': sessionToken,
          'Accept': 'application/json',
        };
      } else {
        // Last try: Try alternative API endpoint with Bearer
        endpoint = endpoints.accountsAlt;
        console.log('Using alternative endpoint with authorization header: Bearer [token]');
        headers = {
          'Authorization': `Bearer ${sessionToken}`,
          'Accept': 'application/json',
        };
      }
      
      const response = await axios.get(endpoint, {
        headers,
        // Add timeout to prevent hanging
        timeout: 10000,
      });

      // Log complete response for debugging
      console.log('Accounts API response status:', response.status);
      console.log('Accounts API response headers:', JSON.stringify(response.headers));
      console.log('Accounts API response data:', typeof response.data, JSON.stringify(response.data).substring(0, 500) + '...');

      // Validate the response format
      if (!response.data) {
        throw new Error('Empty response from Tastytrade API');
      }
      
      // Check if the response structure matches what we expect (try all known formats)
      // Format used by real Tastytrade API
      if (response.data.data && response.data.data.items && Array.isArray(response.data.data.items)) {
        console.log(`Successfully fetched ${response.data.data.items.length} Tastytrade accounts (data.items array)`);
        return response.data.data.items.map((item: any) => {
          // Convert account-number to account_number for our interface
          return {
            account_number: item["account-number"] || item.account_number || "unknown",
            nickname: item.nickname || "",
            account_type_name: item["account-type-name"] || item.account_type_name || "",
            is_margin: item["is-margin"] !== undefined ? item["is-margin"] : (item.is_margin || false),
            margin_or_cash: item["margin-or-cash"] || item.margin_or_cash || "unknown",
            // Account balances and status
            available_trading_buying_power: item["available-trading-buying-power"] || item.available_trading_buying_power || 0,
            cash_balance: item["cash-balance"] || item.cash_balance || 0,
            equity_value: item["equity-value"] || item.equity_value || 0,
            net_liquidating_value: item["net-liquidating-value"] || item.net_liquidating_value || 0,
            day_trader_status: item["day-trader-status"] || item.day_trader_status || "No PDT Restrictions"
          } as TastytradeAccount;
        });
      } else if (response.data.items && Array.isArray(response.data.items)) {
        console.log(`Successfully fetched ${response.data.items.length} Tastytrade accounts (items array)`);
        return response.data.items as TastytradeAccount[];
      } else if (Array.isArray(response.data)) {
        // Handle case where items might be the direct response
        console.log(`Successfully fetched ${response.data.length} Tastytrade accounts (direct array)`);
        return response.data as TastytradeAccount[];
      } else if (response.data.data && Array.isArray(response.data.data)) {
        // Another possible response structure
        console.log(`Successfully fetched ${response.data.data.length} Tastytrade accounts (data array)`);
        return response.data.data as TastytradeAccount[];
      } else if (response.data.accounts && Array.isArray(response.data.accounts)) {
        // Another possible response structure
        console.log(`Successfully fetched ${response.data.accounts.length} Tastytrade accounts (accounts array)`);
        return response.data.accounts as TastytradeAccount[];
      }
      
      // Try to extract account data using regex if structured approach fails
      console.log('Attempting to extract account numbers using regex...');
      const responseStr = JSON.stringify(response.data);
      
      // Try to find account numbers with snake_case first
      let accountMatches = responseStr.match(/"account_number"\s*:\s*"([^"]+)"/g);
      
      if (accountMatches && accountMatches.length > 0) {
        console.log(`Found ${accountMatches.length} account numbers via regex (snake_case)`);
        // Extract just the account numbers and construct minimal account objects
        const accounts = accountMatches.map(match => {
          const matchResult = match.match(/"account_number"\s*:\s*"([^"]+)"/);
          const accountNumber = matchResult && matchResult[1] ? matchResult[1] : "unknown";
          return { account_number: accountNumber } as TastytradeAccount;
        });
        return accounts;
      }
      
      // If no snake_case matches, try with kebab-case (hyphen) which is what the real API uses
      accountMatches = responseStr.match(/"account-number"\s*:\s*"([^"]+)"/g);
      
      if (accountMatches && accountMatches.length > 0) {
        console.log(`Found ${accountMatches.length} account numbers via regex (kebab-case)`);
        // Extract just the account numbers and construct minimal account objects
        const accounts = accountMatches.map(match => {
          const matchResult = match.match(/"account-number"\s*:\s*"([^"]+)"/);
          const accountNumber = matchResult && matchResult[1] ? matchResult[1] : "unknown";
          return { account_number: accountNumber } as TastytradeAccount;
        });
        return accounts;
      }
      
      // If we can't recognize the structure, output it to logs and throw an error
      console.error('Unrecognized Tastytrade API response format:', JSON.stringify(response.data).substring(0, 1000));
      throw new Error('Invalid accounts response format from Tastytrade API');
    } catch (error: any) {
      console.error(`Tastytrade accounts fetch error (attempt ${retryCount + 1}):`, error.response?.data || error.message);
      
      // If this was our last retry, throw the error
      if (retryCount === maxRetries) {
        if (error.response?.status === 401) {
          throw new Error('Authentication token rejected. Please login again.');
        } else if (error.response?.status === 403) {
          throw new Error('Access forbidden. You may not have permission to view accounts.');
        }
        throw new Error(error.response?.data?.error || 'Failed to fetch Tastytrade accounts');
      }
      
      // Otherwise, retry after a short delay
      console.log('Retrying account fetch after error...');
      await new Promise(resolve => setTimeout(resolve, 1000)); // 1 second delay before retry
      retryCount++;
    }
  }
  
  // This should never be reached due to the while loop structure
  throw new Error('Failed to fetch Tastytrade accounts after retries');
}

/**
 * Connects to Tastytrade with credentials and returns account info
 * @param username Tastytrade username
 * @param password Tastytrade password
 * @returns Account information if successful
 */
export async function connectToTastytrade(username: string, password: string): Promise<{
  accounts: MappedTastytradeAccount[],
  sessionToken: string,
  userId?: string
}> {
  try {
    // Log connection attempt
    console.log(`ATTEMPTING TASTYTRADE CONNECTION FOR: ${username}`);
    await storage.createSystemLog({
      type: 'info',
      component: 'broker',
      message: `Attempting to connect to Tastytrade API with username: ${username}`
    });

    // Authenticate with Tastytrade
    console.log('Calling authenticateWithTastytrade...');
    const authResponse = await authenticateWithTastytrade(username, password);
    console.log('Authentication successful, token received:', authResponse.session_token ? 'Token received' : 'No token received');
    
    // Make sure we have a session token
    if (!authResponse.session_token) {
      throw new Error('No session token received from Tastytrade authentication');
    }
    
    // Fetch accounts using the session token
    console.log('Fetching accounts with session token...');
    const accounts = await fetchTastytradeAccounts(authResponse.session_token);
    
    console.log('Accounts fetched:', accounts ? `Found ${accounts.length} accounts` : 'No accounts found');
    
    if (!accounts || accounts.length === 0) {
      throw new Error('No accounts found for this Tastytrade user');
    }

    // Log success
    console.log('Tastytrade connection successful!');
    await storage.createSystemLog({
      type: 'success',
      component: 'broker',
      message: `Successfully connected to Tastytrade API. Found ${accounts.length} accounts.`
    });

    // Return account information and session data
    return {
      accounts: accounts.map(account => ({
        accountId: account.account_number,
        nickname: account.nickname,
        accountType: account.account_type_name,
        isMargin: account.is_margin,
        marginOrCash: account.margin_or_cash,
        // Map account balances and status to our schema
        balance: account.cash_balance || 0,
        buyingPower: account.available_trading_buying_power || 0,
        pdtStatus: account.day_trader_status || 'No PDT Restrictions'
      })),
      sessionToken: authResponse.session_token,
      userId: authResponse.user_id
    };
  } catch (error: any) {
    // Log error
    await storage.createSystemLog({
      type: 'error',
      component: 'broker',
      message: `Tastytrade connection error: ${error.message}`
    });

    throw error;
  }
}