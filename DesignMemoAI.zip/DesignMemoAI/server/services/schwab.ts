import axios from 'axios';
import { storage } from '../storage';

// Schwab API configuration - Using environment variables
const SCHWAB_CLIENT_ID = process.env.SCHWAB_CLIENT_ID || 'JtK96Q9sOAbNvbNSh9rWeaGuIK8Si335';
const SCHWAB_CLIENT_SECRET = process.env.SCHWAB_CLIENT_SECRET || '8lrmF9APAnOTsGMn';
const SCHWAB_REDIRECT_URI = process.env.SCHWAB_REDIRECT_URI || 'https://tradeswim.org/auth/schwab/callback';
const SCHWAB_API_BASE_URL = process.env.SCHWAB_API_BASE_URL || 'https://api.schwab.com';

// API endpoints
const endpoints = {
  // Authentication endpoints
  token: `${SCHWAB_API_BASE_URL}/oauth/token`,
  
  // Account endpoints
  accounts: `${SCHWAB_API_BASE_URL}/v1/accounts`,
  accountDetails: (accountId: string) => `${SCHWAB_API_BASE_URL}/v1/accounts/${accountId}`,
  accountBalances: (accountId: string) => `${SCHWAB_API_BASE_URL}/v1/accounts/${accountId}/balances`,
  accountPositions: (accountId: string) => `${SCHWAB_API_BASE_URL}/v1/accounts/${accountId}/positions`,
  
  // Trading endpoints
  placeOrder: (accountId: string) => `${SCHWAB_API_BASE_URL}/v1/accounts/${accountId}/orders`,
  orderStatus: (accountId: string, orderId: string) => `${SCHWAB_API_BASE_URL}/v1/accounts/${accountId}/orders/${orderId}`,
  cancelOrder: (accountId: string, orderId: string) => `${SCHWAB_API_BASE_URL}/v1/accounts/${accountId}/orders/${orderId}`,
  modifyOrder: (accountId: string, orderId: string) => `${SCHWAB_API_BASE_URL}/v1/accounts/${accountId}/orders/${orderId}`,
  
  // Market data endpoints
  quotes: `${SCHWAB_API_BASE_URL}/v1/marketdata/quotes`,
  optionChains: `${SCHWAB_API_BASE_URL}/v1/marketdata/chains`,
  instruments: `${SCHWAB_API_BASE_URL}/v1/instruments`,
  searchInstruments: `${SCHWAB_API_BASE_URL}/v1/instruments/search`,
};

// Interface for Schwab authentication response
interface SchwabAuthResponse {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  token_type: string;
}

// Interface for Schwab account
interface SchwabAccount {
  accountId: string;
  accountName: string;
  accountType: string;
  status: string;
  balance?: number;
  buyingPower?: number;
  pdtStatus?: string;
  isDayTrader?: boolean;
  isProfessionalTrader?: boolean;
}

// Interface for Account Balances
export interface SchwabAccountBalance {
  cashBalance: number;
  buyingPower: number;
  availableFunds: number;
  marginBalance: number;
  equityValue: number;
  longMarginValue: number;
  shortMarginValue: number;
  pendingDeposits: number;
  maintenanceMargin: number;
  maintenanceRequirement: number;
  lastUpdated: string;
}

// Interface for Position
export interface SchwabPosition {
  symbol: string;
  assetType: 'EQUITY' | 'OPTION' | 'MUTUAL_FUND' | 'ETF' | 'BOND' | 'OTHER';
  description: string;
  quantity: number;
  averagePrice: number;
  marketValue: number;
  currentPrice: number;
  openPrice: number;
  costBasis: number;
  unrealizedPL: number;
  unrealizedPLPercent: number;
  dayPL: number;
  dayPLPercent: number;
  holdingType: 'LONG' | 'SHORT';
  lastUpdated: string;
  // For options
  underlying?: string;
  strike?: number;
  expirationDate?: string;
  putCall?: 'PUT' | 'CALL';
}

// Order types - comprehensive order types supported by Schwab
export type OrderType = 'MARKET' | 'LIMIT' | 'STOP' | 'STOP_LIMIT' | 'TRAILING_STOP' | 'TRAILING_STOP_LIMIT';

// Order durations - all available duration types
export type OrderDuration = 'DAY' | 'GTC' | 'GTC_EXT' | 'AM' | 'PM' | 'IMMEDIATE_OR_CANCEL' | 'FILL_OR_KILL';

// Order status types
export type OrderStatus = 'PENDING' | 'OPEN' | 'FILLED' | 'PARTIALLY_FILLED' | 'CANCELED' | 'REJECTED' | 'EXPIRED';

// Interface for Order
export interface SchwabOrder {
  orderId?: string;
  accountId: string;
  symbol: string;
  quantity: number;
  price?: number;
  stopPrice?: number;
  orderType: OrderType;
  duration: OrderDuration;
  orderStrategy: 'SINGLE' | 'OCO' | 'TRIGGER';
  session: 'NORMAL' | 'AM' | 'PM' | 'SEAMLESS';
  assetType: 'EQUITY' | 'OPTION' | 'MUTUAL_FUND' | 'ETF' | 'BOND' | 'OTHER';
  instruction: 'BUY' | 'SELL' | 'BUY_TO_COVER' | 'SELL_SHORT' | 'BUY_TO_OPEN' | 'BUY_TO_CLOSE' | 'SELL_TO_OPEN' | 'SELL_TO_CLOSE';
  status?: OrderStatus;
  enteredTime?: string;
  closeTime?: string;
  tag?: string;
  legs?: SchwabOrderLeg[];
}

// Interface for Options multi-leg orders
export interface SchwabOrderLeg {
  symbol: string;
  instruction: 'BUY' | 'SELL' | 'BUY_TO_OPEN' | 'BUY_TO_CLOSE' | 'SELL_TO_OPEN' | 'SELL_TO_CLOSE';
  quantity: number;
  putCall?: 'PUT' | 'CALL';
  strike?: number;
  expirationDate?: string;
}

// Interface for Option Chain
export interface SchwabOptionChain {
  symbol: string;
  status: string;
  underlying: {
    symbol: string;
    description: string;
    price: number;
    change: number;
    percentChange: number;
    volume: number;
    quoteTime: string;
  };
  expirationDates: string[];
  strikes: number[];
  putExpDateMap: Record<string, Record<string, SchwabOptionContract[]>>;
  callExpDateMap: Record<string, Record<string, SchwabOptionContract[]>>;
}

// Interface for Option Contract
export interface SchwabOptionContract {
  putCall: 'PUT' | 'CALL';
  symbol: string;
  description: string;
  bid: number;
  ask: number;
  last: number;
  mark: number;
  bidSize: number;
  askSize: number;
  lastSize: number;
  highPrice: number;
  lowPrice: number;
  openPrice: number;
  closePrice: number;
  totalVolume: number;
  quoteTimeInLong: number;
  tradeTimeInLong: number;
  netChange: number;
  delta: number;
  gamma: number;
  theta: number;
  vega: number;
  rho: number;
  timeValue: number;
  openInterest: number;
  inTheMoney: boolean;
  theoreticalValue: number;
  theoreticalVolatility: number;
  expirationDate: string;
  daysToExpiration: number;
  strikePrice: number;
  percentChange: number;
  markChange: number;
  markPercentChange: number;
}

// Interface for Market Data Quote
export interface SchwabQuote {
  symbol: string;
  description: string;
  bidPrice: number;
  bidSize: number;
  bidId: string;
  askPrice: number;
  askSize: number;
  askId: string;
  lastPrice: number;
  lastSize: number;
  lastId: string;
  openPrice: number;
  highPrice: number;
  lowPrice: number;
  closePrice: number;
  volume: number;
  quoteTime: number;
  tradeTime: number;
  mark: number;
  exchange: string;
  marginable: boolean;
  shortable: boolean;
  volatility: number;
  delta: number;
  gamma: number;
  theta: number;
  vega: number;
  rho: number;
  divAmount: number;
  divYield: number;
  divDate: string;
  regularMarketLastPrice: number;
  regularMarketLastSize: number;
  regularMarketNetChange: number;
  regularMarketTradeTime: number;
  netChange: number;
  netPercentChange: number;
  securityStatus: string;
  mark52WeekHigh: number;
  mark52WeekLow: number;
  peRatio: number;
  earningsPerShare: number;
  marketCap: number;
}

/**
 * Authenticates with Schwab API using OAuth2
 * @param authCode Authorization code obtained from OAuth flow
 * @returns Authentication response with tokens
 */
export async function authenticateWithSchwab(authCode: string): Promise<SchwabAuthResponse> {
  try {
    const response = await axios.post(endpoints.token, 
      new URLSearchParams({
        grant_type: 'authorization_code',
        code: authCode,
        client_id: SCHWAB_CLIENT_ID,
        client_secret: SCHWAB_CLIENT_SECRET,
        redirect_uri: SCHWAB_REDIRECT_URI
      }), 
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      }
    );

    console.log('Schwab authentication response:', response.status);
    
    if (!response.data || !response.data.access_token) {
      throw new Error('Invalid response from Schwab API');
    }

    // Log successful authentication
    await storage.createSystemLog({
      type: 'success',
      component: 'broker',
      message: 'Successfully authenticated with Schwab API'
    });

    return response.data as SchwabAuthResponse;
  } catch (error: any) {
    console.error('Schwab authentication error:', error.response?.data || error.message);
    
    // Log error
    await storage.createSystemLog({
      type: 'error',
      component: 'broker',
      message: `Schwab authentication error: ${error.response?.data?.error_description || error.message}`
    });
    
    throw new Error(error.response?.data?.error_description || 'Failed to authenticate with Schwab');
  }
}

/**
 * Refreshes an access token using the refresh token
 * @param refreshToken The refresh token to use
 * @returns New authentication response with tokens
 */
export async function refreshSchwabToken(refreshToken: string): Promise<SchwabAuthResponse> {
  try {
    const response = await axios.post(endpoints.token, 
      new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: refreshToken,
        client_id: SCHWAB_CLIENT_ID,
        client_secret: SCHWAB_CLIENT_SECRET
      }), 
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      }
    );

    if (!response.data || !response.data.access_token) {
      throw new Error('Invalid response from Schwab API during token refresh');
    }

    return response.data as SchwabAuthResponse;
  } catch (error: any) {
    console.error('Schwab token refresh error:', error.response?.data || error.message);
    throw new Error(error.response?.data?.error_description || 'Failed to refresh Schwab token');
  }
}

/**
 * Creates standard authorization headers for Schwab API requests
 * @param accessToken OAuth access token
 * @returns Headers object for API requests
 */
function createSchwabAuthHeaders(accessToken: string) {
  return {
    'Authorization': `Bearer ${accessToken}`,
    'Accept': 'application/json',
    'Content-Type': 'application/json'
  };
}

/**
 * Fetches accounts for the authenticated user
 * @param accessToken OAuth access token
 * @returns List of user accounts
 */
export async function fetchSchwabAccounts(accessToken: string): Promise<SchwabAccount[]> {
  try {
    const response = await axios.get(endpoints.accounts, {
      headers: createSchwabAuthHeaders(accessToken),
    });

    console.log('Schwab accounts response:', response.status);

    if (!response.data || !Array.isArray(response.data.accounts)) {
      throw new Error('Invalid accounts response from Schwab API');
    }

    return response.data.accounts as SchwabAccount[];
  } catch (error: any) {
    console.error('Schwab accounts fetch error:', error.response?.data || error.message);
    throw new Error(error.response?.data?.error || 'Failed to fetch Schwab accounts');
  }
}

/**
 * Fetches detailed information for a specific account
 * @param accessToken OAuth access token
 * @param accountId Account ID to fetch details for
 * @returns Detailed account information
 */
export async function fetchSchwabAccountDetails(accessToken: string, accountId: string) {
  try {
    const response = await axios.get(endpoints.accountDetails(accountId), {
      headers: createSchwabAuthHeaders(accessToken),
    });

    if (!response.data) {
      throw new Error('Invalid account details response from Schwab API');
    }

    return response.data;
  } catch (error: any) {
    console.error('Schwab account details fetch error:', error.response?.data || error.message);
    throw new Error(error.response?.data?.error || 'Failed to fetch Schwab account details');
  }
}

/**
 * Fetches account balances for a specific account
 * @param accessToken OAuth access token
 * @param accountId Account ID to fetch balances for
 * @returns Account balance information
 */
export async function fetchSchwabAccountBalances(accessToken: string, accountId: string): Promise<SchwabAccountBalance> {
  try {
    const response = await axios.get(endpoints.accountBalances(accountId), {
      headers: createSchwabAuthHeaders(accessToken),
    });

    if (!response.data) {
      throw new Error('Invalid account balances response from Schwab API');
    }

    return response.data as SchwabAccountBalance;
  } catch (error: any) {
    console.error('Schwab account balances fetch error:', error.response?.data || error.message);
    throw new Error(error.response?.data?.error || 'Failed to fetch Schwab account balances');
  }
}

/**
 * Fetches positions for a specific account
 * @param accessToken OAuth access token
 * @param accountId Account ID to fetch positions for
 * @returns List of positions for the account
 */
export async function fetchSchwabPositions(accessToken: string, accountId: string): Promise<SchwabPosition[]> {
  try {
    const response = await axios.get(endpoints.accountPositions(accountId), {
      headers: createSchwabAuthHeaders(accessToken),
    });

    if (!response.data || !Array.isArray(response.data.positions)) {
      throw new Error('Invalid positions response from Schwab API');
    }

    return response.data.positions as SchwabPosition[];
  } catch (error: any) {
    console.error('Schwab positions fetch error:', error.response?.data || error.message);
    throw new Error(error.response?.data?.error || 'Failed to fetch Schwab positions');
  }
}

/**
 * Fetches quotes for multiple symbols
 * @param accessToken OAuth access token
 * @param symbols Array of symbol strings to get quotes for
 * @returns Quotes for the requested symbols
 */
export async function fetchSchwabQuotes(accessToken: string, symbols: string[]): Promise<SchwabQuote[]> {
  try {
    const response = await axios.get(endpoints.quotes, {
      headers: createSchwabAuthHeaders(accessToken),
      params: {
        symbols: symbols.join(',')
      }
    });

    if (!response.data || !Array.isArray(response.data.quotes)) {
      throw new Error('Invalid quotes response from Schwab API');
    }

    return response.data.quotes as SchwabQuote[];
  } catch (error: any) {
    console.error('Schwab quotes fetch error:', error.response?.data || error.message);
    throw new Error(error.response?.data?.error || 'Failed to fetch Schwab quotes');
  }
}

/**
 * Searches for trading instruments (stocks, ETFs, etc.)
 * @param accessToken OAuth access token
 * @param query Search query string
 * @returns Search results
 */
export async function searchSchwabInstruments(accessToken: string, query: string) {
  try {
    const response = await axios.get(endpoints.searchInstruments, {
      headers: createSchwabAuthHeaders(accessToken),
      params: {
        symbol: query,
        projection: 'symbol-search'
      }
    });

    if (!response.data || !Array.isArray(response.data.instruments)) {
      throw new Error('Invalid instrument search response from Schwab API');
    }

    return response.data.instruments;
  } catch (error: any) {
    console.error('Schwab instrument search error:', error.response?.data || error.message);
    throw new Error(error.response?.data?.error || 'Failed to search Schwab instruments');
  }
}

/**
 * Fetches option chain data for a symbol
 * @param accessToken OAuth access token
 * @param symbol Underlying stock symbol
 * @returns Option chain data
 */
export async function fetchSchwabOptionChain(accessToken: string, symbol: string): Promise<SchwabOptionChain> {
  try {
    const response = await axios.get(endpoints.optionChains, {
      headers: createSchwabAuthHeaders(accessToken),
      params: {
        symbol: symbol,
        includeQuotes: true
      }
    });

    if (!response.data) {
      throw new Error('Invalid option chain response from Schwab API');
    }

    return response.data as SchwabOptionChain;
  } catch (error: any) {
    console.error('Schwab option chain fetch error:', error.response?.data || error.message);
    throw new Error(error.response?.data?.error || 'Failed to fetch Schwab option chain');
  }
}

/**
 * Places a new order
 * @param accessToken OAuth access token
 * @param order Order details
 * @returns Order confirmation
 */
export async function placeSchwabOrder(accessToken: string, order: SchwabOrder) {
  try {
    // Log order placement attempt
    await storage.createSystemLog({
      type: 'info',
      component: 'broker',
      message: `Attempting to place ${order.orderType} order for ${order.quantity} ${order.symbol} in account ${order.accountId}`
    });

    const response = await axios.post(
      endpoints.placeOrder(order.accountId),
      order,
      {
        headers: createSchwabAuthHeaders(accessToken),
      }
    );

    // Log successful order placement
    await storage.createSystemLog({
      type: 'success',
      component: 'broker',
      message: `Successfully placed ${order.orderType} order for ${order.quantity} ${order.symbol} in account ${order.accountId}`
    });

    return response.data;
  } catch (error: any) {
    // Log order error
    await storage.createSystemLog({
      type: 'error',
      component: 'broker',
      message: `Failed to place ${order.orderType} order for ${order.quantity} ${order.symbol}: ${error.response?.data?.error || error.message}`
    });
    
    console.error('Schwab order placement error:', error.response?.data || error.message);
    throw new Error(error.response?.data?.error || 'Failed to place Schwab order');
  }
}

/**
 * Cancels an existing order
 * @param accessToken OAuth access token
 * @param accountId Account ID the order belongs to
 * @param orderId Order ID to cancel
 * @returns Cancellation confirmation
 */
export async function cancelSchwabOrder(accessToken: string, accountId: string, orderId: string) {
  try {
    // Log cancellation attempt
    await storage.createSystemLog({
      type: 'info',
      component: 'broker',
      message: `Attempting to cancel order ${orderId} in account ${accountId}`
    });

    const response = await axios.delete(
      endpoints.cancelOrder(accountId, orderId),
      {
        headers: createSchwabAuthHeaders(accessToken),
      }
    );

    // Log successful cancellation
    await storage.createSystemLog({
      type: 'success',
      component: 'broker',
      message: `Successfully cancelled order ${orderId} in account ${accountId}`
    });

    return response.data;
  } catch (error: any) {
    // Log cancellation error
    await storage.createSystemLog({
      type: 'error',
      component: 'broker',
      message: `Failed to cancel order ${orderId}: ${error.response?.data?.error || error.message}`
    });
    
    console.error('Schwab order cancellation error:', error.response?.data || error.message);
    throw new Error(error.response?.data?.error || 'Failed to cancel Schwab order');
  }
}

/**
 * Gets the status of an existing order
 * @param accessToken OAuth access token
 * @param accountId Account ID the order belongs to
 * @param orderId Order ID to check
 * @returns Order status details
 */
export async function getSchwabOrderStatus(accessToken: string, accountId: string, orderId: string) {
  try {
    const response = await axios.get(
      endpoints.orderStatus(accountId, orderId),
      {
        headers: createSchwabAuthHeaders(accessToken),
      }
    );

    if (!response.data) {
      throw new Error('Invalid order status response from Schwab API');
    }

    return response.data;
  } catch (error: any) {
    console.error('Schwab order status fetch error:', error.response?.data || error.message);
    throw new Error(error.response?.data?.error || 'Failed to fetch Schwab order status');
  }
}

/**
 * Modifies an existing order
 * @param accessToken OAuth access token
 * @param accountId Account ID the order belongs to
 * @param orderId Order ID to modify
 * @param updatedOrder Updated order details
 * @returns Updated order confirmation
 */
export async function modifySchwabOrder(accessToken: string, accountId: string, orderId: string, updatedOrder: Partial<SchwabOrder>) {
  try {
    // Log modification attempt
    await storage.createSystemLog({
      type: 'info',
      component: 'broker',
      message: `Attempting to modify order ${orderId} in account ${accountId}`
    });

    const response = await axios.put(
      endpoints.modifyOrder(accountId, orderId),
      updatedOrder,
      {
        headers: createSchwabAuthHeaders(accessToken),
      }
    );

    // Log successful modification
    await storage.createSystemLog({
      type: 'success',
      component: 'broker',
      message: `Successfully modified order ${orderId} in account ${accountId}`
    });

    return response.data;
  } catch (error: any) {
    // Log modification error
    await storage.createSystemLog({
      type: 'error',
      component: 'broker',
      message: `Failed to modify order ${orderId}: ${error.response?.data?.error || error.message}`
    });
    
    console.error('Schwab order modification error:', error.response?.data || error.message);
    throw new Error(error.response?.data?.error || 'Failed to modify Schwab order');
  }
}

/**
 * Creates the OAuth authorization URL for Schwab
 * @param state Optional state parameter for OAuth flow
 * @returns OAuth authorization URL
 */
export function createSchwabAuthUrl(state: string = ''): string {
  const authUrl = new URL(`${SCHWAB_API_BASE_URL}/oauth/authorize`);
  authUrl.searchParams.append('response_type', 'code');
  authUrl.searchParams.append('client_id', SCHWAB_CLIENT_ID);
  authUrl.searchParams.append('redirect_uri', SCHWAB_REDIRECT_URI);
  // Include all necessary scopes for trading and account access
  authUrl.searchParams.append('scope', 'accounts trading marketdata'); 
  
  if (state) {
    authUrl.searchParams.append('state', state);
  }
  
  return authUrl.toString();
}

/**
 * Initiates OAuth connection to Schwab
 * @returns Authorization URL and state for OAuth flow
 */
export async function initiateSchwabOAuth() {
  // Generate a random state for security
  const state = Math.random().toString(36).substring(2, 15);
  
  // Log connection attempt
  await storage.createSystemLog({
    type: 'info',
    component: 'broker',
    message: 'Initiating Schwab OAuth connection'
  });
  
  // Create the authorization URL
  const authUrl = createSchwabAuthUrl(state);
  
  return { authUrl, state };
}

/**
 * Connects to Schwab API with OAuth credentials and returns accounts
 * @param authCode Authorization code from OAuth redirect
 * @returns Account information and tokens
 */
export async function connectToSchwab(authCode: string) {
  try {
    // Log connection attempt
    await storage.createSystemLog({
      type: 'info',
      component: 'broker',
      message: 'Attempting to connect to Schwab API with authorization code'
    });
    
    // Authenticate with Schwab
    const authResponse = await authenticateWithSchwab(authCode);
    
    if (!authResponse.access_token) {
      throw new Error('Failed to obtain access token from Schwab');
    }
    
    // Fetch accounts
    const accounts = await fetchSchwabAccounts(authResponse.access_token);
    
    if (!accounts || accounts.length === 0) {
      throw new Error('No accounts found for this Schwab user');
    }
    
    // Log success
    await storage.createSystemLog({
      type: 'success',
      component: 'broker',
      message: `Successfully connected to Schwab API. Found ${accounts.length} accounts.`
    });
    
    // For each account, try to fetch balance information
    const accountsWithBalance = await Promise.all(
      accounts.map(async (account) => {
        try {
          // Fetch account balances
          const balances = await fetchSchwabAccountBalances(authResponse.access_token, account.accountId);
          
          return {
            accountId: account.accountId,
            accountName: account.accountName,
            accountType: account.accountType,
            status: account.status,
            // Add balance information
            balance: balances.cashBalance,
            buyingPower: balances.buyingPower,
            // PDT status based on day trader flag
            pdtStatus: account.isDayTrader ? "Pattern Day Trader" : "No PDT Restrictions"
          };
        } catch (error) {
          console.error(`Failed to fetch balances for account ${account.accountId}:`, error);
          // Return account without balance information if we couldn't fetch it
          return {
            accountId: account.accountId,
            accountName: account.accountName,
            accountType: account.accountType,
            status: account.status,
            // Default values
            balance: 0,
            buyingPower: 0,
            pdtStatus: "Unknown"
          };
        }
      })
    );
    
    // Return account information and tokens
    return {
      accounts: accountsWithBalance,
      accessToken: authResponse.access_token,
      refreshToken: authResponse.refresh_token,
      expiresIn: authResponse.expires_in
    };
  } catch (error: any) {
    // Log error
    await storage.createSystemLog({
      type: 'error',
      component: 'broker',
      message: `Schwab connection error: ${error.message}`
    });
    
    throw error;
  }
}