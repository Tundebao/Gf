import { pgTable, text, serial, integer, boolean, json, timestamp, foreignKey, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  isAdmin: true,
});

// Brokers table
export const brokers = pgTable("brokers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type", { enum: ["schwab", "tastytrade"] }).notNull(),
  accountId: text("account_id").notNull(),
  accountType: text("account_type"),
  role: text("role", { enum: ["leader", "follower"] }).notNull(),
  connected: boolean("connected").default(false).notNull(),
  status: text("status").default("inactive").notNull(),
  connectionData: json("connection_data").$type<{
    // Properties for Schwab broker
    accessToken?: string;
    refreshToken?: string;
    expiresIn?: number;
    // Properties for Tastytrade broker
    sessionToken?: string;
    userId?: string;
    // Common properties
    accounts?: any[];
  }>(),
  balance: integer("balance"),
  equity: integer("equity"),
  margin: integer("margin"),
  buyingPower: integer("buying_power"),
  pdtStatus: text("pdt_status"),
  connectedAt: timestamp("connected_at"),
  lastConnected: timestamp("last_connected"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertBrokerSchema = createInsertSchema(brokers).pick({
  name: true,
  type: true,
  accountId: true,
  accountType: true,
  role: true,
  status: true,
  connectionData: true,
  balance: true,
  buyingPower: true,
  pdtStatus: true,
});

// Trading symbols table
export const symbols = pgTable("symbols", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull().unique(),
  allowTrading: boolean("allow_trading").default(true).notNull(),
  maxPositionSize: integer("max_position_size"),
  maxPositionValue: integer("max_position_value"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertSymbolSchema = createInsertSchema(symbols).pick({
  symbol: true,
  allowTrading: true,
  maxPositionSize: true,
  maxPositionValue: true,
  notes: true,
});

// Option strategies table
export const optionStrategies = pgTable("option_strategies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  symbol: text("symbol").notNull(),
  strategy: text("strategy").notNull(),
  legs: json("legs").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertOptionStrategySchema = createInsertSchema(optionStrategies).pick({
  name: true,
  symbol: true,
  strategy: true,
  legs: true,
  notes: true,
});

// Orders table
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  brokerId: integer("broker_id").notNull().references(() => brokers.id),
  symbol: text("symbol").notNull(),
  action: text("action").notNull(),
  orderType: text("order_type").notNull(),
  quantity: integer("quantity").notNull(),
  price: integer("price"),
  status: text("status").notNull(),
  timeInForce: text("time_in_force").notNull(),
  brokerOrderId: text("broker_order_id"),
  parentOrderId: integer("parent_order_id").references(() => orders.id),
  isCopyTrade: boolean("is_copy_trade").default(false).notNull(),
  instrumentType: text("instrument_type").notNull(),
  filledQuantity: integer("filled_quantity").default(0),
  filledPrice: integer("filled_price"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  brokerOrderId: true,
  filledQuantity: true,
  filledPrice: true,
  createdAt: true,
  updatedAt: true,
});

// Positions table
export const positions = pgTable("positions", {
  id: serial("id").primaryKey(),
  brokerId: integer("broker_id").notNull().references(() => brokers.id),
  symbol: text("symbol").notNull(),
  type: text("type", { enum: ["stock", "option"] }).notNull(),
  quantity: integer("quantity").notNull(),
  averageCost: integer("average_cost").notNull(),
  currentPrice: integer("current_price"),
  marketValue: integer("market_value"),
  unrealizedPnl: integer("unrealized_pnl"),
  unrealizedPnlPercent: integer("unrealized_pnl_percent"),
  openDate: timestamp("open_date").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertPositionSchema = createInsertSchema(positions).omit({
  id: true,
  updatedAt: true,
});

// Risk settings table
export const riskSettings = pgTable("risk_settings", {
  id: serial("id").primaryKey(),
  brokerId: integer("broker_id").references(() => brokers.id),
  maxDailyLoss: integer("max_daily_loss").notNull(),
  maxPositionSize: integer("max_position_size").notNull(),
  maxPositionValue: integer("max_position_value").notNull(),
  maxOrderValue: integer("max_order_value").default(0).notNull(),
  maxPositionPercent: integer("max_position_percent").default(25).notNull(),
  maxLeverage: integer("max_leverage").notNull(),
  enforceStopLoss: boolean("enforce_stop_loss").default(false).notNull(),
  stopLossPercentage: integer("stop_loss_percentage"),
  restrictedSymbols: text("restricted_symbols").array().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertRiskSettingsSchema = createInsertSchema(riskSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Risk events table
export const riskEvents = pgTable("risk_events", {
  id: serial("id").primaryKey(),
  type: text("type", { 
    enum: [
      "position_size_exceeded", 
      "position_value_exceeded", 
      "position_percent_exceeded", 
      "restricted_symbol",
      "max_daily_loss_exceeded",
      "max_leverage_exceeded"
    ]
  }).notNull(),
  eventType: text("event_type").notNull(), // For backward compatibility
  brokerId: integer("broker_id").references(() => brokers.id),
  symbol: text("symbol"),
  description: text("description").notNull(),
  active: boolean("active").default(true).notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  resolvedAt: timestamp("resolved_at"),
});

export const insertRiskEventSchema = createInsertSchema(riskEvents).omit({
  id: true,
  resolvedAt: true,
});

// Copy trading settings table
export const copyTradingSettings = pgTable("copy_trading_settings", {
  id: serial("id").primaryKey(),
  enabled: boolean("enabled").default(false).notNull(),
  isRunning: boolean("is_running").default(false).notNull(),
  copyMode: text("copy_mode", { enum: ["all", "whitelist", "blacklist"] }).default("all").notNull(),
  symbolWhitelist: text("symbol_whitelist").array().default([]),
  symbolBlacklist: text("symbol_blacklist").array().default([]),
  positionSizeType: text("position_size_type", { enum: ["fixed", "percentage", "proportional"] }).default("percentage").notNull(),
  positionSizeValue: integer("position_size_value").default(100).notNull(),
  maxPositionSize: integer("max_position_size").default(0).notNull(),
  mode: text("mode", { enum: ["exact", "fixed", "percent"] }).default("exact").notNull(),
  delay: integer("delay").default(0).notNull(),
  delaySeconds: integer("delay_seconds").default(0).notNull(),
  handlePartialFills: boolean("handle_partial_fills").default(true).notNull(),
  riskCheckEnabled: boolean("risk_check_enabled").default(true).notNull(),
  notificationsEnabled: boolean("notifications_enabled").default(true).notNull(),
  forbidFollowerManualOrders: boolean("forbid_follower_manual_orders").default(false).notNull(),
  autoStart: boolean("auto_start").default(false).notNull(),
  startedAt: timestamp("started_at"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertCopyTradingSettingsSchema = createInsertSchema(copyTradingSettings).omit({
  id: true,
  startedAt: true,
  updatedAt: true,
});

// Copy trading logs table
export const copyTradingLogs = pgTable("copy_trading_logs", {
  id: serial("id").primaryKey(),
  leaderId: integer("leader_id").references(() => brokers.id),
  leaderOrderId: integer("leader_order_id").references(() => orders.id),
  followerOrderId: integer("follower_order_id").references(() => orders.id),
  symbol: text("symbol"),
  quantity: integer("quantity"),
  side: text("side"),
  status: text("status", { enum: ["completed", "processing", "error", "rejected", "filtered", "received", "skipped"] }).default("processing").notNull(),
  success: boolean("success").notNull(),
  message: text("message").notNull(),
  details: text("details"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertCopyTradingLogSchema = createInsertSchema(copyTradingLogs).omit({
  id: true,
});

// System logs table
export const systemLogs = pgTable("system_logs", {
  id: serial("id").primaryKey(),
  type: text("type", { enum: ["info", "warning", "error", "success"] }).notNull(),
  component: text("component").notNull(),
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertSystemLogSchema = createInsertSchema(systemLogs).omit({
  id: true,
});

// Notifications table
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type", { enum: ["info", "warning", "error", "success"] }).notNull(),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  read: true,
  createdAt: true,
});

// Notification settings table
export const notificationSettings = pgTable("notification_settings", {
  id: serial("id").primaryKey(),
  emailEnabled: boolean("email_enabled").default(false).notNull(),
  emailAddress: text("email_address"),
  smsEnabled: boolean("sms_enabled").default(false).notNull(),
  phoneNumber: text("phone_number"),
  slackEnabled: boolean("slack_enabled").default(false).notNull(),
  slackWebhook: text("slack_webhook"),
  notifyOnTradeExecuted: boolean("notify_on_trade_executed").default(true).notNull(),
  notifyOnOrderFilled: boolean("notify_on_order_filled").default(true).notNull(),
  notifyOnOrderCancelled: boolean("notify_on_order_cancelled").default(true).notNull(),
  notifyOnBrokerDisconnect: boolean("notify_on_broker_disconnect").default(true).notNull(),
  notifyOnRiskEvent: boolean("notify_on_risk_event").default(true).notNull(),
  notifyOnCopyTradeFailure: boolean("notify_on_copy_trade_failure").default(true).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertNotificationSettingsSchema = createInsertSchema(notificationSettings).omit({
  id: true,
  updatedAt: true,
});

// General settings table
export const generalSettings = pgTable("general_settings", {
  id: serial("id").primaryKey(),
  timezone: text("timezone").default("America/New_York").notNull(),
  dateFormat: text("date_format").default("MM/DD/YYYY").notNull(),
  timeFormat: text("time_format").default("12h").notNull(),
  copyTradeDelay: integer("copy_trade_delay").default(0).notNull(),
  defaultTradingHours: json("default_trading_hours").notNull(),
  autoRefresh: boolean("auto_refresh").default(true).notNull(),
  refreshInterval: integer("refresh_interval").default(30).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertGeneralSettingsSchema = createInsertSchema(generalSettings).omit({
  id: true,
  updatedAt: true,
});

// API settings table
export const apiSettings = pgTable("api_settings", {
  id: serial("id").primaryKey(),
  webhookEnabled: boolean("webhook_enabled").default(false).notNull(),
  webhookUrl: text("webhook_url"),
  webhookSecret: text("webhook_secret"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertApiSettingsSchema = createInsertSchema(apiSettings).omit({
  id: true,
  updatedAt: true,
});

// Sessions table
export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  token: text("token").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  createdAt: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Broker = typeof brokers.$inferSelect;
export type InsertBroker = z.infer<typeof insertBrokerSchema>;

export type Symbol = typeof symbols.$inferSelect;
export type InsertSymbol = z.infer<typeof insertSymbolSchema>;

export type OptionStrategy = typeof optionStrategies.$inferSelect;
export type InsertOptionStrategy = z.infer<typeof insertOptionStrategySchema>;

export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

export type Position = typeof positions.$inferSelect;
export type InsertPosition = z.infer<typeof insertPositionSchema>;

export type RiskSetting = typeof riskSettings.$inferSelect;
export type InsertRiskSetting = z.infer<typeof insertRiskSettingsSchema>;

export type RiskEvent = typeof riskEvents.$inferSelect;
export type InsertRiskEvent = z.infer<typeof insertRiskEventSchema>;

export type CopyTradingSetting = typeof copyTradingSettings.$inferSelect;
export type InsertCopyTradingSetting = z.infer<typeof insertCopyTradingSettingsSchema>;

export type CopyTradingLog = typeof copyTradingLogs.$inferSelect;
export type InsertCopyTradingLog = z.infer<typeof insertCopyTradingLogSchema>;

export type SystemLog = typeof systemLogs.$inferSelect;
export type InsertSystemLog = z.infer<typeof insertSystemLogSchema>;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

export type NotificationSetting = typeof notificationSettings.$inferSelect;
export type InsertNotificationSetting = z.infer<typeof insertNotificationSettingsSchema>;

export type GeneralSetting = typeof generalSettings.$inferSelect;
export type InsertGeneralSetting = z.infer<typeof insertGeneralSettingsSchema>;

export type ApiSetting = typeof apiSettings.$inferSelect;
export type InsertApiSetting = z.infer<typeof insertApiSettingsSchema>;

export type Session = typeof sessions.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;
