// cPanel-specific entry point
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');

// This ensures TypeScript is compiled on the server
exec('npx tsx server/index.ts', {
  cwd: __dirname,
  env: {
    ...process.env,
    NODE_ENV: 'production',
    PORT: process.env.PORT || 5000,
    DATABASE_URL: process.env.DATABASE_URL,
    JWT_SECRET: process.env.JWT_SECRET,
    SCHWAB_API_URL: process.env.SCHWAB_API_URL,
    SCHWAB_CLIENT_ID: process.env.SCHWAB_CLIENT_ID,
    SCHWAB_CLIENT_SECRET: process.env.SCHWAB_CLIENT_SECRET,
    SCHWAB_API_BASE_URL: process.env.SCHWAB_API_BASE_URL,
    SCHWAB_API_KEY: process.env.SCHWAB_API_KEY,
    SCHWAB_API_SECRET: process.env.SCHWAB_API_SECRET,
    SCHWAB_REDIRECT_URI: process.env.SCHWAB_REDIRECT_URI
  }
}, (error, stdout, stderr) => {
  if (error) {
    console.error();
    return;
  }
  console.log(stdout);
  console.error(stderr);
});
