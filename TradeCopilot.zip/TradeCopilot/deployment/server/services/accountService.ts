import { storage } from '../storage';
import { schwabService } from './schwabService';
import { Account, InsertAccount } from '@shared/schema';
import { log } from '../vite';
import { eq } from 'drizzle-orm';
import { db } from '../db';
import { tradeAccounts } from '@shared/schema';

export class AccountService {
  // Get account details from Schwab and update our database
  async syncAccountDetails(accountId: number): Promise<Account | undefined> {
    try {
      const account = await storage.getAccount(accountId);
      if (!account) {
        log(`Account ${accountId} not found`, "account-service-error");
        return undefined;
      }
      
      // Get account details from Schwab API
      const accountDetails = await schwabService.getAccountDetails(account.accountId);
      
      // Update our database with the latest info
      const updatedAccount = await storage.updateAccount(accountId, {
        balance: accountDetails.balance,
        marginAvailable: accountDetails.marginAvailable || 0,
        pdtStatus: accountDetails.pdtStatus || false,
        status: accountDetails.status === 'active' ? 'connected' : 'disconnected'
      });
      
      log(`Account ${accountId} synced successfully`, "account-service");
      return updatedAccount;
    } catch (error: any) {
      // If there's an auth error, mark the account as auth_failed
      if (error.message.includes('authentication') || error.message.includes('unauthorized')) {
        await storage.updateAccount(accountId, { status: 'auth_failed' });
        log(`Authentication failed for account ${accountId}`, "account-service-error");
      } else {
        log(`Error syncing account ${accountId}: ${error.message}`, "account-service-error");
      }
      throw new Error(`Failed to sync account: ${error.message}`);
    }
  }
  
  // Connect a new account
  async connectAccount(accountData: InsertAccount): Promise<Account> {
    try {
      // First verify we can connect to this account via Schwab API
      const accountDetails = await schwabService.getAccountDetails(accountData.accountId);
      
      // Create the account in our database
      const account = await storage.createAccount({
        ...accountData,
        balance: accountDetails.balance,
        status: 'connected'
      });
      
      log(`Account ${account.accountName} connected successfully`, "account-service");
      return account;
    } catch (error: any) {
      log(`Error connecting account: ${error.message}`, "account-service-error");
      throw new Error(`Failed to connect account: ${error.message}`);
    }
  }
  
  // Sync all accounts
  async syncAllAccounts(): Promise<void> {
    try {
      const accounts = await storage.getAccounts();
      
      for (const account of accounts) {
        try {
          await this.syncAccountDetails(account.id);
        } catch (error: any) {
          log(`Error syncing account ${account.id}: ${error.message}`, "account-service-error");
          // Continue syncing other accounts even if one fails
        }
      }
      
      log(`Synced ${accounts.length} accounts`, "account-service");
    } catch (error: any) {
      log(`Error syncing accounts: ${error.message}`, "account-service-error");
      throw new Error(`Failed to sync accounts: ${error.message}`);
    }
  }
  
  // Pause trading for an account
  async pauseAccount(accountId: number): Promise<Account | undefined> {
    try {
      const updatedAccount = await storage.updateAccount(accountId, {
        status: 'paused'
      });
      
      log(`Account ${accountId} paused successfully`, "account-service");
      return updatedAccount;
    } catch (error: any) {
      log(`Error pausing account ${accountId}: ${error.message}`, "account-service-error");
      throw new Error(`Failed to pause account: ${error.message}`);
    }
  }
  
  // Resume trading for an account
  async resumeAccount(accountId: number): Promise<Account | undefined> {
    try {
      // First verify we can still connect to this account
      const account = await storage.getAccount(accountId);
      if (!account) {
        log(`Account ${accountId} not found`, "account-service-error");
        return undefined;
      }
      
      await schwabService.getAccountDetails(account.accountId);
      
      // Resume the account
      const updatedAccount = await storage.updateAccount(accountId, {
        status: 'connected'
      });
      
      log(`Account ${accountId} resumed successfully`, "account-service");
      return updatedAccount;
    } catch (error: any) {
      log(`Error resuming account ${accountId}: ${error.message}`, "account-service-error");
      throw new Error(`Failed to resume account: ${error.message}`);
    }
  }
  
  // Calculate account statistics and metrics
  async updateAccountMetrics(accountId: number): Promise<Account | undefined> {
    try {
      const account = await storage.getAccount(accountId);
      if (!account) {
        log(`Account ${accountId} not found`, "account-service-error");
        return undefined;
      }
      
      // Get all active trades for this account
      const accountTrades = await db.query.tradeAccounts.findMany({
        where: eq(tradeAccounts.accountId, accountId),
        with: {
          trade: true
        }
      });
      
      // Calculate the total P&L for the month
      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      
      let monthlyProfitLoss = 0;
      
      for (const accountTrade of accountTrades) {
        if (accountTrade.trade.createdAt >= firstDayOfMonth) {
          monthlyProfitLoss += accountTrade.trade.profitLoss || 0;
        }
      }
      
      // Calculate P&L as percentage of account balance
      const monthlyProfitLossPercentage = account.balance > 0 
        ? (monthlyProfitLoss / account.balance) * 100 
        : 0;
      
      // Update the account
      const updatedAccount = await storage.updateAccount(accountId, {
        monthlyProfitLoss,
        monthlyProfitLossPercentage,
        activeTrades: accountTrades.filter(at => at.trade.status === 'active').length
      });
      
      return updatedAccount;
    } catch (error: any) {
      log(`Error updating metrics for account ${accountId}: ${error.message}`, "account-service-error");
      throw new Error(`Failed to update account metrics: ${error.message}`);
    }
  }

  // Update account risk management settings
  async updateRiskManagement(accountId: number, riskSettings: Partial<Account>): Promise<Account | undefined> {
    try {
      const account = await storage.getAccount(accountId);
      if (!account) {
        log(`Account ${accountId} not found`, "account-service-error");
        return undefined;
      }
      
      // Update risk management settings
      const updatedAccount = await storage.updateAccount(accountId, {
        maxTradeSize: riskSettings.maxTradeSize,
        maxDailyDrawdown: riskSettings.maxDailyDrawdown,
        tradingStartTime: riskSettings.tradingStartTime,
        tradingEndTime: riskSettings.tradingEndTime,
        blockedSymbols: riskSettings.blockedSymbols,
        emergencyKillSwitch: riskSettings.emergencyKillSwitch
      });
      
      log(`Risk management settings updated for account ${accountId}`, "account-service");
      return updatedAccount;
    } catch (error: any) {
      log(`Error updating risk management for account ${accountId}: ${error.message}`, "account-service-error");
      throw new Error(`Failed to update risk management settings: ${error.message}`);
    }
  }
  
  // Update copy trading settings
  async updateCopySettings(accountId: number, copySettings: Partial<Account>): Promise<Account | undefined> {
    try {
      const account = await storage.getAccount(accountId);
      if (!account) {
        log(`Account ${accountId} not found`, "account-service-error");
        return undefined;
      }
      
      // Update copy trading settings
      const updatedAccount = await storage.updateAccount(accountId, {
        copyMode: copySettings.copyMode,
        copyAllocation: copySettings.copyAllocation
      });
      
      log(`Copy trading settings updated for account ${accountId}`, "account-service");
      return updatedAccount;
    } catch (error: any) {
      log(`Error updating copy settings for account ${accountId}: ${error.message}`, "account-service-error");
      throw new Error(`Failed to update copy trading settings: ${error.message}`);
    }
  }
  
  // Toggle emergency kill switch
  async toggleKillSwitch(accountId: number, enabled: boolean): Promise<Account | undefined> {
    try {
      const account = await storage.getAccount(accountId);
      if (!account) {
        log(`Account ${accountId} not found`, "account-service-error");
        return undefined;
      }
      
      // If enabling kill switch, also pause the account
      const status = enabled ? 'paused' : account.status;
      
      const updatedAccount = await storage.updateAccount(accountId, {
        emergencyKillSwitch: enabled,
        status
      });
      
      log(`Emergency kill switch ${enabled ? 'enabled' : 'disabled'} for account ${accountId}`, "account-service");
      return updatedAccount;
    } catch (error: any) {
      log(`Error toggling kill switch for account ${accountId}: ${error.message}`, "account-service-error");
      throw new Error(`Failed to toggle emergency kill switch: ${error.message}`);
    }
  }
  
  // Check if a trade is allowed based on risk management rules
  async validateTrade(accountId: number, symbol: string, quantity: number, estimatedCost: number): Promise<{isValid: boolean, reason?: string}> {
    try {
      const account = await storage.getAccount(accountId);
      if (!account) {
        return { isValid: false, reason: "Account not found" };
      }
      
      // Check if account is active
      if (account.status !== 'connected') {
        return { isValid: false, reason: `Account is ${account.status}` };
      }
      
      // Check emergency kill switch
      if (account.emergencyKillSwitch) {
        return { isValid: false, reason: "Emergency kill switch is active" };
      }
      
      // Check blocked symbols
      if (account.blockedSymbols && account.blockedSymbols.includes(symbol)) {
        return { isValid: false, reason: `Symbol ${symbol} is blocked for this account` };
      }
      
      // Check max trade size
      if (account.maxTradeSize && estimatedCost > account.maxTradeSize) {
        return { isValid: false, reason: `Trade cost exceeds max trade size (${estimatedCost} > ${account.maxTradeSize})` };
      }
      
      // Check daily drawdown limit
      if (account.dailyProfitLoss !== null && account.maxDailyDrawdown && account.dailyProfitLoss < -account.maxDailyDrawdown) {
        return { isValid: false, reason: `Daily drawdown limit exceeded (${account.dailyProfitLoss} < -${account.maxDailyDrawdown})` };
      }
      
      // Check trading hours
      const now = new Date();
      const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
      
      if (account.tradingStartTime && currentTime < account.tradingStartTime) {
        return { isValid: false, reason: `Outside of trading hours (starts at ${account.tradingStartTime})` };
      }
      
      if (account.tradingEndTime && currentTime > account.tradingEndTime) {
        return { isValid: false, reason: `Outside of trading hours (ends at ${account.tradingEndTime})` };
      }
      
      return { isValid: true };
    } catch (error: any) {
      log(`Error validating trade for account ${accountId}: ${error.message}`, "account-service-error");
      return { isValid: false, reason: `Validation error: ${error.message}` };
    }
  }
}

export const accountService = new AccountService();