import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { WebSocketServer, WebSocket } from "ws";
import { authenticate, requireAdmin, generateToken, AuthRequest } from "./middleware/auth";
import { tradeService } from "./services/tradeService";
import { accountService } from "./services/accountService";
import { schwabService } from "./services/schwabService";
import { loginSchema, insertTradeSchema, insertAccountSchema } from "@shared/schema";
import { z } from "zod";
import { log } from "./vite";
import oauthRoutes from "./routes/oauthRoutes";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server first
  const httpServer = createServer(app);
  
  // Create a WebSocket server (on a distinct path)
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Keep track of connected clients for broadcasting
  const clients = new Set<WebSocket>();
  
  // Handle WebSocket connections
  wss.on('connection', (ws) => {
    clients.add(ws);
    log('WebSocket client connected', 'ws');
    
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        log(`Received message: ${data.type}`, 'ws');
        
        // Handle different message types
        if (data.type === 'ping') {
          ws.send(JSON.stringify({ type: 'pong', timestamp: new Date().toISOString() }));
        } else if (data.type === 'subscribe') {
          // Handle subscription to different data types
          if (data.channel === 'trades') {
            sendActiveTrades(ws);
          } else if (data.channel === 'market') {
            sendMarketData(ws);
          } else if (data.channel === 'accounts') {
            sendAccountsData(ws);
          }
        }
      } catch (err) {
        log(`WebSocket error: ${err}`, 'ws-error');
      }
    });
    
    ws.on('close', () => {
      clients.delete(ws);
      log('WebSocket client disconnected', 'ws');
    });
    
    // Send initial data
    sendMarketData(ws);
    sendActiveTrades(ws);
  });
  
  // Broadcast function to send updates to all connected clients
  function broadcast(data: any) {
    const message = JSON.stringify(data);
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }
  
  // Send market data to a specific client
  async function sendMarketData(ws: WebSocket) {
    try {
      if (ws.readyState === WebSocket.OPEN) {
        const marketIndices = await schwabService.getMarketIndices();
        ws.send(JSON.stringify({
          type: 'marketUpdate',
          data: marketIndices
        }));
      }
    } catch (error: any) {
      log(`Failed to send market data: ${error.message}`, 'ws-error');
    }
  }
  
  // Send active trades to a specific client
  async function sendActiveTrades(ws: WebSocket) {
    try {
      if (ws.readyState === WebSocket.OPEN) {
        const activeTrades = await storage.getActiveTrades();
        ws.send(JSON.stringify({
          type: 'tradesUpdate',
          data: activeTrades
        }));
      }
    } catch (error: any) {
      log(`Failed to send active trades: ${error.message}`, 'ws-error');
    }
  }
  
  // Send accounts data to a specific client
  async function sendAccountsData(ws: WebSocket) {
    try {
      if (ws.readyState === WebSocket.OPEN) {
        const accounts = await storage.getAccounts();
        ws.send(JSON.stringify({
          type: 'accountsUpdate',
          data: accounts
        }));
      }
    } catch (error: any) {
      log(`Failed to send accounts data: ${error.message}`, 'ws-error');
    }
  }
  
  // Authentication routes
  const handleLogin = async (req: Request, res: Response) => {
    try {
      const validation = loginSchema.safeParse(req.body);
      if (!validation.success) {
        log(`Validation failed: ${JSON.stringify(validation.error)}`, 'auth-error');
        return res.status(400).json({ message: 'Invalid credentials format' });
      }
      
      const { username, password } = validation.data;
      log(`Login attempt for user: ${username}`, 'auth-info');
      
      const user = await storage.verifyUserCredentials(username, password);
      
      if (!user) {
        log(`Invalid credentials for user: ${username}`, 'auth-error');
        return res.status(401).json({ message: 'Invalid username or password' });
      }
      
      if (!user.isAdmin) {
        log(`Non-admin access attempt: ${username}`, 'auth-error');
        return res.status(403).json({ message: 'Admin access required' });
      }
      
      const token = generateToken(user.id, user.isAdmin);
      
      log(`Login successful for user: ${username}`, 'auth-info');
      return res.status(200).json({
        message: 'Login successful',
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          isAdmin: user.isAdmin
        }
      });
    } catch (error: any) {
      log(`Login error: ${error.message}`, 'auth-error');
      return res.status(500).json({ message: 'Authentication failed' });
    }
  };
  
  // Support both routes for login
  app.post('/api/auth/login', handleLogin);
  app.post('/api/login', handleLogin);
  
  // Register OAuth routes
  app.use('/auth/schwab', oauthRoutes);
  
  // Protected routes (require authentication)
  // All routes below this middleware require authentication
  app.use('/api', authenticate);
  
  // Dashboard
  app.get('/api/dashboard', requireAdmin, async (req, res) => {
    try {
      const activeTrades = await storage.getActiveTrades();
      const accounts = await storage.getAccounts();
      const marketData = await storage.getMarketData();
      
      // Calculate stats
      const totalProfitLoss = activeTrades.reduce((sum, trade) => sum + (trade.profitLoss || 0), 0);
      const successRate = activeTrades.length > 0
        ? (activeTrades.filter(t => (t.profitLoss || 0) > 0).length / activeTrades.length) * 100
        : 0;
      
      // Get market indices
      const marketIndices = await schwabService.getMarketIndices();
      
      return res.status(200).json({
        activeTrades: activeTrades.length,
        totalProfitLoss,
        connectedAccounts: accounts.filter(a => a.status === 'connected').length,
        successRate,
        marketIndices,
        recentTrades: activeTrades.slice(0, 5) // Get 5 most recent trades
      });
    } catch (error: any) {
      log(`Dashboard error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: 'Failed to load dashboard data' });
    }
  });
  
  // Trade History endpoints
  app.get('/api/trade-history', requireAdmin, async (req, res) => {
    try {
      // Parse filters from query parameters
      const filters: any = {};
      
      // Handle date filters
      if (req.query.startDate) {
        filters.startDate = new Date(req.query.startDate as string);
      }
      
      if (req.query.endDate) {
        filters.endDate = new Date(req.query.endDate as string);
      }
      
      // Handle other filters
      if (req.query.symbol) {
        filters.symbol = req.query.symbol as string;
      }
      
      if (req.query.status) {
        filters.status = req.query.status as string;
      }
      
      if (req.query.account) {
        filters.account = parseInt(req.query.account as string, 10);
      }
      
      const tradeHistory = await storage.getTradeHistory(filters);
      return res.status(200).json(tradeHistory);
    } catch (error: any) {
      log(`Get trade history error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: 'Failed to load trade history' });
    }
  });
  
  app.get('/api/trade-history/detailed', requireAdmin, async (req, res) => {
    try {
      // Parse filters from query parameters
      const filters: any = {};
      
      // Handle date filters
      if (req.query.startDate) {
        filters.startDate = new Date(req.query.startDate as string);
      }
      
      if (req.query.endDate) {
        filters.endDate = new Date(req.query.endDate as string);
      }
      
      // Handle other filters
      if (req.query.symbol) {
        filters.symbol = req.query.symbol as string;
      }
      
      if (req.query.status) {
        filters.status = req.query.status as string;
      }
      
      if (req.query.account) {
        filters.account = parseInt(req.query.account as string, 10);
      }
      
      const detailedTradeHistory = await storage.getTradeHistoryWithAccounts(filters);
      return res.status(200).json(detailedTradeHistory);
    } catch (error: any) {
      log(`Get detailed trade history error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: 'Failed to load detailed trade history' });
    }
  });
  
  // Export trade history as CSV
  app.get('/api/trade-history/export', requireAdmin, async (req, res) => {
    try {
      // Parse filters from query parameters
      const filters: any = {};
      
      // Handle date filters
      if (req.query.startDate) {
        filters.startDate = new Date(req.query.startDate as string);
      }
      
      if (req.query.endDate) {
        filters.endDate = new Date(req.query.endDate as string);
      }
      
      // Handle other filters
      if (req.query.symbol) {
        filters.symbol = req.query.symbol as string;
      }
      
      if (req.query.status) {
        filters.status = req.query.status as string;
      }
      
      if (req.query.account) {
        filters.account = parseInt(req.query.account as string, 10);
      }
      
      // Get trade history data
      const tradeHistory = await storage.getTradeHistory(filters);
      
      // Generate CSV header
      let csv = 'Symbol,Type,Entry Price,Exit Price,Quantity,P&L,P&L %,Status,Entry Date,Exit Date,Option\n';
      
      // Generate CSV rows
      for (const trade of tradeHistory) {
        const entryDate = new Date(trade.createdAt).toLocaleDateString();
        const exitDate = trade.closedAt ? new Date(trade.closedAt).toLocaleDateString() : '';
        const isOption = trade.isOption ? 
          `${trade.optionType?.toUpperCase()} ${trade.strikePrice} ${trade.expirationDate ? new Date(trade.expirationDate).toLocaleDateString() : ''}` : 
          'No';
        
        csv += `"${trade.symbol}",`;
        csv += `"${trade.type}",`;
        csv += `${trade.entryPrice},`;
        csv += `${trade.currentPrice || ''},`;
        csv += `${trade.quantity},`;
        csv += `${trade.profitLoss || 0},`;
        csv += `${trade.profitLossPercentage ? (trade.profitLossPercentage).toFixed(2) + '%' : '0%'},`;
        csv += `"${trade.status}",`;
        csv += `"${entryDate}",`;
        csv += `"${exitDate}",`;
        csv += `"${isOption}"\n`;
      }
      
      // Set response headers for CSV download
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=trade-history.csv');
      
      return res.status(200).send(csv);
    } catch (error: any) {
      log(`Export trade history error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: 'Failed to export trade history' });
    }
  });
  
  // All trades
  app.get('/api/trades', requireAdmin, async (req, res) => {
    try {
      const trades = await storage.getTrades();
      return res.status(200).json(trades);
    } catch (error: any) {
      log(`Get trades error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: 'Failed to load trades' });
    }
  });
  
  app.post('/api/trades', requireAdmin, async (req, res) => {
    try {
      // Validate the trade data
      const tradeValidation = insertTradeSchema.safeParse(req.body.trade);
      if (!tradeValidation.success) {
        return res.status(400).json({ message: 'Invalid trade data', errors: tradeValidation.error.errors });
      }
      
      // Validate account IDs
      const accountIdsSchema = z.array(z.number()).min(1, 'At least one account is required');
      const accountIdsValidation = accountIdsSchema.safeParse(req.body.accountIds);
      if (!accountIdsValidation.success) {
        return res.status(400).json({ message: 'Invalid account IDs', errors: accountIdsValidation.error.errors });
      }
      
      // Create the trade
      const trade = await tradeService.createTrade(tradeValidation.data, accountIdsValidation.data);
      
      // Broadcast trade creation to websocket clients
      broadcast({
        type: 'newTrade',
        data: trade
      });
      
      return res.status(201).json(trade);
    } catch (error: any) {
      log(`Create trade error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: `Failed to create trade: ${error.message}` });
    }
  });
  
  app.get('/api/trades/active', requireAdmin, async (req, res) => {
    try {
      const activeTrades = await storage.getActiveTrades();
      return res.status(200).json(activeTrades);
    } catch (error: any) {
      log(`Get active trades error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: 'Failed to load active trades' });
    }
  });
  
  app.put('/api/trades/:id', requireAdmin, async (req, res) => {
    try {
      const tradeId = Number(req.params.id);
      const updatedTrade = await storage.updateTrade(tradeId, req.body);
      
      if (!updatedTrade) {
        return res.status(404).json({ message: 'Trade not found' });
      }
      
      // Broadcast trade update to websocket clients
      broadcast({
        type: 'updateTrade',
        data: updatedTrade
      });
      
      return res.status(200).json(updatedTrade);
    } catch (error: any) {
      log(`Update trade error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: `Failed to update trade: ${error.message}` });
    }
  });
  
  app.delete('/api/trades/:id', requireAdmin, async (req, res) => {
    try {
      const tradeId = Number(req.params.id);
      const closedTrade = await tradeService.closeTrade(tradeId);
      
      if (!closedTrade) {
        return res.status(404).json({ message: 'Trade not found' });
      }
      
      // Broadcast trade closure to websocket clients
      broadcast({
        type: 'closeTrade',
        data: closedTrade
      });
      
      return res.status(200).json({ message: 'Trade closed successfully', trade: closedTrade });
    } catch (error: any) {
      log(`Close trade error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: `Failed to close trade: ${error.message}` });
    }
  });
  
  // Accounts
  app.get('/api/accounts', requireAdmin, async (req, res) => {
    try {
      const accounts = await storage.getAccounts();
      return res.status(200).json(accounts);
    } catch (error: any) {
      log(`Get accounts error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: 'Failed to load accounts' });
    }
  });
  
  app.post('/api/accounts', requireAdmin, async (req, res) => {
    try {
      // Validate the account data
      const validation = insertAccountSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: 'Invalid account data', errors: validation.error.errors });
      }
      
      // Connect the account
      const account = await accountService.connectAccount(validation.data);
      
      // Broadcast account creation to websocket clients
      broadcast({
        type: 'newAccount',
        data: account
      });
      
      return res.status(201).json(account);
    } catch (error: any) {
      log(`Create account error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: `Failed to create account: ${error.message}` });
    }
  });
  
  app.post('/api/accounts/:id/pause', requireAdmin, async (req, res) => {
    try {
      const accountId = Number(req.params.id);
      const account = await accountService.pauseAccount(accountId);
      
      if (!account) {
        return res.status(404).json({ message: 'Account not found' });
      }
      
      // Broadcast account update to websocket clients
      broadcast({
        type: 'updateAccount',
        data: account
      });
      
      return res.status(200).json(account);
    } catch (error: any) {
      log(`Pause account error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: `Failed to pause account: ${error.message}` });
    }
  });
  
  app.post('/api/accounts/:id/resume', requireAdmin, async (req, res) => {
    try {
      const accountId = Number(req.params.id);
      const account = await accountService.resumeAccount(accountId);
      
      if (!account) {
        return res.status(404).json({ message: 'Account not found' });
      }
      
      // Broadcast account update to websocket clients
      broadcast({
        type: 'updateAccount',
        data: account
      });
      
      return res.status(200).json(account);
    } catch (error: any) {
      log(`Resume account error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: `Failed to resume account: ${error.message}` });
    }
  });
  
  app.post('/api/accounts/:id/sync', requireAdmin, async (req, res) => {
    try {
      const accountId = Number(req.params.id);
      const account = await accountService.syncAccountDetails(accountId);
      
      if (!account) {
        return res.status(404).json({ message: 'Account not found' });
      }
      
      // Update metrics after syncing
      await accountService.updateAccountMetrics(accountId);
      
      // Broadcast account update to websocket clients
      broadcast({
        type: 'updateAccount',
        data: account
      });
      
      return res.status(200).json(account);
    } catch (error: any) {
      log(`Sync account error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: `Failed to sync account: ${error.message}` });
    }
  });

  // Update copy trading settings
  app.put('/api/accounts/:id/copy-settings', requireAdmin, async (req, res) => {
    try {
      const accountId = Number(req.params.id);
      
      // Validate the settings
      const { copyMode, copyAllocation } = req.body;
      
      const account = await accountService.updateCopySettings(accountId, {
        copyMode,
        copyAllocation
      });
      
      if (!account) {
        return res.status(404).json({ message: 'Account not found' });
      }
      
      // Broadcast account update to websocket clients
      broadcast({
        type: 'updateAccount',
        data: account
      });
      
      return res.status(200).json(account);
    } catch (error: any) {
      log(`Update copy settings error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: `Failed to update copy settings: ${error.message}` });
    }
  });
  
  // Update risk management settings
  app.put('/api/accounts/:id/risk-management', requireAdmin, async (req, res) => {
    try {
      const accountId = Number(req.params.id);
      
      // Extract risk management settings from request
      const {
        maxTradeSize,
        maxDailyDrawdown,
        tradingStartTime,
        tradingEndTime,
        blockedSymbols
      } = req.body;
      
      const account = await accountService.updateRiskManagement(accountId, {
        maxTradeSize,
        maxDailyDrawdown,
        tradingStartTime,
        tradingEndTime,
        blockedSymbols
      });
      
      if (!account) {
        return res.status(404).json({ message: 'Account not found' });
      }
      
      // Broadcast account update to websocket clients
      broadcast({
        type: 'updateAccount',
        data: account
      });
      
      return res.status(200).json(account);
    } catch (error: any) {
      log(`Update risk management error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: `Failed to update risk management settings: ${error.message}` });
    }
  });
  
  // Toggle emergency kill switch
  app.post('/api/accounts/:id/kill-switch', requireAdmin, async (req, res) => {
    try {
      const accountId = Number(req.params.id);
      const { enabled } = req.body;
      
      if (typeof enabled !== 'boolean') {
        return res.status(400).json({ message: 'Enabled status must be a boolean' });
      }
      
      const account = await accountService.toggleKillSwitch(accountId, enabled);
      
      if (!account) {
        return res.status(404).json({ message: 'Account not found' });
      }
      
      // Broadcast account update to websocket clients
      broadcast({
        type: 'updateAccount',
        data: account
      });
      
      return res.status(200).json(account);
    } catch (error: any) {
      log(`Toggle kill switch error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: `Failed to toggle emergency kill switch: ${error.message}` });
    }
  });

  // Delete account endpoint
  app.delete('/api/accounts/:id', requireAdmin, async (req, res) => {
    try {
      const accountId = Number(req.params.id);
      
      // Get the account before deleting it (for logging)
      const accountToDelete = await storage.getAccount(accountId);
      if (!accountToDelete) {
        return res.status(404).json({ message: 'Account not found' });
      }
      
      // Delete the account
      const success = await storage.deleteAccount(accountId);
      
      if (success) {
        log(`Account deleted: ${accountToDelete.accountName} (ID: ${accountId})`, 'account');
        
        // Broadcast deletion to websocket clients
        broadcast({
          type: 'deleteAccount',
          data: { id: accountId }
        });
        
        return res.status(200).json({ success: true, message: 'Account deleted successfully' });
      } else {
        return res.status(500).json({ success: false, message: 'Failed to delete account' });
      }
    } catch (error: any) {
      log(`Error deleting account: ${error.message}`, 'account-error');
      return res.status(500).json({ message: `Failed to delete account: ${error.message}` });
    }
  });
  
  // Market Data
  app.get('/api/market/quotes', requireAdmin, async (req, res) => {
    try {
      const symbols = req.query.symbols as string;
      if (!symbols) {
        return res.status(400).json({ message: 'Symbols parameter required' });
      }
      
      const symbolArray = symbols.split(',');
      const quotes = await schwabService.getQuotes(symbolArray);
      
      return res.status(200).json(quotes);
    } catch (error: any) {
      log(`Market quotes error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: `Failed to get market quotes: ${error.message}` });
    }
  });
  
  app.get('/api/market/indices', requireAdmin, async (req, res) => {
    try {
      const indices = await schwabService.getMarketIndices();
      return res.status(200).json(indices);
    } catch (error: any) {
      log(`Market indices error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: `Failed to get market indices: ${error.message}` });
    }
  });
  
  // Symbol search for stocks, ETFs, options
  app.get('/api/market/search', requireAdmin, async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query || query.length < 2) {
        return res.status(400).json({ message: 'Search query must be at least 2 characters' });
      }
      
      const results = await schwabService.searchSymbols(query);
      return res.status(200).json(results);
    } catch (error: any) {
      log(`Symbol search error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: `Failed to search symbols: ${error.message}` });
    }
  });
  
  // Get options chain for a symbol
  app.get('/api/market/options/:symbol', requireAdmin, async (req, res) => {
    try {
      const symbol = req.params.symbol;
      const expiration = req.query.expiration as string | undefined;
      
      const optionChain = await schwabService.getOptionChain(symbol, expiration);
      return res.status(200).json(optionChain);
    } catch (error: any) {
      log(`Options chain error: ${error.message}`, 'api-error');
      return res.status(500).json({ message: `Failed to get options chain: ${error.message}` });
    }
  });
  
  // Validate a trade before execution
  app.post('/api/trades/validate', requireAdmin, async (req, res) => {
    try {
      const tradeOrder = req.body;
      
      // Basic validation
      if (!tradeOrder.symbol || !tradeOrder.quantity || !tradeOrder.orderType || !tradeOrder.action) {
        return res.status(400).json({ 
          isValid: false, 
          message: 'Missing required trade parameters' 
        });
      }
      
      // Validate with the Schwab service
      const validationResult = await schwabService.validateTrade(tradeOrder);
      return res.status(200).json(validationResult);
    } catch (error: any) {
      log(`Trade validation error: ${error.message}`, 'api-error');
      return res.status(500).json({ 
        isValid: false, 
        message: `Validation failed: ${error.message}` 
      });
    }
  });
  
  // Set up periodic updates
  // Update active trades every 30 seconds
  setInterval(async () => {
    try {
      await tradeService.updateAllActiveTrades();
      
      // Broadcast updated trades to websocket clients
      const activeTrades = await storage.getActiveTrades();
      broadcast({
        type: 'tradesUpdate',
        data: activeTrades
      });
    } catch (error: any) {
      log(`Periodic trade update error: ${error.message}`, 'schedule-error');
    }
  }, 30000);
  
  // Update market data every 15 seconds
  setInterval(async () => {
    try {
      const marketIndices = await schwabService.getMarketIndices();
      
      // Store market data in database
      for (const index of marketIndices) {
        await storage.updateMarketData({
          symbol: index.symbol,
          price: index.price,
          change: index.change,
          changePercentage: index.changePercentage
        });
      }
      
      // Broadcast to all connected clients
      broadcast({
        type: 'marketUpdate',
        data: marketIndices
      });
    } catch (error: any) {
      log(`Periodic market update error: ${error.message}`, 'schedule-error');
    }
  }, 15000);
  
  // Update account metrics hourly
  setInterval(async () => {
    try {
      const accounts = await storage.getAccounts();
      
      for (const account of accounts) {
        try {
          await accountService.updateAccountMetrics(account.id);
        } catch (error: any) {
          log(`Account metrics update error for ${account.id}: ${error.message}`, 'schedule-error');
        }
      }
      
      log(`Updated metrics for ${accounts.length} accounts`, 'schedule');
    } catch (error: any) {
      log(`Periodic account metrics update error: ${error.message}`, 'schedule-error');
    }
  }, 3600000); // 1 hour
  
  return httpServer;
}
