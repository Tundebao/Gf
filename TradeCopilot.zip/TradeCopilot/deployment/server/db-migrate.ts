import { pool, db } from './db';
import { sql } from 'drizzle-orm';
import { log } from './vite';

async function main() {
  try {
    log('Starting database migration...', 'db-migrate');

    // 1. Add enum types if they don't exist
    await db.execute(sql`
      DO $$
      BEGIN
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'copy_mode') THEN
          CREATE TYPE copy_mode AS ENUM ('exact', 'fixed', 'percentage');
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'order_type') THEN
          CREATE TYPE order_type AS ENUM ('market', 'limit', 'stop', 'stop_limit', 'trailing_stop');
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'time_in_force') THEN
          CREATE TYPE time_in_force AS ENUM ('day', 'gtc', 'ext');
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'trail_type') THEN
          CREATE TYPE trail_type AS ENUM ('amount', 'percentage');
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'option_type') THEN
          CREATE TYPE option_type AS ENUM ('call', 'put');
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'option_strategy') THEN
          CREATE TYPE option_strategy AS ENUM ('single', 'vertical', 'calendar', 'straddle', 'strangle', 'iron_condor');
        END IF;
      END
      $$;
    `);
    log('Created enum types', 'db-migrate');

    // 2. Add new columns to accounts table
    const alterAccountsTable = async () => {
      // Check if columns exist before adding them
      const columnsResult = await db.execute(sql`
        SELECT column_name
        FROM information_schema.columns
        WHERE table_name = 'accounts'
      `);
      
      const columns = columnsResult.rows.map((row: any) => row.column_name);
      
      // Add margin_available column if it doesn't exist
      if (!columns.includes('margin_available')) {
        await db.execute(sql`
          ALTER TABLE accounts
          ADD COLUMN margin_available double precision;
        `);
        log('Added margin_available column', 'db-migrate');
      }
      
      // Add pdt_status column if it doesn't exist
      if (!columns.includes('pdt_status')) {
        await db.execute(sql`
          ALTER TABLE accounts
          ADD COLUMN pdt_status boolean DEFAULT false;
        `);
        log('Added pdt_status column', 'db-migrate');
      }
      
      // Add copy_mode column if it doesn't exist
      if (!columns.includes('copy_mode')) {
        await db.execute(sql`
          ALTER TABLE accounts
          ADD COLUMN copy_mode copy_mode DEFAULT 'percentage';
        `);
        log('Added copy_mode column', 'db-migrate');
      }
      
      // Add copy_allocation column if it doesn't exist
      if (!columns.includes('copy_allocation')) {
        await db.execute(sql`
          ALTER TABLE accounts
          ADD COLUMN copy_allocation double precision DEFAULT 100;
        `);
        log('Added copy_allocation column', 'db-migrate');
      }
      
      // Add max_trade_size column if it doesn't exist
      if (!columns.includes('max_trade_size')) {
        await db.execute(sql`
          ALTER TABLE accounts
          ADD COLUMN max_trade_size double precision DEFAULT 1000;
        `);
        log('Added max_trade_size column', 'db-migrate');
      }
      
      // Add max_daily_drawdown column if it doesn't exist
      if (!columns.includes('max_daily_drawdown')) {
        await db.execute(sql`
          ALTER TABLE accounts
          ADD COLUMN max_daily_drawdown double precision DEFAULT 500;
        `);
        log('Added max_daily_drawdown column', 'db-migrate');
      }
      
      // Add trading_start_time column if it doesn't exist
      if (!columns.includes('trading_start_time')) {
        await db.execute(sql`
          ALTER TABLE accounts
          ADD COLUMN trading_start_time text DEFAULT '09:30';
        `);
        log('Added trading_start_time column', 'db-migrate');
      }
      
      // Add trading_end_time column if it doesn't exist
      if (!columns.includes('trading_end_time')) {
        await db.execute(sql`
          ALTER TABLE accounts
          ADD COLUMN trading_end_time text DEFAULT '16:00';
        `);
        log('Added trading_end_time column', 'db-migrate');
      }
      
      // Add emergency_kill_switch column if it doesn't exist
      if (!columns.includes('emergency_kill_switch')) {
        await db.execute(sql`
          ALTER TABLE accounts
          ADD COLUMN emergency_kill_switch boolean DEFAULT false;
        `);
        log('Added emergency_kill_switch column', 'db-migrate');
      }
      
      // Add blocked_symbols column if it doesn't exist
      if (!columns.includes('blocked_symbols')) {
        await db.execute(sql`
          ALTER TABLE accounts
          ADD COLUMN blocked_symbols text[];
        `);
        log('Added blocked_symbols column', 'db-migrate');
      }
      
      // Add daily_profit_loss column if it doesn't exist
      if (!columns.includes('daily_profit_loss')) {
        await db.execute(sql`
          ALTER TABLE accounts
          ADD COLUMN daily_profit_loss double precision DEFAULT 0;
        `);
        log('Added daily_profit_loss column', 'db-migrate');
      }
      
      // Add daily_profit_loss_percentage column if it doesn't exist
      if (!columns.includes('daily_profit_loss_percentage')) {
        await db.execute(sql`
          ALTER TABLE accounts
          ADD COLUMN daily_profit_loss_percentage double precision DEFAULT 0;
        `);
        log('Added daily_profit_loss_percentage column', 'db-migrate');
      }
      
      // Add fixed_quantity column if it doesn't exist
      if (!columns.includes('fixed_quantity')) {
        await db.execute(sql`
          ALTER TABLE accounts
          ADD COLUMN fixed_quantity double precision DEFAULT 1;
        `);
        log('Added fixed_quantity column', 'db-migrate');
      }
      
      // Add percent_allocation column if it doesn't exist
      if (!columns.includes('percent_allocation')) {
        await db.execute(sql`
          ALTER TABLE accounts
          ADD COLUMN percent_allocation double precision DEFAULT 100;
        `);
        log('Added percent_allocation column', 'db-migrate');
      }
      
      // Add kill_switch_enabled column if it doesn't exist
      if (!columns.includes('kill_switch_enabled')) {
        await db.execute(sql`
          ALTER TABLE accounts
          ADD COLUMN kill_switch_enabled boolean DEFAULT false;
        `);
        log('Added kill_switch_enabled column', 'db-migrate');
      }
    };
    
    await alterAccountsTable();

    // 3. Update trades table with new columns for advanced order types and options
    const alterTradesTable = async () => {
      // First, check if we need to modify the symbol column length
      await db.execute(sql`
        ALTER TABLE trades ALTER COLUMN symbol TYPE VARCHAR(20);
      `);
      log('Updated symbol column length in trades table', 'db-migrate');
      
      // Check existing columns
      const columnsResult = await db.execute(sql`
        SELECT column_name
        FROM information_schema.columns
        WHERE table_name = 'trades'
      `);
      
      const columns = columnsResult.rows.map((row: any) => row.column_name);
      
      // Add order_type column if it doesn't exist
      if (!columns.includes('order_type')) {
        await db.execute(sql`
          ALTER TABLE trades
          ADD COLUMN order_type order_type DEFAULT 'market';
        `);
        log('Added order_type column', 'db-migrate');
      }
      
      // Add time_in_force column if it doesn't exist
      if (!columns.includes('time_in_force')) {
        await db.execute(sql`
          ALTER TABLE trades
          ADD COLUMN time_in_force time_in_force DEFAULT 'day';
        `);
        log('Added time_in_force column', 'db-migrate');
      }
      
      // Add trail_amount column if it doesn't exist
      if (!columns.includes('trail_amount')) {
        await db.execute(sql`
          ALTER TABLE trades
          ADD COLUMN trail_amount double precision;
        `);
        log('Added trail_amount column', 'db-migrate');
      }
      
      // Add trail_type column if it doesn't exist
      if (!columns.includes('trail_type')) {
        await db.execute(sql`
          ALTER TABLE trades
          ADD COLUMN trail_type trail_type;
        `);
        log('Added trail_type column', 'db-migrate');
      }
      
      // Add is_option column if it doesn't exist
      if (!columns.includes('is_option')) {
        await db.execute(sql`
          ALTER TABLE trades
          ADD COLUMN is_option boolean DEFAULT false;
        `);
        log('Added is_option column', 'db-migrate');
      }
      
      // Add option_type column if it doesn't exist
      if (!columns.includes('option_type')) {
        await db.execute(sql`
          ALTER TABLE trades
          ADD COLUMN option_type option_type;
        `);
        log('Added option_type column', 'db-migrate');
      }
      
      // Add expiration_date column if it doesn't exist
      if (!columns.includes('expiration_date')) {
        await db.execute(sql`
          ALTER TABLE trades
          ADD COLUMN expiration_date varchar(10);
        `);
        log('Added expiration_date column', 'db-migrate');
      }
      
      // Add strike_price column if it doesn't exist
      if (!columns.includes('strike_price')) {
        await db.execute(sql`
          ALTER TABLE trades
          ADD COLUMN strike_price double precision;
        `);
        log('Added strike_price column', 'db-migrate');
      }
      
      // Add option_strategy column if it doesn't exist
      if (!columns.includes('option_strategy')) {
        await db.execute(sql`
          ALTER TABLE trades
          ADD COLUMN option_strategy option_strategy;
        `);
        log('Added option_strategy column', 'db-migrate');
      }
    };
    
    await alterTradesTable();
    
    // 4. Create option_legs table if it doesn't exist
    const createOptionLegsTable = async () => {
      const tableExistsResult = await db.execute(sql`
        SELECT EXISTS (
          SELECT FROM information_schema.tables 
          WHERE table_name = 'option_legs'
        ) as exists;
      `);
      
      const tableExists = tableExistsResult.rows[0].exists;
      
      if (!tableExists) {
        await db.execute(sql`
          CREATE TABLE option_legs (
            id SERIAL PRIMARY KEY,
            trade_id INTEGER NOT NULL REFERENCES trades(id) ON DELETE CASCADE,
            symbol VARCHAR(30) NOT NULL,
            action TEXT NOT NULL,
            quantity DOUBLE PRECISION NOT NULL,
            option_type option_type NOT NULL,
            strike_price DOUBLE PRECISION NOT NULL,
            expiration_date VARCHAR(10) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            executed_at TIMESTAMP,
            status trade_status NOT NULL DEFAULT 'active'
          );
        `);
        log('Created option_legs table', 'db-migrate');
      }
    };
    
    await createOptionLegsTable();
    
    // 5. Update trade_accounts table with new columns for copy trading
    const alterTradeAccountsTable = async () => {
      // Check existing columns
      const columnsResult = await db.execute(sql`
        SELECT column_name
        FROM information_schema.columns
        WHERE table_name = 'trade_accounts'
      `);
      
      const columns = columnsResult.rows.map((row: any) => row.column_name);
      
      // Add quantity column if it doesn't exist
      if (!columns.includes('quantity')) {
        await db.execute(sql`
          ALTER TABLE trade_accounts
          ADD COLUMN quantity double precision;
        `);
        log('Added quantity column to trade_accounts', 'db-migrate');
      }
      
      // Add price column if it doesn't exist
      if (!columns.includes('price')) {
        await db.execute(sql`
          ALTER TABLE trade_accounts
          ADD COLUMN price double precision;
        `);
        log('Added price column to trade_accounts', 'db-migrate');
      }
      
      // Add order_type column if it doesn't exist
      if (!columns.includes('order_type')) {
        await db.execute(sql`
          ALTER TABLE trade_accounts
          ADD COLUMN order_type order_type;
        `);
        log('Added order_type column to trade_accounts', 'db-migrate');
      }
      
      // Add order_id column if it doesn't exist
      if (!columns.includes('order_id')) {
        await db.execute(sql`
          ALTER TABLE trade_accounts
          ADD COLUMN order_id text;
        `);
        log('Added order_id column to trade_accounts', 'db-migrate');
      }
      
      // Add error_message column if it doesn't exist
      if (!columns.includes('error_message')) {
        await db.execute(sql`
          ALTER TABLE trade_accounts
          ADD COLUMN error_message text;
        `);
        log('Added error_message column to trade_accounts', 'db-migrate');
      }
      
      // Add retry_count column if it doesn't exist
      if (!columns.includes('retry_count')) {
        await db.execute(sql`
          ALTER TABLE trade_accounts
          ADD COLUMN retry_count integer DEFAULT 0;
        `);
        log('Added retry_count column to trade_accounts', 'db-migrate');
      }
      
      // Add last_retry_at column if it doesn't exist
      if (!columns.includes('last_retry_at')) {
        await db.execute(sql`
          ALTER TABLE trade_accounts
          ADD COLUMN last_retry_at timestamp;
        `);
        log('Added last_retry_at column to trade_accounts', 'db-migrate');
      }
    };
    
    await alterTradeAccountsTable();
    
    log('Database migration completed successfully', 'db-migrate');
    process.exit(0);
  } catch (error) {
    log(`Migration failed: ${error}`, 'db-migrate-error');
    process.exit(1);
  }
}

main();