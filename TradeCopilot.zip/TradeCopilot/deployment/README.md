# TradeSwim cPanel Deployment

## Setup Instructions

1. Upload all files to your cPanel account
2. In cPanel, go to "Setup Node.js App"
3. Create a new Node.js application:
   - Node.js version: 20.x (or latest available)
   - Application mode: Production
   - Application root: /path/to/uploaded/files
   - Application URL: your domain or subdomain
   - Application startup file: index.js
   - Environment variables:
     - DATABASE_URL: Your PostgreSQL connection string
     - JWT_SECRET: Your secret key for JWT
     - SCHWAB_API_URL: Your Schwab API URL
     - SCHWAB_CLIENT_ID: Your Schwab client ID
     - SCHWAB_CLIENT_SECRET: Your Schwab client secret
     - SCHWAB_API_BASE_URL: Your Schwab API base URL
     - SCHWAB_API_KEY: Your Schwab API key
     - SCHWAB_API_SECRET: Your Schwab API secret
     - SCHWAB_REDIRECT_URI: Your Schwab redirect URI

4. Set up the PostgreSQL database:
   - Create a new PostgreSQL database in cPanel
   - Import your existing database dump if available
   - Update the DATABASE_URL environment variable with the new connection details

5. Install dependencies:
   - SSH into your cPanel account
   - Navigate to your application directory
   - Run: npm install

6. Start the application:
   - Click "Start Application" in the Node.js app setup

## Troubleshooting

- If you see WebSocket connection errors, ensure that your hosting provider supports WebSocket proxying
- For database connection issues, verify your DATABASE_URL environment variable
- Check the application logs in cPanel for any error messages
