import { pgTable, text, serial, integer, boolean, doublePrecision, timestamp, varchar, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Enums
export const tradeTypeEnum = pgEnum('trade_type', ['long', 'short']);
export const tradeStatusEnum = pgEnum('trade_status', ['active', 'closed', 'pending', 'warning', 'error']);
export const accountStatusEnum = pgEnum('account_status', ['connected', 'paused', 'auth_failed', 'disconnected']);
export const copyModeEnum = pgEnum('copy_mode', ['exact', 'fixed', 'percentage']);
export const orderTypeEnum = pgEnum('order_type', ['market', 'limit', 'stop', 'stop_limit', 'trailing_stop']);
export const timeInForceEnum = pgEnum('time_in_force', ['day', 'gtc', 'ext']);
export const trailTypeEnum = pgEnum('trail_type', ['amount', 'percentage']);
export const optionTypeEnum = pgEnum('option_type', ['call', 'put']);
export const optionStrategyEnum = pgEnum('option_strategy', ['single', 'vertical', 'calendar', 'straddle', 'strangle', 'iron_condor']);

// Users table (for admin authentication)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  isAdmin: boolean("is_admin").notNull().default(false),
  lastLogin: timestamp("last_login"),
});

// Connected trading accounts
export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  accountName: text("account_name").notNull(),
  accountId: text("account_id").notNull().unique(),
  accountType: text("account_type").notNull(),
  balance: doublePrecision("balance").notNull(),
  marginAvailable: doublePrecision("margin_available"),
  pdtStatus: boolean("pdt_status").default(false),
  status: accountStatusEnum("status").notNull().default('connected'),
  // Copy trading settings
  copyMode: copyModeEnum("copy_mode").default('percentage'),
  copyAllocation: doublePrecision("copy_allocation").default(100),
  fixedQuantity: doublePrecision("fixed_quantity").default(1),
  percentAllocation: doublePrecision("percent_allocation").default(100),
  // Risk management controls
  maxTradeSize: doublePrecision("max_trade_size").default(1000),
  maxDailyDrawdown: doublePrecision("max_daily_drawdown").default(500),
  tradingStartTime: text("trading_start_time").default('09:30'),
  tradingEndTime: text("trading_end_time").default('16:00'),
  emergencyKillSwitch: boolean("emergency_kill_switch").default(false),
  killSwitchEnabled: boolean("kill_switch_enabled").default(false),
  blockedSymbols: text("blocked_symbols").array(),
  // API credentials
  apiKey: text("api_key"),
  apiSecret: text("api_secret"),
  // Stats
  activeTrades: integer("active_trades").notNull().default(0),
  monthlyProfitLoss: doublePrecision("monthly_profit_loss").notNull().default(0),
  monthlyProfitLossPercentage: doublePrecision("monthly_profit_loss_percentage").notNull().default(0),
  dailyProfitLoss: doublePrecision("daily_profit_loss").default(0),
  dailyProfitLossPercentage: doublePrecision("daily_profit_loss_percentage").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Trades
export const trades = pgTable("trades", {
  id: serial("id").primaryKey(),
  symbol: varchar("symbol", { length: 20 }).notNull(), // Increased length for option symbols
  type: tradeTypeEnum("type").notNull(),
  entryPrice: doublePrecision("entry_price").notNull(),
  currentPrice: doublePrecision("current_price"),
  targetPrice: doublePrecision("target_price"),
  stopLoss: doublePrecision("stop_loss"),
  quantity: doublePrecision("quantity").notNull(),
  profitLoss: doublePrecision("profit_loss"),
  profitLossPercentage: doublePrecision("profit_loss_percentage"),
  status: tradeStatusEnum("status").notNull().default('active'),
  
  // Advanced order type fields
  orderType: orderTypeEnum("order_type").default('market'),
  timeInForce: timeInForceEnum("time_in_force").default('day'),
  
  // Trailing stop parameters
  trailAmount: doublePrecision("trail_amount"),
  trailType: trailTypeEnum("trail_type"),
  
  // Options trading fields
  isOption: boolean("is_option").default(false),
  optionType: optionTypeEnum("option_type"),
  expirationDate: varchar("expiration_date", { length: 10 }),
  strikePrice: doublePrecision("strike_price"),
  optionStrategy: optionStrategyEnum("option_strategy"),
  
  // Timestamps
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  closedAt: timestamp("closed_at"),
});

// Trade Accounts (for copy trading relationships)
export const tradeAccounts = pgTable("trade_accounts", {
  id: serial("id").primaryKey(),
  tradeId: integer("trade_id").notNull().references(() => trades.id, { onDelete: 'cascade' }),
  accountId: integer("account_id").notNull().references(() => accounts.id, { onDelete: 'cascade' }),
  status: tradeStatusEnum("status").notNull().default('active'),
  executedAt: timestamp("executed_at"),
  profitLoss: doublePrecision("profit_loss"),
  profitLossPercentage: doublePrecision("profit_loss_percentage"),
  
  // Copy trading specific fields
  quantity: doublePrecision("quantity"),
  price: doublePrecision("price"),
  orderType: orderTypeEnum("order_type"),
  orderId: text("order_id"),
  errorMessage: text("error_message"),
  retryCount: integer("retry_count").default(0),
  lastRetryAt: timestamp("last_retry_at"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Market data
export const marketData = pgTable("market_data", {
  id: serial("id").primaryKey(),
  symbol: varchar("symbol", { length: 10 }).notNull(),
  price: doublePrecision("price").notNull(),
  change: doublePrecision("change").notNull(),
  changePercentage: doublePrecision("change_percentage").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Option Legs for multi-leg option strategies
export const optionLegs = pgTable("option_legs", {
  id: serial("id").primaryKey(),
  tradeId: integer("trade_id").notNull().references(() => trades.id, { onDelete: 'cascade' }),
  symbol: varchar("symbol", { length: 30 }).notNull(),
  action: text("action").notNull(),  // 'buy' or 'sell'
  quantity: doublePrecision("quantity").notNull(),
  optionType: optionTypeEnum("option_type").notNull(),
  strikePrice: doublePrecision("strike_price").notNull(),
  expirationDate: varchar("expiration_date", { length: 10 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  executedAt: timestamp("executed_at"),
  status: tradeStatusEnum("status").notNull().default('active'),
});

// OAuth tokens for Schwab API
export const oauthTokens = pgTable("oauth_tokens", {
  id: serial("id").primaryKey(),
  accountId: integer("account_id").references(() => accounts.id, { onDelete: 'cascade' }),
  accessToken: text("access_token").notNull(),
  refreshToken: text("refresh_token").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  scope: text("scope"),
  tokenType: text("token_type").notNull().default('Bearer'),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Define relations
export const accountsRelations = relations(accounts, ({ many, one }) => ({
  tradeAccounts: many(tradeAccounts),
  oauthToken: one(oauthTokens, {
    fields: [accounts.id],
    references: [oauthTokens.accountId],
  }),
}));

export const tradesRelations = relations(trades, ({ many }) => ({
  tradeAccounts: many(tradeAccounts),
  optionLegs: many(optionLegs),
}));

export const optionLegsRelations = relations(optionLegs, ({ one }) => ({
  trade: one(trades, {
    fields: [optionLegs.tradeId],
    references: [trades.id],
  }),
}));

export const tradeAccountsRelations = relations(tradeAccounts, ({ one }) => ({
  trade: one(trades, {
    fields: [tradeAccounts.tradeId],
    references: [trades.id],
  }),
  account: one(accounts, {
    fields: [tradeAccounts.accountId],
    references: [accounts.id],
  }),
}));

export const oauthTokensRelations = relations(oauthTokens, ({ one }) => ({
  account: one(accounts, {
    fields: [oauthTokens.accountId],
    references: [accounts.id],
  }),
}));

// Zod schemas for validation
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  isAdmin: true,
});

export const insertAccountSchema = createInsertSchema(accounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTradeSchema = createInsertSchema(trades).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  closedAt: true,
});

export const insertTradeAccountSchema = createInsertSchema(tradeAccounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const loginSchema = z.object({
  username: z.string().min(3, 'Username must be at least 3 characters'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

export const marketDataSchema = createInsertSchema(marketData).omit({
  id: true,
  updatedAt: true,
});

export const oauthTokenSchema = createInsertSchema(oauthTokens).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const optionLegSchema = createInsertSchema(optionLegs).omit({
  id: true,
  createdAt: true,
  executedAt: true,
});

// TypeScript types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Account = typeof accounts.$inferSelect;
export type InsertAccount = z.infer<typeof insertAccountSchema>;

export type Trade = typeof trades.$inferSelect;
export type InsertTrade = z.infer<typeof insertTradeSchema>;

export type TradeAccount = typeof tradeAccounts.$inferSelect;
export type InsertTradeAccount = z.infer<typeof insertTradeAccountSchema>;

export type MarketData = typeof marketData.$inferSelect;
export type InsertMarketData = z.infer<typeof marketDataSchema>;

export type OAuthToken = typeof oauthTokens.$inferSelect;
export type InsertOAuthToken = z.infer<typeof oauthTokenSchema>;

export type OptionLeg = typeof optionLegs.$inferSelect;
export type InsertOptionLeg = z.infer<typeof optionLegSchema>;

export type LoginData = z.infer<typeof loginSchema>;
