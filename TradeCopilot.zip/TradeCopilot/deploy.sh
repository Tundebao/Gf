#!/bin/bash
# TradeSwim cPanel Deployment Script

# Create a deployment directory
mkdir -p deployment

# Build the client application
echo "Building client application..."
cd client
npm run build
cd ..

# Copy the built client files to deployment
cp -r client/dist/* deployment/

# Create a server directory in deployment
mkdir -p deployment/server

# Copy necessary server files
echo "Copying server files..."
cp -r server/* deployment/server/
cp -r shared deployment/
cp package.json deployment/
cp tsconfig.json deployment/
cp drizzle.config.ts deployment/
cp vite.config.ts deployment/

# Create .htaccess file for the deployment
echo "Creating .htaccess file..."
cat > deployment/.htaccess << EOL
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /
    RewriteRule ^index\.html$ - [L]
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule . /index.html [L]
</IfModule>

# Websocket proxy
<IfModule mod_proxy.c>
    <IfModule mod_proxy_wstunnel.c>
        ProxyPass /ws ws://localhost:5000/ws
        ProxyPassReverse /ws ws://localhost:5000/ws
    </IfModule>
</IfModule>
EOL

# Create a cpanel-specific index.js for Node.js application
echo "Creating Node.js entry point..."
cat > deployment/index.js << EOL
// cPanel-specific entry point
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');

// This ensures TypeScript is compiled on the server
exec('npx tsx server/index.ts', {
  cwd: __dirname,
  env: {
    ...process.env,
    NODE_ENV: 'production',
    PORT: process.env.PORT || 5000,
    DATABASE_URL: process.env.DATABASE_URL,
    JWT_SECRET: process.env.JWT_SECRET,
    SCHWAB_API_URL: process.env.SCHWAB_API_URL,
    SCHWAB_CLIENT_ID: process.env.SCHWAB_CLIENT_ID,
    SCHWAB_CLIENT_SECRET: process.env.SCHWAB_CLIENT_SECRET,
    SCHWAB_API_BASE_URL: process.env.SCHWAB_API_BASE_URL,
    SCHWAB_API_KEY: process.env.SCHWAB_API_KEY,
    SCHWAB_API_SECRET: process.env.SCHWAB_API_SECRET,
    SCHWAB_REDIRECT_URI: process.env.SCHWAB_REDIRECT_URI
  }
}, (error, stdout, stderr) => {
  if (error) {
    console.error(`Execution error: ${error}`);
    return;
  }
  console.log(stdout);
  console.error(stderr);
});
EOL

# Create a README for deployment
echo "Creating deployment README..."
cat > deployment/README.md << EOL
# TradeSwim cPanel Deployment

## Setup Instructions

1. Upload all files to your cPanel account
2. In cPanel, go to "Setup Node.js App"
3. Create a new Node.js application:
   - Node.js version: 20.x (or latest available)
   - Application mode: Production
   - Application root: /path/to/uploaded/files
   - Application URL: your domain or subdomain
   - Application startup file: index.js
   - Environment variables:
     - DATABASE_URL: Your PostgreSQL connection string
     - JWT_SECRET: Your secret key for JWT
     - SCHWAB_API_URL: Your Schwab API URL
     - SCHWAB_CLIENT_ID: Your Schwab client ID
     - SCHWAB_CLIENT_SECRET: Your Schwab client secret
     - SCHWAB_API_BASE_URL: Your Schwab API base URL
     - SCHWAB_API_KEY: Your Schwab API key
     - SCHWAB_API_SECRET: Your Schwab API secret
     - SCHWAB_REDIRECT_URI: Your Schwab redirect URI

4. Set up the PostgreSQL database:
   - Create a new PostgreSQL database in cPanel
   - Import your existing database dump if available
   - Update the DATABASE_URL environment variable with the new connection details

5. Install dependencies:
   - SSH into your cPanel account
   - Navigate to your application directory
   - Run: npm install

6. Start the application:
   - Click "Start Application" in the Node.js app setup

## Troubleshooting

- If you see WebSocket connection errors, ensure that your hosting provider supports WebSocket proxying
- For database connection issues, verify your DATABASE_URL environment variable
- Check the application logs in cPanel for any error messages
EOL

# Create a zip file for easy download
echo "Creating deployment zip file..."
cd deployment
zip -r ../tradeswim-cpanel-deploy.zip .
cd ..

echo "Deployment package created successfully!"
echo "Download the tradeswim-cpanel-deploy.zip file and follow the instructions in the README.md file to deploy to cPanel."