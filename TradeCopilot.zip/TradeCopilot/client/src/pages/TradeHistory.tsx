import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { format } from 'date-fns';
import { 
  Download, 
  Filter, 
  RefreshCw, 
  Calendar, 
  FileText, 
  TrendingUp, 
  TrendingDown,
  AlertTriangle
} from 'lucide-react';
import { Trade, Account } from '@shared/schema';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';

type TradeHistoryFilters = {
  startDate?: Date;
  endDate?: Date;
  symbol?: string;
  status?: string;
  account?: number;
};

const TradeHistory: React.FC = () => {
  const { toast } = useToast();
  const [filters, setFilters] = useState<TradeHistoryFilters>({});
  const [symbolFilter, setSymbolFilter] = useState('');
  const [startDateOpen, setStartDateOpen] = useState(false);
  const [endDateOpen, setEndDateOpen] = useState(false);
  
  // Format date for query string if it exists
  const formatDateForQuery = (date?: Date) => {
    if (!date) return undefined;
    return date.toISOString();
  };
  
  // Build query string from filters
  const buildQueryString = () => {
    const params = new URLSearchParams();
    
    if (filters.startDate) {
      params.append('startDate', formatDateForQuery(filters.startDate) || '');
    }
    
    if (filters.endDate) {
      params.append('endDate', formatDateForQuery(filters.endDate) || '');
    }
    
    if (filters.symbol) {
      params.append('symbol', filters.symbol);
    }
    
    if (filters.status) {
      params.append('status', filters.status);
    }
    
    if (filters.account) {
      params.append('account', filters.account.toString());
    }
    
    return params.toString();
  };
  
  // Fetch trade history data with filters
  const { data, isLoading, isError, refetch } = useQuery<Trade[]>({
    queryKey: ['/api/trade-history', filters],
    queryFn: async () => {
      const queryString = buildQueryString();
      const url = queryString ? `/api/trade-history?${queryString}` : '/api/trade-history';
      const response = await apiRequest('GET', url);
      if (!response.ok) {
        throw new Error('Failed to fetch trade history');
      }
      return response.json();
    },
  });
  
  // Fetch accounts for account filter dropdown
  const { data: accounts } = useQuery({
    queryKey: ['/api/accounts'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/accounts');
      if (!response.ok) {
        throw new Error('Failed to fetch accounts');
      }
      return response.json();
    },
  });
  
  // Apply filters
  const applyFilters = () => {
    setFilters({
      ...filters,
      symbol: symbolFilter || undefined,
    });
  };
  
  // Reset all filters
  const resetFilters = () => {
    setFilters({});
    setSymbolFilter('');
  };
  
  // Download trade history as CSV
  const downloadCsv = async () => {
    try {
      const queryString = buildQueryString();
      const url = queryString ? `/api/trade-history/export?${queryString}` : '/api/trade-history/export';
      
      const response = await apiRequest('GET', url);
      
      if (!response.ok) {
        throw new Error('Failed to download CSV');
      }
      
      // Create a blob from the response
      const blob = await response.blob();
      
      // Create a temporary URL for the blob
      const downloadUrl = window.URL.createObjectURL(blob);
      
      // Create a temporary link element
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = `trade-history-${format(new Date(), 'yyyy-MM-dd')}.csv`;
      
      // Append to the document, click it, and remove it
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      
      // Release the URL
      window.URL.revokeObjectURL(downloadUrl);
      
      toast({
        title: 'Success',
        description: 'Trade history exported successfully',
      });
    } catch (error) {
      console.error('Error downloading CSV:', error);
      toast({
        title: 'Export failed',
        description: 'Failed to export trade history',
        variant: 'destructive',
      });
    }
  };
  
  // Format currency
  const formatCurrency = (value: number | null) => {
    if (value === null) return '-';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value);
  };
  
  // Format percentage
  const formatPercentage = (value: number | null) => {
    if (value === null) return '-';
    return `${value.toFixed(2)}%`;
  };
  
  // Get trade row color based on type
  const getTradeTypeColor = (trade: Trade) => {
    // Buy trades are green
    if (trade.type === 'long') {
      return 'hover:bg-green-50 dark:hover:bg-green-950/20';
    }
    // Sell trades are red
    else if (trade.type === 'short') {
      return 'hover:bg-red-50 dark:hover:bg-red-950/20';
    }
    return '';
  };
  
  // Get status badge colors
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-500 hover:bg-green-600">Active</Badge>;
      case 'closed':
        return <Badge className="bg-gray-500 hover:bg-gray-600">Closed</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-500 hover:bg-yellow-600">Pending</Badge>;
      case 'warning':
        return <Badge className="bg-orange-500 hover:bg-orange-600">Warning</Badge>;
      case 'error':
        return <Badge className="bg-red-500 hover:bg-red-600">Error</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };
  
  return (
    <div className="container mx-auto py-6">
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Trade History</CardTitle>
            <CardDescription>
              View and filter your trading history
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => refetch()}>
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh
            </Button>
            <Button onClick={downloadCsv}>
              <Download className="mr-2 h-4 w-4" />
              Export CSV
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filter controls */}
          <div className="flex flex-wrap gap-3 mb-4">
            {/* Symbol filter */}
            <div className="flex-1 min-w-[200px]">
              <Input
                placeholder="Filter by symbol..."
                value={symbolFilter}
                onChange={(e) => setSymbolFilter(e.target.value)}
              />
            </div>
            
            {/* Status filter */}
            <div className="w-[200px]">
              <Select
                value={filters.status || "all"}
                onValueChange={(value) => setFilters({ ...filters, status: value === "all" ? undefined : value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="closed">Closed</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {/* Account filter */}
            <div className="w-[200px]">
              <Select
                value={filters.account?.toString() || "all"}
                onValueChange={(value) => 
                  setFilters({ ...filters, account: value === "all" ? undefined : parseInt(value, 10) })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Account" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All accounts</SelectItem>
                  {accounts?.map((account: { id: number, accountName: string }) => (
                    <SelectItem key={account.id} value={account.id.toString()}>
                      {account.accountName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            {/* Start date filter */}
            <div>
              <Popover open={startDateOpen} onOpenChange={setStartDateOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-[200px] justify-start">
                    <Calendar className="mr-2 h-4 w-4" />
                    {filters.startDate ? (
                      format(filters.startDate, 'PP')
                    ) : (
                      <span>From date</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <CalendarComponent
                    mode="single"
                    selected={filters.startDate}
                    onSelect={(date) => {
                      setFilters({ ...filters, startDate: date || undefined });
                      setStartDateOpen(false);
                    }}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            {/* End date filter */}
            <div>
              <Popover open={endDateOpen} onOpenChange={setEndDateOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-[200px] justify-start">
                    <Calendar className="mr-2 h-4 w-4" />
                    {filters.endDate ? (
                      format(filters.endDate, 'PP')
                    ) : (
                      <span>To date</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <CalendarComponent
                    mode="single"
                    selected={filters.endDate}
                    onSelect={(date) => {
                      setFilters({ ...filters, endDate: date || undefined });
                      setEndDateOpen(false);
                    }}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            {/* Filter action buttons */}
            <div className="flex gap-2">
              <Button variant="secondary" onClick={applyFilters}>
                <Filter className="mr-2 h-4 w-4" />
                Apply Filters
              </Button>
              <Button variant="outline" onClick={resetFilters}>
                Clear
              </Button>
            </div>
          </div>
          
          {/* Trade table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Symbol</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Entry Price</TableHead>
                  <TableHead>Current Price</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>P&L</TableHead>
                  <TableHead>P&L %</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Entry Date</TableHead>
                  <TableHead>Exit Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  // Loading skeleton
                  Array(5).fill(0).map((_, index) => (
                    <TableRow key={index}>
                      {Array(10).fill(0).map((_, colIndex) => (
                        <TableCell key={colIndex}>
                          <Skeleton className="h-6 w-full" />
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : isError ? (
                  // Error state
                  <TableRow>
                    <TableCell colSpan={10} className="text-center py-4">
                      <AlertTriangle className="h-8 w-8 text-red-500 mx-auto mb-2" />
                      <p>Failed to load trade history</p>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="mt-2"
                        onClick={() => refetch()}
                      >
                        Try Again
                      </Button>
                    </TableCell>
                  </TableRow>
                ) : data && data.length > 0 ? (
                  // Actual data
                  data.map((trade) => (
                    <TableRow key={trade.id} className={getTradeTypeColor(trade)}>
                      <TableCell className="font-medium">{trade.symbol}</TableCell>
                      <TableCell>
                        {trade.type === 'long' ? (
                          <div className="flex items-center">
                            <TrendingUp className="h-4 w-4 mr-1 text-green-500" />
                            Long
                          </div>
                        ) : (
                          <div className="flex items-center">
                            <TrendingDown className="h-4 w-4 mr-1 text-red-500" />
                            Short
                          </div>
                        )}
                      </TableCell>
                      <TableCell>{formatCurrency(trade.entryPrice)}</TableCell>
                      <TableCell>{formatCurrency(trade.currentPrice)}</TableCell>
                      <TableCell>{trade.quantity}</TableCell>
                      <TableCell 
                        className={(trade.profitLoss || 0) > 0 ? 'text-green-500' : 
                                  (trade.profitLoss || 0) < 0 ? 'text-red-500' : ''}
                      >
                        {formatCurrency(trade.profitLoss)}
                      </TableCell>
                      <TableCell
                        className={(trade.profitLossPercentage || 0) > 0 ? 'text-green-500' : 
                                  (trade.profitLossPercentage || 0) < 0 ? 'text-red-500' : ''}
                      >
                        {formatPercentage(trade.profitLossPercentage)}
                      </TableCell>
                      <TableCell>{getStatusBadge(trade.status)}</TableCell>
                      <TableCell>{format(new Date(trade.createdAt), 'MM/dd/yyyy HH:mm')}</TableCell>
                      <TableCell>
                        {trade.closedAt ? format(new Date(trade.closedAt), 'MM/dd/yyyy HH:mm') : '-'}
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  // No data state
                  <TableRow>
                    <TableCell colSpan={10} className="text-center py-8">
                      <FileText className="h-10 w-10 text-gray-400 mx-auto mb-2" />
                      <p>No trade history found</p>
                      {Object.keys(filters).length > 0 && (
                        <p className="text-sm text-gray-500 mt-1">
                          Try adjusting your filter criteria
                        </p>
                      )}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TradeHistory;