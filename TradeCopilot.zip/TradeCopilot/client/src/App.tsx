import React, { useEffect } from "react";
import { Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "./components/ui/toaster";
import { TooltipProvider } from "./components/ui/tooltip";
import { useWebSocket } from "./lib/websocket";
import { AuthProvider, useAuth } from "./lib/auth";
import NotFound from "./pages/not-found";
import Dashboard from "./pages/Dashboard";
import Trades from "./pages/Trades";
import TradeHistory from "./pages/TradeHistory";
import Accounts from "./pages/Accounts";
import Settings from "./pages/Settings";
import CopyTrading from "./pages/CopyTrading";
import LoginForm from "./components/auth/LoginForm";
import Header from "./components/layout/Header";
import Sidebar from "./components/layout/Sidebar";
import Footer from "./components/layout/Footer";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();
  const [location, setLocation] = useLocation();
  
  // Initialize WebSocket connection
  const websocket = useWebSocket();
  
  // Log when user is authenticated
  useEffect(() => {
    if (isAuthenticated) {
      console.log("User is authenticated, ready to use WebSocket");
    }
  }, [isAuthenticated]);
  
  useEffect(() => {
    console.log("Authentication state:", { isAuthenticated, isLoading });
  }, [isAuthenticated, isLoading]);
  
  // Show loading screen while auth state is being determined
  if (isLoading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-dark-darker">
        <div className="text-light text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading...</p>
        </div>
      </div>
    );
  }
  
  // If not authenticated, show login form
  if (!isAuthenticated) {
    console.log("User not authenticated, showing login form");
    return <LoginForm />;
  }
  
  console.log("User authenticated, rendering dashboard at location:", location);
  
  return (
    <div className="min-h-screen flex flex-col bg-dark-darker text-light font-sans">
      <Header />
      
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Mobile Navigation */}
        <div className="md:hidden bg-dark border-b border-dark-lighter px-4 py-2 overflow-x-auto hide-scroll">
          <div className="flex space-x-4">
            <a href="/" className={`whitespace-nowrap px-3 py-2 rounded-md text-sm font-medium ${location === '/' ? 'bg-dark-darker text-light' : 'text-light-darker hover:bg-dark-darker'}`}>Dashboard</a>
            <a href="/trades" className={`whitespace-nowrap px-3 py-2 rounded-md text-sm font-medium ${location === '/trades' ? 'bg-dark-darker text-light' : 'text-light-darker hover:bg-dark-darker'}`}>Trades</a>
            <a href="/trade-history" className={`whitespace-nowrap px-3 py-2 rounded-md text-sm font-medium ${location === '/trade-history' ? 'bg-dark-darker text-light' : 'text-light-darker hover:bg-dark-darker'}`}>History</a>
            <a href="/accounts" className={`whitespace-nowrap px-3 py-2 rounded-md text-sm font-medium ${location === '/accounts' ? 'bg-dark-darker text-light' : 'text-light-darker hover:bg-dark-darker'}`}>Accounts</a>
            <a href="/copy-trading" className={`whitespace-nowrap px-3 py-2 rounded-md text-sm font-medium ${location === '/copy-trading' ? 'bg-dark-darker text-light' : 'text-light-darker hover:bg-dark-darker'}`}>Copy Trading</a>
            <a href="/settings" className={`whitespace-nowrap px-3 py-2 rounded-md text-sm font-medium ${location === '/settings' ? 'bg-dark-darker text-light' : 'text-light-darker hover:bg-dark-darker'}`}>Settings</a>
          </div>
        </div>
        
        <main className="flex-1 p-4 md:p-6 overflow-auto">
          {/* Use individual routes and render them conditionally based on current path */}
          <Route path="/" component={Dashboard} />
          <Route path="/trades" component={Trades} />
          <Route path="/trade-history" component={TradeHistory} />
          <Route path="/accounts" component={Accounts} />
          <Route path="/copy-trading" component={CopyTrading} />
          <Route path="/settings" component={Settings} />
          
          {/* 404 route - show only if no other routes match */}
          {location !== "/" && 
           location !== "/trades" && 
           location !== "/trade-history" && 
           location !== "/accounts" && 
           location !== "/copy-trading" && 
           location !== "/settings" && <NotFound />}
        </main>
        
        <Sidebar />
      </div>
      
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AuthProvider>
          <Router />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
