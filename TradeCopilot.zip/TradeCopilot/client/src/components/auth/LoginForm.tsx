import { useState } from 'react';
import { useAuth } from '../../lib/auth';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { useToast } from '../../hooks/use-toast';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '../../components/ui/form';

const loginSchema = z.object({
  username: z.string().min(3, 'Username must be at least 3 characters'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

type LoginFormValues = z.infer<typeof loginSchema>;

export default function LoginForm() {
  const { login, isLoading } = useAuth();
  const { toast } = useToast();
  
  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: '',
      password: '',
    },
  });
  
  const onSubmit = async (data: LoginFormValues) => {
    try {
      console.log('Login form submitted with:', data.username);
      const success = await login(data.username, data.password);
      
      if (success) {
        console.log('Login successful, should be redirected');
        // Force a re-render to ensure the Router component sees the updated authentication state
        window.location.href = '/';
      } else {
        console.log('Login failed in form handler');
        toast({
          variant: 'destructive',
          title: 'Login Failed',
          description: 'Invalid username or password',
        });
      }
    } catch (error) {
      console.error('Login error in form handler:', error);
      toast({
        variant: 'destructive',
        title: 'Login Failed',
        description: error instanceof Error ? error.message : 'Invalid credentials',
      });
    }
  };
  
  return (
    <div className="fixed inset-0 bg-dark-darker bg-opacity-80 flex items-center justify-center z-50">
      <div className="bg-dark-lighter rounded-lg shadow-lg p-8 w-full max-w-md">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-light mb-2">TradeSwim</h2>
          <p className="text-light-darker">Admin Copy Trading Platform</p>
        </div>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-light-darker text-sm">Username</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="Enter your username"
                      className="w-full px-3 py-2 bg-dark-darker text-light border border-dark-lighter rounded focus:outline-none focus:border-primary"
                      disabled={isLoading}
                    />
                  </FormControl>
                  <FormMessage className="text-danger text-xs" />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-light-darker text-sm">Password</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="password"
                      placeholder="Enter your password"
                      className="w-full px-3 py-2 bg-dark-darker text-light border border-dark-lighter rounded focus:outline-none focus:border-primary"
                      disabled={isLoading}
                    />
                  </FormControl>
                  <FormMessage className="text-danger text-xs" />
                </FormItem>
              )}
            />
            
            <Button
              type="submit"
              className="w-full bg-primary hover:bg-primary-dark text-white font-semibold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition duration-200"
              disabled={isLoading}
            >
              {isLoading ? 'Signing In...' : 'Sign In'}
            </Button>
          </form>
        </Form>
        
        <div className="mt-4 text-center">
          <p className="text-light-darker text-sm">Admin access only. Unauthorized access is prohibited.</p>
        </div>
      </div>
    </div>
  );
}
