import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Account } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { formatCurrency, formatPercentage } from '@/lib/utils';
import { useLocation } from 'wouter';

interface AccountsResponse {
  accounts: Account[];
  total: number;
}

export default function ConnectedAccountsTable() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  const { data: accounts, isLoading, isError } = useQuery<Account[]>({
    queryKey: ['/api/accounts'],
  });

  const pauseAccountMutation = useMutation({
    mutationFn: async (accountId: number) => {
      const res = await apiRequest('POST', `/api/accounts/${accountId}/pause`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/accounts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      toast({
        title: 'Account paused',
        description: 'The account has been paused successfully',
      });
    },
    onError: (error) => {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to pause account',
      });
    }
  });

  const resumeAccountMutation = useMutation({
    mutationFn: async (accountId: number) => {
      const res = await apiRequest('POST', `/api/accounts/${accountId}/resume`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/accounts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      toast({
        title: 'Account resumed',
        description: 'The account has been resumed successfully',
      });
    },
    onError: (error) => {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to resume account',
      });
    }
  });

  const syncAccountMutation = useMutation({
    mutationFn: async (accountId: number) => {
      const res = await apiRequest('POST', `/api/accounts/${accountId}/sync`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/accounts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      toast({
        title: 'Account synced',
        description: 'The account has been synced successfully',
      });
    },
    onError: (error) => {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to sync account',
      });
    }
  });

  const handlePauseAccount = (accountId: number) => {
    pauseAccountMutation.mutate(accountId);
  };

  const handleResumeAccount = (accountId: number) => {
    resumeAccountMutation.mutate(accountId);
  };

  const handleSyncAccount = (accountId: number) => {
    syncAccountMutation.mutate(accountId);
  };
  
  const navigateToAccountsPage = () => {
    setLocation('/accounts');
  };
  
  const navigateToAccountSettings = (accountId: number) => {
    setLocation(`/accounts?id=${accountId}`);
  };

  // Status styles and text
  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'connected':
        return { dotClass: 'status-active', text: 'Connected' };
      case 'paused':
        return { dotClass: 'status-inactive', text: 'Paused' };
      case 'auth_failed':
        return { dotClass: 'status-error', text: 'Auth Failed' };
      case 'disconnected':
        return { dotClass: 'status-inactive', text: 'Disconnected' };
      default:
        return { dotClass: 'status-inactive', text: status };
    }
  };

  if (isLoading) {
    return (
      <div className="bg-dark rounded-lg shadow-md border border-dark-lighter overflow-hidden mb-6">
        <div className="p-4 border-b border-dark-lighter flex justify-between items-center">
          <div>
            <h3 className="font-semibold">Connected Accounts</h3>
            <p className="text-sm text-light-darker">Accounts configured for copy trading</p>
          </div>
          <Button className="px-3 py-1 text-sm" disabled>Loading...</Button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-dark-lighter">
            <thead className="bg-dark-lighter">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Account</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Type</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Balance</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Active Trades</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">P&L (Monthly)</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-light-darker uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-dark divide-y divide-dark-lighter animate-pulse">
              {Array(5).fill(0).map((_, index) => (
                <tr key={index}>
                  {Array(7).fill(0).map((_, cellIndex) => (
                    <td key={cellIndex} className="px-6 py-4 whitespace-nowrap">
                      <div className="h-4 bg-dark-lighter rounded"></div>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="bg-dark rounded-lg shadow-md border border-dark-lighter overflow-hidden mb-6 p-4">
        <div className="text-danger flex items-center justify-center p-6">
          <span className="material-icons mr-2">error</span>
          Failed to load accounts. Please try again later.
        </div>
      </div>
    );
  }

  return (
    <div className="bg-dark rounded-lg shadow-md border border-dark-lighter overflow-hidden">
      <div className="p-4 border-b border-dark-lighter flex justify-between items-center">
        <div>
          <h3 className="font-semibold">Connected Accounts</h3>
          <p className="text-sm text-light-darker">Accounts configured for copy trading</p>
        </div>
        <Button 
          className="px-3 py-1 text-sm rounded-md bg-primary hover:bg-primary-dark text-white transition-colors flex items-center"
          onClick={navigateToAccountsPage}
        >
          <span className="material-icons text-sm mr-1">add</span> Connect New
        </Button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-dark-lighter">
          <thead className="bg-dark-lighter">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Account</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Type</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Balance</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Active Trades</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">P&L (Monthly)</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Status</th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-light-darker uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-dark divide-y divide-dark-lighter">
            {accounts && accounts.length > 0 ? (
              accounts.map((account) => {
                const statusInfo = getStatusInfo(account.status);
                
                return (
                  <tr key={account.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="text-sm font-medium">{account.accountName}</div>
                        <div className="ml-2 text-xs text-light-darker">ID: {account.accountId}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 py-1 text-xs rounded-full bg-info bg-opacity-10 text-info">
                        {account.accountType}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap font-mono">
                      {formatCurrency(account.balance)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {account.activeTrades}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap font-mono">
                      <span className={account.monthlyProfitLoss >= 0 ? 'text-secondary' : 'text-danger'}>
                        {formatCurrency(account.monthlyProfitLoss)} ({formatPercentage(account.monthlyProfitLossPercentage)})
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <span className={`status-dot ${statusInfo.dotClass}`}></span>
                        <span>{statusInfo.text}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex justify-end space-x-2">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="p-1 rounded hover:bg-dark-lighter text-light"
                          onClick={() => navigateToAccountSettings(account.id)}
                        >
                          <span className="material-icons text-sm">settings</span>
                        </Button>
                        
                        {account.status === 'connected' ? (
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="p-1 rounded hover:bg-dark-lighter text-warning"
                            onClick={() => handlePauseAccount(account.id)}
                            disabled={pauseAccountMutation.isPending}
                          >
                            <span className="material-icons text-sm">pause</span>
                          </Button>
                        ) : account.status === 'paused' ? (
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="p-1 rounded hover:bg-dark-lighter text-secondary"
                            onClick={() => handleResumeAccount(account.id)}
                            disabled={resumeAccountMutation.isPending}
                          >
                            <span className="material-icons text-sm">play_arrow</span>
                          </Button>
                        ) : account.status === 'auth_failed' ? (
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="p-1 rounded hover:bg-dark-lighter text-primary"
                            onClick={() => handleSyncAccount(account.id)}
                            disabled={syncAccountMutation.isPending}
                          >
                            <span className="material-icons text-sm">refresh</span>
                          </Button>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={7} className="px-6 py-12 text-center text-light-darker">
                  No accounts connected. Click "Connect New" to add an account.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
