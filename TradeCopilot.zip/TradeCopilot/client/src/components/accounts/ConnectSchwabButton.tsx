import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";

interface ConnectSchwabButtonProps {
  accountId: number;
  onSuccess?: () => void;
}

export default function ConnectSchwabButton({ accountId, onSuccess }: ConnectSchwabButtonProps) {
  const { toast } = useToast();
  const { isAuthenticated } = useAuth();
  const [isLoading, setIsLoading] = useState(false);

  const connectMutation = useMutation({
    mutationFn: async () => {
      setIsLoading(true);
      // First make a request to our API to get the authorization URL with the token included
      const response = await apiRequest("GET", `/auth/schwab/connect?accountId=${accountId}`);
      
      if (response.ok) {
        // Response will be the authorization URL from Schwab
        const data = await response.json();
        if (data.authUrl) {
          window.location.href = data.authUrl;
        } else {
          throw new Error("Authorization URL not returned");
        }
      } else {
        // Handle error response
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to initiate OAuth flow");
      }
      
      return null;
    },
    onError: (error: Error) => {
      setIsLoading(false);
      toast({
        title: "Connection Failed",
        description: error.message || "Failed to initiate connection to Schwab",
        variant: "destructive",
      });
    }
  });

  // Check OAuth status
  const checkStatusMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("GET", `/auth/schwab/status/${accountId}`);
      return await res.json();
    },
    onSuccess: (data) => {
      if (data.connected) {
        toast({
          title: "Account Connected",
          description: "Your Schwab account is successfully connected.",
        });
        if (onSuccess) onSuccess();
      } else {
        toast({
          title: "Connection Required",
          description: "Please connect your Schwab account to enable trading.",
          variant: "destructive",
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Status Check Failed",
        description: error.message || "Failed to check connection status",
        variant: "destructive",
      });
    }
  });

  const handleConnect = () => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to connect your account.",
        variant: "destructive",
      });
      return;
    }
    
    // Check if token exists
    const token = localStorage.getItem('token');
    if (!token) {
      toast({
        title: "Authentication Error",
        description: "Session expired or invalid. Please log in again.",
        variant: "destructive",
      });
      return;
    }
    
    connectMutation.mutate();
  };

  return (
    <Button 
      onClick={handleConnect} 
      disabled={isLoading}
      size="sm"
      variant="outline"
      className="flex items-center gap-2"
    >
      {isLoading ? (
        <>
          <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          Connecting...
        </>
      ) : (
        <>
          <svg 
            className="h-4 w-4" 
            viewBox="0 0 24 24" 
            fill="none" 
            xmlns="http://www.w3.org/2000/svg"
          >
            <path 
              d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            />
            <path 
              d="M14.3333 19V12.5C14.3333 11.3954 13.4379 10.5 12.3333 10.5H7.66667" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            />
            <path 
              d="M10.3333 8.5L7.66667 10.5L10.3333 12.5" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            />
          </svg>
          Connect to Schwab
        </>
      )}
    </Button>
  );
}