import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { BadgeCheck, AlertCircle, Shield } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface OAuthStatusBadgeProps {
  accountId: number;
}

export default function OAuthStatusBadge({ accountId }: OAuthStatusBadgeProps) {
  const { data, isLoading, error } = useQuery({
    queryKey: [`/auth/schwab/status/${accountId}`],
    queryFn: async () => {
      const res = await apiRequest("GET", `/auth/schwab/status/${accountId}`);
      return res.json();
    },
    // Don't refetch too often
    refetchInterval: 300000, // 5 minutes
  });

  if (isLoading) {
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-gray-800 text-gray-300">
        <span className="h-2 w-2 animate-pulse bg-blue-400 rounded-full mr-1.5"></span>
        Checking...
      </span>
    );
  }

  if (error || !data) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <span className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-red-900/20 text-red-400">
              <AlertCircle className="h-3.5 w-3.5 mr-1" />
              Error
            </span>
          </TooltipTrigger>
          <TooltipContent>
            <p>Failed to check OAuth status</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  if (data.connected) {
    const expiresAt = new Date(data.expiresAt);
    const expiresIn = formatDistanceToNow(expiresAt, { addSuffix: true });

    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <span className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-green-900/20 text-green-400">
              <BadgeCheck className="h-3.5 w-3.5 mr-1" />
              OAuth Active
            </span>
          </TooltipTrigger>
          <TooltipContent>
            <p>Token expires {expiresIn}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-yellow-900/20 text-yellow-400">
            <Shield className="h-3.5 w-3.5 mr-1" />
            Not Connected
          </span>
        </TooltipTrigger>
        <TooltipContent>
          <p>OAuth connection required</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}