export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-dark-darker text-light-darker text-sm py-4 px-6 border-t border-dark-lighter">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
        <div className="mb-2 md:mb-0">
          <span>© {currentYear} TradeSwim. All rights reserved.</span>
        </div>
        <div className="flex space-x-4">
          <a href="#" className="hover:text-light transition-colors">Terms</a>
          <a href="#" className="hover:text-light transition-colors">Privacy</a>
          <a href="#" className="hover:text-light transition-colors">Help</a>
        </div>
      </div>
    </footer>
  );
}
